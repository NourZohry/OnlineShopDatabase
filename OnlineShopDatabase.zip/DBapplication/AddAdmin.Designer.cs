﻿namespace DBapplication
{
    partial class AddAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AdminUsernameTextBox = new System.Windows.Forms.TextBox();
            this.AdminPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CreateNewAdminAccountButton = new System.Windows.Forms.Button();
            this.Returnbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AdminUsernameTextBox
            // 
            this.AdminUsernameTextBox.Location = new System.Drawing.Point(159, 57);
            this.AdminUsernameTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.AdminUsernameTextBox.Name = "AdminUsernameTextBox";
            this.AdminUsernameTextBox.Size = new System.Drawing.Size(203, 22);
            this.AdminUsernameTextBox.TabIndex = 0;
            // 
            // AdminPasswordTextBox
            // 
            this.AdminPasswordTextBox.Location = new System.Drawing.Point(159, 113);
            this.AdminPasswordTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.AdminPasswordTextBox.Name = "AdminPasswordTextBox";
            this.AdminPasswordTextBox.Size = new System.Drawing.Size(203, 22);
            this.AdminPasswordTextBox.TabIndex = 1;
            this.AdminPasswordTextBox.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(73, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Username:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(73, 117);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password:";
            // 
            // CreateNewAdminAccountButton
            // 
            this.CreateNewAdminAccountButton.Location = new System.Drawing.Point(159, 170);
            this.CreateNewAdminAccountButton.Margin = new System.Windows.Forms.Padding(4);
            this.CreateNewAdminAccountButton.Name = "CreateNewAdminAccountButton";
            this.CreateNewAdminAccountButton.Size = new System.Drawing.Size(204, 28);
            this.CreateNewAdminAccountButton.TabIndex = 4;
            this.CreateNewAdminAccountButton.Text = "Create New Admin Account";
            this.CreateNewAdminAccountButton.UseVisualStyleBackColor = true;
            this.CreateNewAdminAccountButton.Click += new System.EventHandler(this.CreateNewAdminAccountButton_Click);
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(363, 226);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 34);
            this.Returnbutton.TabIndex = 37;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // AddAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(452, 274);
            this.Controls.Add(this.Returnbutton);
            this.Controls.Add(this.CreateNewAdminAccountButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AdminPasswordTextBox);
            this.Controls.Add(this.AdminUsernameTextBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AddAdmin";
            this.Text = "Add Admin Account";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox AdminUsernameTextBox;
        private System.Windows.Forms.TextBox AdminPasswordTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CreateNewAdminAccountButton;
        private System.Windows.Forms.Button Returnbutton;
    }
}