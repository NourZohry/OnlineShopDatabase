﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class AddAdmin : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public AddAdmin(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            controllerObj = new Controller();
        }



        private void AddManager_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void CreateNewAdminAccountButton_Click(object sender, EventArgs e)
        {
            if (AdminUsernameTextBox.Text == "" || AdminPasswordTextBox.Text == "")
            {
                MessageBox.Show("Please insert all values.");
            }
            else
            {
                int AID = controllerObj.GetHighestAID() + 1;
                int r = controllerObj.InsertAdmin(AdminUsernameTextBox.Text.ToString(), AdminPasswordTextBox.Text.ToString(),AID);
                if (r > 0)
                {
                    MessageBox.Show("Admin inserted successfully");

                }
                else
                    MessageBox.Show("Insertion Failed");
            }
        }
    }
}
