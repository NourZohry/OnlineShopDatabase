﻿namespace DBapplication
{
    partial class AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ProductNametextbox = new System.Windows.Forms.TextBox();
            this.Sizetextbox = new System.Windows.Forms.TextBox();
            this.Colortextbox = new System.Windows.Forms.TextBox();
            this.Pricetextbox = new System.Windows.Forms.TextBox();
            this.Weighttextbox = new System.Windows.Forms.TextBox();
            this.CategoryIDComboBox = new System.Windows.Forms.ComboBox();
            this.AddProductbutton = new System.Windows.Forms.Button();
            this.Returnbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Size";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Color";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 214);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Weight";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Category ID";
            // 
            // ProductNametextbox
            // 
            this.ProductNametextbox.Location = new System.Drawing.Point(143, 22);
            this.ProductNametextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ProductNametextbox.Name = "ProductNametextbox";
            this.ProductNametextbox.Size = new System.Drawing.Size(121, 22);
            this.ProductNametextbox.TabIndex = 8;
            // 
            // Sizetextbox
            // 
            this.Sizetextbox.Location = new System.Drawing.Point(143, 65);
            this.Sizetextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Sizetextbox.Name = "Sizetextbox";
            this.Sizetextbox.Size = new System.Drawing.Size(121, 22);
            this.Sizetextbox.TabIndex = 9;
            // 
            // Colortextbox
            // 
            this.Colortextbox.Location = new System.Drawing.Point(143, 112);
            this.Colortextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Colortextbox.Name = "Colortextbox";
            this.Colortextbox.Size = new System.Drawing.Size(121, 22);
            this.Colortextbox.TabIndex = 10;
            // 
            // Pricetextbox
            // 
            this.Pricetextbox.Location = new System.Drawing.Point(143, 162);
            this.Pricetextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Pricetextbox.Name = "Pricetextbox";
            this.Pricetextbox.Size = new System.Drawing.Size(121, 22);
            this.Pricetextbox.TabIndex = 11;
            // 
            // Weighttextbox
            // 
            this.Weighttextbox.Location = new System.Drawing.Point(143, 209);
            this.Weighttextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Weighttextbox.Name = "Weighttextbox";
            this.Weighttextbox.Size = new System.Drawing.Size(121, 22);
            this.Weighttextbox.TabIndex = 12;
            // 
            // CategoryIDComboBox
            // 
            this.CategoryIDComboBox.FormattingEnabled = true;
            this.CategoryIDComboBox.Location = new System.Drawing.Point(143, 261);
            this.CategoryIDComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CategoryIDComboBox.Name = "CategoryIDComboBox";
            this.CategoryIDComboBox.Size = new System.Drawing.Size(121, 24);
            this.CategoryIDComboBox.TabIndex = 13;
            // 
            // AddProductbutton
            // 
            this.AddProductbutton.Location = new System.Drawing.Point(200, 332);
            this.AddProductbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AddProductbutton.Name = "AddProductbutton";
            this.AddProductbutton.Size = new System.Drawing.Size(112, 32);
            this.AddProductbutton.TabIndex = 14;
            this.AddProductbutton.Text = "Add product";
            this.AddProductbutton.UseVisualStyleBackColor = true;
            this.AddProductbutton.Click += new System.EventHandler(this.AddProductbutton_Click);
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(328, 332);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 32);
            this.Returnbutton.TabIndex = 15;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // AddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(424, 379);
            this.Controls.Add(this.Returnbutton);
            this.Controls.Add(this.AddProductbutton);
            this.Controls.Add(this.CategoryIDComboBox);
            this.Controls.Add(this.Weighttextbox);
            this.Controls.Add(this.Pricetextbox);
            this.Controls.Add(this.Colortextbox);
            this.Controls.Add(this.Sizetextbox);
            this.Controls.Add(this.ProductNametextbox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AddProduct";
            this.Text = "Add Product";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddProduct_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox ProductNametextbox;
        private System.Windows.Forms.TextBox Sizetextbox;
        private System.Windows.Forms.TextBox Colortextbox;
        private System.Windows.Forms.TextBox Pricetextbox;
        private System.Windows.Forms.TextBox Weighttextbox;
        private System.Windows.Forms.ComboBox CategoryIDComboBox;
        private System.Windows.Forms.Button AddProductbutton;
        private System.Windows.Forms.Button Returnbutton;
    }
}