﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class AddProduct : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public AddProduct(string id, Form p)
        {
            InitializeComponent();
            controllerObj = new Controller();
            MyParent = p;
            MyParent.Hide();
            s = id;
            DataTable dt = controllerObj.SelectCatID();
            CategoryIDComboBox.DataSource = dt;
            CategoryIDComboBox.DisplayMember = "CatID";

        }
        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void AddProduct_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void AddProductbutton_Click(object sender, EventArgs e)
        {
            if (ProductNametextbox.Text == "" || Sizetextbox.Text == "" || Colortextbox.Text == "" || Pricetextbox.Text == "" || Weighttextbox.Text == "" || CategoryIDComboBox.Text == "")
            {
                MessageBox.Show("Please insert all values.");
            }
            else
            {

                int ProdID = controllerObj.GetHighestProdID() + 1;
                int r = controllerObj.AddProduct(ProdID,ProductNametextbox.Text, float.Parse(Sizetextbox.Text), Colortextbox.Text, float.Parse(Pricetextbox.Text), float.Parse(Weighttextbox.Text), Convert.ToInt32(CategoryIDComboBox.Text));
                if (r > 0)
                {
                    MessageBox.Show("Product inserted successfully");

                }
                else
                    MessageBox.Show("Insertion Failed");
            }
        }
    }
}
