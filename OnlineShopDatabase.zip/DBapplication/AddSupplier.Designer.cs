﻿namespace DBapplication
{
    partial class AddSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Returnbutton = new System.Windows.Forms.Button();
            this.AddSupplierbutton = new System.Windows.Forms.Button();
            this.URLtextbox = new System.Windows.Forms.TextBox();
            this.Emailtextbox = new System.Windows.Forms.TextBox();
            this.Phonetextbox = new System.Windows.Forms.TextBox();
            this.Addresstextbox = new System.Windows.Forms.TextBox();
            this.Suppliernametextbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(315, 254);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 32);
            this.Returnbutton.TabIndex = 31;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // AddSupplierbutton
            // 
            this.AddSupplierbutton.Location = new System.Drawing.Point(187, 254);
            this.AddSupplierbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AddSupplierbutton.Name = "AddSupplierbutton";
            this.AddSupplierbutton.Size = new System.Drawing.Size(112, 32);
            this.AddSupplierbutton.TabIndex = 30;
            this.AddSupplierbutton.Text = "Add supplier";
            this.AddSupplierbutton.UseVisualStyleBackColor = true;
            this.AddSupplierbutton.Click += new System.EventHandler(this.AddSupplierbutton_Click);
            // 
            // URLtextbox
            // 
            this.URLtextbox.Location = new System.Drawing.Point(132, 201);
            this.URLtextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.URLtextbox.Name = "URLtextbox";
            this.URLtextbox.Size = new System.Drawing.Size(121, 22);
            this.URLtextbox.TabIndex = 27;
            // 
            // Emailtextbox
            // 
            this.Emailtextbox.Location = new System.Drawing.Point(132, 151);
            this.Emailtextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Emailtextbox.Name = "Emailtextbox";
            this.Emailtextbox.Size = new System.Drawing.Size(121, 22);
            this.Emailtextbox.TabIndex = 26;
            // 
            // Phonetextbox
            // 
            this.Phonetextbox.Location = new System.Drawing.Point(132, 103);
            this.Phonetextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Phonetextbox.Name = "Phonetextbox";
            this.Phonetextbox.Size = new System.Drawing.Size(121, 22);
            this.Phonetextbox.TabIndex = 25;
            // 
            // Addresstextbox
            // 
            this.Addresstextbox.Location = new System.Drawing.Point(132, 62);
            this.Addresstextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Addresstextbox.Name = "Addresstextbox";
            this.Addresstextbox.Size = new System.Drawing.Size(121, 22);
            this.Addresstextbox.TabIndex = 24;
            // 
            // Suppliernametextbox
            // 
            this.Suppliernametextbox.Location = new System.Drawing.Point(132, 18);
            this.Suppliernametextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Suppliernametextbox.Name = "Suppliernametextbox";
            this.Suppliernametextbox.Size = new System.Drawing.Size(121, 22);
            this.Suppliernametextbox.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 206);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 17);
            this.label5.TabIndex = 20;
            this.label5.Text = "URL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 17);
            this.label4.TabIndex = 19;
            this.label4.Text = "Email";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 17);
            this.label3.TabIndex = 18;
            this.label3.Text = "Phone";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 17;
            this.label2.Text = "Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 16;
            this.label1.Text = "Supplier name";
            // 
            // AddSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(413, 319);
            this.Controls.Add(this.Returnbutton);
            this.Controls.Add(this.AddSupplierbutton);
            this.Controls.Add(this.URLtextbox);
            this.Controls.Add(this.Emailtextbox);
            this.Controls.Add(this.Phonetextbox);
            this.Controls.Add(this.Addresstextbox);
            this.Controls.Add(this.Suppliernametextbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AddSupplier";
            this.Text = "AddSupplier";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddSupplier_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Returnbutton;
        private System.Windows.Forms.Button AddSupplierbutton;
        private System.Windows.Forms.TextBox URLtextbox;
        private System.Windows.Forms.TextBox Emailtextbox;
        private System.Windows.Forms.TextBox Phonetextbox;
        private System.Windows.Forms.TextBox Addresstextbox;
        private System.Windows.Forms.TextBox Suppliernametextbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}