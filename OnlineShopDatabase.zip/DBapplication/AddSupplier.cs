﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class AddSupplier : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public AddSupplier(string id, Form p)
        {
            InitializeComponent();
            controllerObj = new Controller();
            MyParent = p;
            MyParent.Hide();
            s = id;

        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void AddSupplier_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void AddSupplierbutton_Click(object sender, EventArgs e)
        {
            if (Suppliernametextbox.Text == "" || Addresstextbox.Text == "" || Phonetextbox.Text == "" || Emailtextbox.Text == "" || URLtextbox.Text == "" )
            {
                MessageBox.Show("Please insert all values.");
            }
            else
            {
                
                int SID = controllerObj.GetHighestSID() + 1;
                int r = controllerObj.InsertSupplier(Suppliernametextbox.Text,SID, Addresstextbox.Text, Phonetextbox.Text, Emailtextbox.Text, URLtextbox.Text);
                if (r > 0)
                {
                    MessageBox.Show("Supplier inserted successfully");
                    
                }
                else
                    MessageBox.Show("Insertion Failed");
            }

        }
    }
}
