﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class AdminLogin : Form
    {
        Form MyParent;
        Controller controllerObj;
        public AdminLogin(Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (AdminUserNameTextBox.Text.ToString() == "" || AdminPasswordTextBox.Text.ToString() == "")
            {
                MessageBox.Show("Please enter a proper username and password.");
            }
            else
            {
                controllerObj = new Controller();
                int count = controllerObj.EmployeeCheckID(AdminUserNameTextBox.Text.ToString(), AdminPasswordTextBox.Text.ToString(), "Admins");
                if (count == 0)
                {
                    MessageBox.Show("Incorrect username or password.");
                }
                else
                {
                    int EID = controllerObj.EmployeeGetLoginID(AdminUserNameTextBox.Text.ToString(), AdminPasswordTextBox.Text.ToString(), "Admins");
                    MessageBox.Show("Sucessfully logged in.");
                    AdminPage CP = new AdminPage(AdminUserNameTextBox.Text, this);
                    CP.Show();

                    AdminUserNameTextBox.Text = null;
                    AdminPasswordTextBox.Text = null;
                }
            }
        }

        private void AdminLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }
    }
}
