﻿namespace DBapplication
{
    partial class AdminPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminPage));
            this.ReturnButton = new System.Windows.Forms.Button();
            this.ViewAllReviews = new System.Windows.Forms.Button();
            this.ViewAllProducts = new System.Windows.Forms.Button();
            this.ViewEmployees = new System.Windows.Forms.Button();
            this.ViewSuppliers = new System.Windows.Forms.Button();
            this.ManagerSettings = new System.Windows.Forms.Button();
            this.RemoveSupplier = new System.Windows.Forms.Button();
            this.SetDiscount = new System.Windows.Forms.Button();
            this.UpdateEmployee = new System.Windows.Forms.Button();
            this.RemoveEmployee = new System.Windows.Forms.Button();
            this.AddSupplier = new System.Windows.Forms.Button();
            this.UpdateSupplier = new System.Windows.Forms.Button();
            this.InsertEmployee = new System.Windows.Forms.Button();
            this.ViewCustomers = new System.Windows.Forms.Button();
            this.UpdateProduct = new System.Windows.Forms.Button();
            this.RemoveProduct = new System.Windows.Forms.Button();
            this.AddProduct = new System.Windows.Forms.Button();
            this.DeleteCustomer = new System.Windows.Forms.Button();
            this.ManagerStatButton = new System.Windows.Forms.Button();
            this.EmployeeStatButton = new System.Windows.Forms.Button();
            this.InsertManagerButton = new System.Windows.Forms.Button();
            this.ViewAllManagerButton = new System.Windows.Forms.Button();
            this.RemoveManagerButton = new System.Windows.Forms.Button();
            this.AddAdminAccountButton = new System.Windows.Forms.Button();
            this.CustomerReportbutton = new System.Windows.Forms.Button();
            this.ManagerReportbutton = new System.Windows.Forms.Button();
            this.EmployeeReportbutton = new System.Windows.Forms.Button();
            this.ProductReportbutton = new System.Windows.Forms.Button();
            this.ReviewReportbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ReturnButton
            // 
            this.ReturnButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnButton.Location = new System.Drawing.Point(792, 383);
            this.ReturnButton.Margin = new System.Windows.Forms.Padding(2);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(82, 31);
            this.ReturnButton.TabIndex = 13;
            this.ReturnButton.Text = "Log Out";
            this.ReturnButton.UseVisualStyleBackColor = true;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // ViewAllReviews
            // 
            this.ViewAllReviews.Location = new System.Drawing.Point(26, 334);
            this.ViewAllReviews.Name = "ViewAllReviews";
            this.ViewAllReviews.Size = new System.Drawing.Size(218, 23);
            this.ViewAllReviews.TabIndex = 29;
            this.ViewAllReviews.Text = "View All Reviews";
            this.ViewAllReviews.UseVisualStyleBackColor = true;
            this.ViewAllReviews.Click += new System.EventHandler(this.ViewAllReviews_Click);
            // 
            // ViewAllProducts
            // 
            this.ViewAllProducts.Location = new System.Drawing.Point(170, 379);
            this.ViewAllProducts.Name = "ViewAllProducts";
            this.ViewAllProducts.Size = new System.Drawing.Size(179, 23);
            this.ViewAllProducts.TabIndex = 28;
            this.ViewAllProducts.Text = "View All Products";
            this.ViewAllProducts.UseVisualStyleBackColor = true;
            this.ViewAllProducts.Click += new System.EventHandler(this.ViewAllProducts_Click);
            // 
            // ViewEmployees
            // 
            this.ViewEmployees.Location = new System.Drawing.Point(26, 115);
            this.ViewEmployees.Name = "ViewEmployees";
            this.ViewEmployees.Size = new System.Drawing.Size(218, 23);
            this.ViewEmployees.TabIndex = 27;
            this.ViewEmployees.Text = "View All Employees";
            this.ViewEmployees.UseVisualStyleBackColor = true;
            this.ViewEmployees.Click += new System.EventHandler(this.ViewEmployees_Click);
            // 
            // ViewSuppliers
            // 
            this.ViewSuppliers.Location = new System.Drawing.Point(268, 115);
            this.ViewSuppliers.Name = "ViewSuppliers";
            this.ViewSuppliers.Size = new System.Drawing.Size(218, 23);
            this.ViewSuppliers.TabIndex = 26;
            this.ViewSuppliers.Text = "View All Suppliers";
            this.ViewSuppliers.UseVisualStyleBackColor = true;
            this.ViewSuppliers.Click += new System.EventHandler(this.ViewSuppliers_Click);
            // 
            // ManagerSettings
            // 
            this.ManagerSettings.Location = new System.Drawing.Point(701, 383);
            this.ManagerSettings.Name = "ManagerSettings";
            this.ManagerSettings.Size = new System.Drawing.Size(75, 31);
            this.ManagerSettings.TabIndex = 25;
            this.ManagerSettings.Text = "Settings";
            this.ManagerSettings.UseVisualStyleBackColor = true;
            this.ManagerSettings.Click += new System.EventHandler(this.ManagerSettings_Click_1);
            // 
            // RemoveSupplier
            // 
            this.RemoveSupplier.Location = new System.Drawing.Point(268, 87);
            this.RemoveSupplier.Name = "RemoveSupplier";
            this.RemoveSupplier.Size = new System.Drawing.Size(218, 23);
            this.RemoveSupplier.TabIndex = 24;
            this.RemoveSupplier.Text = "Remove Suppliers";
            this.RemoveSupplier.UseVisualStyleBackColor = true;
            this.RemoveSupplier.Click += new System.EventHandler(this.RemoveSupplier_Click);
            // 
            // SetDiscount
            // 
            this.SetDiscount.Location = new System.Drawing.Point(26, 162);
            this.SetDiscount.Name = "SetDiscount";
            this.SetDiscount.Size = new System.Drawing.Size(218, 23);
            this.SetDiscount.TabIndex = 23;
            this.SetDiscount.Text = "Set Discount on a Product";
            this.SetDiscount.UseVisualStyleBackColor = true;
            this.SetDiscount.Click += new System.EventHandler(this.SetDiscount_Click);
            // 
            // UpdateEmployee
            // 
            this.UpdateEmployee.Location = new System.Drawing.Point(26, 58);
            this.UpdateEmployee.Name = "UpdateEmployee";
            this.UpdateEmployee.Size = new System.Drawing.Size(218, 23);
            this.UpdateEmployee.TabIndex = 22;
            this.UpdateEmployee.Text = "Update Employee Information";
            this.UpdateEmployee.UseVisualStyleBackColor = true;
            this.UpdateEmployee.Click += new System.EventHandler(this.UpdateEmployee_Click);
            // 
            // RemoveEmployee
            // 
            this.RemoveEmployee.Location = new System.Drawing.Point(26, 87);
            this.RemoveEmployee.Name = "RemoveEmployee";
            this.RemoveEmployee.Size = new System.Drawing.Size(218, 23);
            this.RemoveEmployee.TabIndex = 21;
            this.RemoveEmployee.Text = "Remove Employees";
            this.RemoveEmployee.UseVisualStyleBackColor = true;
            this.RemoveEmployee.Click += new System.EventHandler(this.RemoveEmployee_Click);
            // 
            // AddSupplier
            // 
            this.AddSupplier.Location = new System.Drawing.Point(268, 28);
            this.AddSupplier.Name = "AddSupplier";
            this.AddSupplier.Size = new System.Drawing.Size(218, 23);
            this.AddSupplier.TabIndex = 20;
            this.AddSupplier.Text = "Add New Suppliers";
            this.AddSupplier.UseVisualStyleBackColor = true;
            this.AddSupplier.Click += new System.EventHandler(this.AddSupplier_Click);
            // 
            // UpdateSupplier
            // 
            this.UpdateSupplier.Location = new System.Drawing.Point(268, 58);
            this.UpdateSupplier.Name = "UpdateSupplier";
            this.UpdateSupplier.Size = new System.Drawing.Size(218, 23);
            this.UpdateSupplier.TabIndex = 19;
            this.UpdateSupplier.Text = "Update Supplier Information";
            this.UpdateSupplier.UseVisualStyleBackColor = true;
            this.UpdateSupplier.Click += new System.EventHandler(this.UpdateSupplier_Click);
            // 
            // InsertEmployee
            // 
            this.InsertEmployee.Location = new System.Drawing.Point(26, 28);
            this.InsertEmployee.Name = "InsertEmployee";
            this.InsertEmployee.Size = new System.Drawing.Size(218, 23);
            this.InsertEmployee.TabIndex = 18;
            this.InsertEmployee.Text = "Add New Employees";
            this.InsertEmployee.UseVisualStyleBackColor = true;
            this.InsertEmployee.Click += new System.EventHandler(this.InsertEmployee_Click);
            // 
            // ViewCustomers
            // 
            this.ViewCustomers.Location = new System.Drawing.Point(26, 304);
            this.ViewCustomers.Name = "ViewCustomers";
            this.ViewCustomers.Size = new System.Drawing.Size(218, 23);
            this.ViewCustomers.TabIndex = 34;
            this.ViewCustomers.Text = "View All Customers";
            this.ViewCustomers.UseVisualStyleBackColor = true;
            this.ViewCustomers.Click += new System.EventHandler(this.ViewCustomers_Click);
            // 
            // UpdateProduct
            // 
            this.UpdateProduct.Location = new System.Drawing.Point(268, 304);
            this.UpdateProduct.Name = "UpdateProduct";
            this.UpdateProduct.Size = new System.Drawing.Size(218, 23);
            this.UpdateProduct.TabIndex = 33;
            this.UpdateProduct.Text = "Update Product Information";
            this.UpdateProduct.UseVisualStyleBackColor = true;
            this.UpdateProduct.Click += new System.EventHandler(this.UpdateProduct_Click);
            // 
            // RemoveProduct
            // 
            this.RemoveProduct.Location = new System.Drawing.Point(268, 333);
            this.RemoveProduct.Name = "RemoveProduct";
            this.RemoveProduct.Size = new System.Drawing.Size(218, 23);
            this.RemoveProduct.TabIndex = 32;
            this.RemoveProduct.Text = "Remove a Product";
            this.RemoveProduct.UseVisualStyleBackColor = true;
            this.RemoveProduct.Click += new System.EventHandler(this.RemoveProduct_Click);
            // 
            // AddProduct
            // 
            this.AddProduct.Location = new System.Drawing.Point(268, 274);
            this.AddProduct.Name = "AddProduct";
            this.AddProduct.Size = new System.Drawing.Size(218, 23);
            this.AddProduct.TabIndex = 31;
            this.AddProduct.Text = "Add a Product to Sell";
            this.AddProduct.UseVisualStyleBackColor = true;
            this.AddProduct.Click += new System.EventHandler(this.AddProduct_Click);
            // 
            // DeleteCustomer
            // 
            this.DeleteCustomer.Location = new System.Drawing.Point(26, 274);
            this.DeleteCustomer.Name = "DeleteCustomer";
            this.DeleteCustomer.Size = new System.Drawing.Size(218, 23);
            this.DeleteCustomer.TabIndex = 30;
            this.DeleteCustomer.Text = "Delete a Customer\'s Account";
            this.DeleteCustomer.UseVisualStyleBackColor = true;
            this.DeleteCustomer.Click += new System.EventHandler(this.DeleteCustomer_Click);
            // 
            // ManagerStatButton
            // 
            this.ManagerStatButton.Location = new System.Drawing.Point(26, 191);
            this.ManagerStatButton.Margin = new System.Windows.Forms.Padding(2);
            this.ManagerStatButton.Name = "ManagerStatButton";
            this.ManagerStatButton.Size = new System.Drawing.Size(218, 23);
            this.ManagerStatButton.TabIndex = 35;
            this.ManagerStatButton.Text = "Manager Statistics";
            this.ManagerStatButton.UseVisualStyleBackColor = true;
            this.ManagerStatButton.Click += new System.EventHandler(this.ManagerStatButton_Click);
            // 
            // EmployeeStatButton
            // 
            this.EmployeeStatButton.Location = new System.Drawing.Point(26, 218);
            this.EmployeeStatButton.Margin = new System.Windows.Forms.Padding(2);
            this.EmployeeStatButton.Name = "EmployeeStatButton";
            this.EmployeeStatButton.Size = new System.Drawing.Size(218, 23);
            this.EmployeeStatButton.TabIndex = 36;
            this.EmployeeStatButton.Text = "Employee Statistics";
            this.EmployeeStatButton.UseVisualStyleBackColor = true;
            this.EmployeeStatButton.Click += new System.EventHandler(this.EmployeeStatButton_Click);
            // 
            // InsertManagerButton
            // 
            this.InsertManagerButton.Location = new System.Drawing.Point(268, 162);
            this.InsertManagerButton.Margin = new System.Windows.Forms.Padding(2);
            this.InsertManagerButton.Name = "InsertManagerButton";
            this.InsertManagerButton.Size = new System.Drawing.Size(218, 23);
            this.InsertManagerButton.TabIndex = 37;
            this.InsertManagerButton.Text = "Add Manager";
            this.InsertManagerButton.UseVisualStyleBackColor = true;
            this.InsertManagerButton.Click += new System.EventHandler(this.InsertManagerButton_Click);
            // 
            // ViewAllManagerButton
            // 
            this.ViewAllManagerButton.Location = new System.Drawing.Point(268, 218);
            this.ViewAllManagerButton.Name = "ViewAllManagerButton";
            this.ViewAllManagerButton.Size = new System.Drawing.Size(218, 23);
            this.ViewAllManagerButton.TabIndex = 38;
            this.ViewAllManagerButton.Text = "View All Managers";
            this.ViewAllManagerButton.UseVisualStyleBackColor = true;
            this.ViewAllManagerButton.Click += new System.EventHandler(this.ViewAllManagerButton_Click);
            // 
            // RemoveManagerButton
            // 
            this.RemoveManagerButton.Location = new System.Drawing.Point(268, 190);
            this.RemoveManagerButton.Name = "RemoveManagerButton";
            this.RemoveManagerButton.Size = new System.Drawing.Size(218, 23);
            this.RemoveManagerButton.TabIndex = 39;
            this.RemoveManagerButton.Text = "Remove Managers";
            this.RemoveManagerButton.UseVisualStyleBackColor = true;
            this.RemoveManagerButton.Click += new System.EventHandler(this.RemoveManagerButton_Click);
            // 
            // AddAdminAccountButton
            // 
            this.AddAdminAccountButton.Location = new System.Drawing.Point(588, 274);
            this.AddAdminAccountButton.Name = "AddAdminAccountButton";
            this.AddAdminAccountButton.Size = new System.Drawing.Size(179, 57);
            this.AddAdminAccountButton.TabIndex = 40;
            this.AddAdminAccountButton.Text = "Add Admin Account";
            this.AddAdminAccountButton.UseVisualStyleBackColor = true;
            this.AddAdminAccountButton.Click += new System.EventHandler(this.AddAdminAccountButton_Click);
            // 
            // CustomerReportbutton
            // 
            this.CustomerReportbutton.Location = new System.Drawing.Point(588, 58);
            this.CustomerReportbutton.Name = "CustomerReportbutton";
            this.CustomerReportbutton.Size = new System.Drawing.Size(126, 23);
            this.CustomerReportbutton.TabIndex = 41;
            this.CustomerReportbutton.Text = "Print Customer Report";
            this.CustomerReportbutton.UseVisualStyleBackColor = true;
            this.CustomerReportbutton.Click += new System.EventHandler(this.CustomerReportbutton_Click);
            // 
            // ManagerReportbutton
            // 
            this.ManagerReportbutton.Location = new System.Drawing.Point(588, 98);
            this.ManagerReportbutton.Name = "ManagerReportbutton";
            this.ManagerReportbutton.Size = new System.Drawing.Size(126, 23);
            this.ManagerReportbutton.TabIndex = 42;
            this.ManagerReportbutton.Text = "Print Manager Report";
            this.ManagerReportbutton.UseVisualStyleBackColor = true;
            this.ManagerReportbutton.Click += new System.EventHandler(this.ManagerReportbutton_Click);
            // 
            // EmployeeReportbutton
            // 
            this.EmployeeReportbutton.Location = new System.Drawing.Point(588, 137);
            this.EmployeeReportbutton.Name = "EmployeeReportbutton";
            this.EmployeeReportbutton.Size = new System.Drawing.Size(126, 23);
            this.EmployeeReportbutton.TabIndex = 43;
            this.EmployeeReportbutton.Text = "Print Employee Report";
            this.EmployeeReportbutton.UseVisualStyleBackColor = true;
            this.EmployeeReportbutton.Click += new System.EventHandler(this.EmployeeReportbutton_Click);
            // 
            // ProductReportbutton
            // 
            this.ProductReportbutton.Location = new System.Drawing.Point(588, 183);
            this.ProductReportbutton.Name = "ProductReportbutton";
            this.ProductReportbutton.Size = new System.Drawing.Size(126, 23);
            this.ProductReportbutton.TabIndex = 44;
            this.ProductReportbutton.Text = "Print Product Report";
            this.ProductReportbutton.UseVisualStyleBackColor = true;
            this.ProductReportbutton.Click += new System.EventHandler(this.ProductReportbutton_Click);
            // 
            // ReviewReportbutton
            // 
            this.ReviewReportbutton.Location = new System.Drawing.Point(588, 229);
            this.ReviewReportbutton.Name = "ReviewReportbutton";
            this.ReviewReportbutton.Size = new System.Drawing.Size(126, 23);
            this.ReviewReportbutton.TabIndex = 45;
            this.ReviewReportbutton.Text = "Print Review Report";
            this.ReviewReportbutton.UseVisualStyleBackColor = true;
            this.ReviewReportbutton.Click += new System.EventHandler(this.ReviewReportbutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(749, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 43);
            this.label1.TabIndex = 46;
            this.label1.Text = "Admin";
            // 
            // AdminPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(884, 424);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ReviewReportbutton);
            this.Controls.Add(this.ProductReportbutton);
            this.Controls.Add(this.EmployeeReportbutton);
            this.Controls.Add(this.ManagerReportbutton);
            this.Controls.Add(this.CustomerReportbutton);
            this.Controls.Add(this.AddAdminAccountButton);
            this.Controls.Add(this.RemoveManagerButton);
            this.Controls.Add(this.ViewAllManagerButton);
            this.Controls.Add(this.InsertManagerButton);
            this.Controls.Add(this.EmployeeStatButton);
            this.Controls.Add(this.ManagerStatButton);
            this.Controls.Add(this.ViewCustomers);
            this.Controls.Add(this.UpdateProduct);
            this.Controls.Add(this.RemoveProduct);
            this.Controls.Add(this.AddProduct);
            this.Controls.Add(this.DeleteCustomer);
            this.Controls.Add(this.ViewAllReviews);
            this.Controls.Add(this.ViewAllProducts);
            this.Controls.Add(this.ViewEmployees);
            this.Controls.Add(this.ViewSuppliers);
            this.Controls.Add(this.ManagerSettings);
            this.Controls.Add(this.RemoveSupplier);
            this.Controls.Add(this.SetDiscount);
            this.Controls.Add(this.UpdateEmployee);
            this.Controls.Add(this.RemoveEmployee);
            this.Controls.Add(this.AddSupplier);
            this.Controls.Add(this.UpdateSupplier);
            this.Controls.Add(this.InsertEmployee);
            this.Controls.Add(this.ReturnButton);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AdminPage";
            this.Text = "AdminPage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AdminPage_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ReturnButton;
        private System.Windows.Forms.Button ViewAllReviews;
        private System.Windows.Forms.Button ViewAllProducts;
        private System.Windows.Forms.Button ViewEmployees;
        private System.Windows.Forms.Button ViewSuppliers;
        private System.Windows.Forms.Button ManagerSettings;
        private System.Windows.Forms.Button RemoveSupplier;
        private System.Windows.Forms.Button SetDiscount;
        private System.Windows.Forms.Button UpdateEmployee;
        private System.Windows.Forms.Button RemoveEmployee;
        private System.Windows.Forms.Button AddSupplier;
        private System.Windows.Forms.Button UpdateSupplier;
        private System.Windows.Forms.Button InsertEmployee;
        private System.Windows.Forms.Button ViewCustomers;
        private System.Windows.Forms.Button UpdateProduct;
        private System.Windows.Forms.Button RemoveProduct;
        private System.Windows.Forms.Button AddProduct;
        private System.Windows.Forms.Button DeleteCustomer;
        private System.Windows.Forms.Button ManagerStatButton;
        private System.Windows.Forms.Button EmployeeStatButton;
        private System.Windows.Forms.Button InsertManagerButton;
        private System.Windows.Forms.Button ViewAllManagerButton;
        private System.Windows.Forms.Button RemoveManagerButton;
        private System.Windows.Forms.Button AddAdminAccountButton;
        private System.Windows.Forms.Button CustomerReportbutton;
        private System.Windows.Forms.Button ManagerReportbutton;
        private System.Windows.Forms.Button EmployeeReportbutton;
        private System.Windows.Forms.Button ProductReportbutton;
        private System.Windows.Forms.Button ReviewReportbutton;
        private System.Windows.Forms.Label label1;
    }
}