﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class AdminPage : Form
    {
        Form MyParent;
        string s;
        public AdminPage(string id,Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void AdminPage_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void InsertEmployee_Click(object sender, EventArgs e)
        {
            InsertEmployee IE = new InsertEmployee(s, this);
            IE.Show();
        }

        private void UpdateEmployee_Click(object sender, EventArgs e)
        {
            UpdateEmployee UE = new UpdateEmployee(s, this);
            UE.Show();
        }

        private void RemoveEmployee_Click(object sender, EventArgs e)
        {
            RemoveEmployee RE = new RemoveEmployee(s, this);
            RE.Show();
        }

        private void ViewEmployees_Click(object sender, EventArgs e)
        {
            ViewEmployees VE = new ViewEmployees(s, this);
            VE.Show();
        }

        private void SetDiscount_Click(object sender, EventArgs e)
        {
            SetDiscount SD = new SetDiscount(s, this);
            SD.Show();
        }

        private void ViewAllProducts_Click(object sender, EventArgs e)
        {
            ViewAllProducts VAP = new ViewAllProducts(s, this);
            VAP.Show();
        }

        private void ViewAllReviews_Click(object sender, EventArgs e)
        {
            ViewAllReviews VAR = new ViewAllReviews(s, this);
            VAR.Show();
        }

        private void AddSupplier_Click(object sender, EventArgs e)
        {
            AddSupplier AS = new AddSupplier(s, this);
            AS.Show();
        }

        private void UpdateSupplier_Click(object sender, EventArgs e)
        {
            UpdateSupplier US = new UpdateSupplier(s, this);
            US.Show();
        }

        private void RemoveSupplier_Click(object sender, EventArgs e)
        {
            RemoveSupplier RS = new RemoveSupplier(s, this);
            RS.Show();
        }

        private void ViewSuppliers_Click(object sender, EventArgs e)
        {
            ViewSuppliers VS = new ViewSuppliers(s, this);
            VS.Show();
        }

        private void ManagerSettings_Click(object sender, EventArgs e)
        {
            ManagerSettings MS = new ManagerSettings(s, this);
            MS.Show();
        }

        private void DeleteCustomer_Click(object sender, EventArgs e)
        {
            DeleteCustomer DC = new DeleteCustomer(s, this);
            DC.Show();
        }

      

        private void AddProduct_Click(object sender, EventArgs e)
        {
            AddProduct AP = new AddProduct(s, this);
            AP.Show();
        }

        private void UpdateProduct_Click(object sender, EventArgs e)
        {
            UpdateProduct UP = new UpdateProduct(s, this);
            UP.Show();
        }

        private void RemoveProduct_Click(object sender, EventArgs e)
        {
            RemoveProduct RP = new RemoveProduct(s, this);
            RP.Show();
        }

       

        private void ViewCustomers_Click(object sender, EventArgs e)
        {
            ViewCustomers VC = new ViewCustomers(s, this);
            VC.Show();
        }

        private void ManagerStatButton_Click(object sender, EventArgs e)
        {
            MangStat MS = new MangStat(s, this);
            MS.Show();
        }

        private void EmployeeStatButton_Click(object sender, EventArgs e)
        {
            EmpStat ES = new EmpStat(s, this);
            ES.Show();
        }

        private void InsertManagerButton_Click(object sender, EventArgs e)
        {
            AddManager AM = new AddManager(s, this);
            AM.Show();
        }

        private void RemoveManagerButton_Click(object sender, EventArgs e)
        {
            RemoveManager RM = new RemoveManager(s, this);
            RM.Show();
        }

        private void AddAdminAccountButton_Click(object sender, EventArgs e)
        {
            AddAdmin AM = new AddAdmin(s, this);
            AM.Show();
        }

        private void ManagerSettings_Click_1(object sender, EventArgs e)
        {
            AdminSettings AS = new AdminSettings(s, this);
            AS.Show();
        }

        private void ViewAllManagerButton_Click(object sender, EventArgs e)
        {
            ViewAllManagers VAM = new ViewAllManagers(s, this);
            VAM.Show();
        }

        private void CustomerReportbutton_Click(object sender, EventArgs e)
        {
            PrintCustomerReport PCR = new PrintCustomerReport(s, this);
            PCR.Show();
        }

        private void ManagerReportbutton_Click(object sender, EventArgs e)
        {
            PrintManagerReport PMR = new PrintManagerReport(s, this);
            PMR.Show();
        }

        private void EmployeeReportbutton_Click(object sender, EventArgs e)
        {
            PrintEmployeeReport PER = new PrintEmployeeReport(s, this);
            PER.Show();
        }

        private void ProductReportbutton_Click(object sender, EventArgs e)
        {
            PrintProductReport PPR = new PrintProductReport(s, this);
            PPR.Show();
        }

        private void ReviewReportbutton_Click(object sender, EventArgs e)
        {
            PrintReviewReport PPR = new PrintReviewReport(s, this);
            PPR.Show();
        }
    }
}
