﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class ConfirmOrder : Form
    {
        Controller controllerObj;
        Form MyParent;
        string s;
        public ConfirmOrder(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;

            controllerObj = new Controller();

            int CID = controllerObj.GetCustomerID(s);
            if (controllerObj.CheckOrdID(CID) > 0)
                if (controllerObj.CheckProductCount(CID) > 0)
                {
                    DataTable dt = controllerObj.GetCurrentOrder(CID);
                    OrderDataGrid.DataSource = dt;
                    OrderDataGrid.Columns["ProdID"].Visible = false;
                    OrderDataGrid.Refresh();
                }
            //else
            //{
            //    MessageBox.Show("You have no products in your order.");
            //}

        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void ConfirmOrderButton_Click(object sender, EventArgs e)
        {
            int CID = controllerObj.GetCustomerID(s);
            if (controllerObj.CheckOrdID(controllerObj.GetCustomerID(s)) == 0)
            {
                MessageBox.Show("You have no products in your order.");
                return;
            }
            else if (controllerObj.CheckProductCount(CID) == 0)
            {
                MessageBox.Show("You have no products in your order.");
                return;
            }
            else if (controllerObj.CheckAddress(CID) == 0)
            {
                MessageBox.Show("Please edit your address from Settings.");
                return;
            }
            else if (comboBox1.Text == "")
            {
                MessageBox.Show("Please select a payment method first.");
                return;
            }
            else if (comboBox1.Text == "Credit" & controllerObj.CheckCredit(CID) == 0)
            {
                MessageBox.Show("Please edit your credit card from Settings.");
                return;
            }
            /*
            else if (controllerObj.CheckProductCount(CID) == 0)
            {
                MessageBox.Show("You have no products in your order.");
                return;
            }
            */
            else
            {
                int OrdID = controllerObj.GetOrdID(CID);
                int r = controllerObj.ConfirmOrder(OrdID, comboBox1.Text);
                if (r > 0)
                {
                    MessageBox.Show("Thank you for ordering!");
                    controllerObj.CreateShippedItems(OrdID);
                    OrderDataGrid.DataSource = null;
                    OrderDataGrid.Refresh();
                }
                else
                {
                    MessageBox.Show("Failed to confirm order.");
                }
            }
        }

        private void CancelOrderButton_Click(object sender, EventArgs e)
        {
            int CID = controllerObj.GetCustomerID(s);
            if (controllerObj.CheckOrdID(controllerObj.GetCustomerID(s)) == 0)
            {
                MessageBox.Show("You have no products in your order.");
                return;
            }
            else if (controllerObj.CheckProductCount(CID) == 0)
            {
                MessageBox.Show("You have no products in your order.");
                return;
            }
            /*
            else if (controllerObj.CheckProductCount(CID) == 0)
            {
                MessageBox.Show("You have no products in your order.");
                return;
            }
            */
            else
            {
                int OrdID = controllerObj.GetOrdID(CID);
                int r = controllerObj.DeleteOrder(OrdID);
                OrderDataGrid.DataSource = null;
                if (r > 0)
                {
                    MessageBox.Show("Order is successfully cancelled.");
                }
                else
                {
                    MessageBox.Show("Failed to cancel order.");
                }
            }
        }

        private void OrderDataGrid_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void OrderDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void OrderDataGrid_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex < 0)
                return;
            //MessageBox.Show(ProductDataGrid.Rows[e.RowIndex].Cells[0].Value.ToString());
            string ProdID = OrderDataGrid.Rows[e.RowIndex].Cells[0].Value.ToString();
            controllerObj = new Controller();

            int CID = controllerObj.GetCustomerID(s);
            //int Check = controllerObj.CheckOrdID(CID); //0 -> no order exists, make new order

            int OrdID = controllerObj.GetOrdID(CID);
            int r = controllerObj.RemoveProductFromOrder(ProdID);
            if (r > 0)
            {
                MessageBox.Show("Removed " + OrderDataGrid.Rows[e.RowIndex].Cells[1].Value.ToString() + " from your Order!");
                if (controllerObj.CheckProductCount(CID) > 0)
                {
                    DataTable dt = controllerObj.GetCurrentOrder(CID);
                    OrderDataGrid.DataSource = dt;
                    OrderDataGrid.Columns["ProdID"].Visible = false;
                    OrderDataGrid.Refresh();
                }
                else if (controllerObj.CheckProductCount(CID) == 0)
                {
                    DataTable dt = controllerObj.GetCurrentOrder(CID);
                    OrderDataGrid.DataSource = dt;
                    //OrderDataGrid.Columns["ProdID"].Visible = false;
                    OrderDataGrid.Refresh();
                }

            }
            else
            {
                MessageBox.Show("Please use the 'Cancel Order' button.");
            }
        }
    }
}
