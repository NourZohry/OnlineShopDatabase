﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace DBapplication
{
    public class Controller
    {
        DBManager dbMan;
        DBmanagerPro dbManPro;
        public Controller()
        {
            dbMan = new DBManager();
            dbManPro = new DBmanagerPro();
        }


        public void TerminateConnection()
        {
            dbMan.CloseConnection();
        }

        public int EmployeeCheckID(string username, string password, string usertype)
        {
            string query;
            if (usertype == "Employee")
            {
                query = "SELECT COUNT(EID) FROM Employee WHERE username = '" + username + "' AND password = HASHBYTES('MD5','" + password + "');";
            }
            else if (usertype == "Manager")
            {
                query = "SELECT COUNT(MID) FROM Manager WHERE username = '" + username + "' AND password = HASHBYTES('MD5','" + password + "');";
            }
            else if (usertype == "Customer")
            {
                query = "SELECT COUNT(CID) FROM Customer WHERE username = '" + username + "' AND password = HASHBYTES('MD5','" + password + "');";
            }
            else
            {
                query = "SELECT COUNT(AID) FROM Admins WHERE username = '" + username + "' AND password = HASHBYTES('MD5','" + password + "');";
            }
            return (int)dbMan.ExecuteScalar(query);
        }
        public int EmployeeGetLoginID(string username, string password, string usertype)
        {
            string query;
            if (usertype == "Employee")
            {
                query = "SELECT EID FROM Employee WHERE username = '" + username + "' AND password = HASHBYTES('MD5','" + password + "');";
            }
            else if (usertype == "Manager")
            {
                query = "SELECT MID FROM Manager WHERE username = '" + username + "' AND password = HASHBYTES('MD5','" + password + "');";
            }
            else if (usertype == "Customer")
            {
                query = "SELECT CID FROM Customer WHERE username = '" + username + "' AND password = HASHBYTES('MD5','" + password + "');";
            }
            else
            {
                query = "SELECT AID FROM Admins WHERE username = '" + username + "' AND password = HASHBYTES('MD5','" + password + "');";
            }
            return (int)dbMan.ExecuteScalar(query);
        }
        public int GetHighestCID()
        {
            string query = "SELECT MAX(CID) FROM Customer;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int InsertCustomer(int CID, string Fname, string Minit, string LName, string Email, string Username, string Password)
        {
            string StoredProcedureName = StoredPro.InsertCustomer;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            Parameters.Add("@CID", CID);
            Parameters.Add("@Fname", Fname);
            Parameters.Add("@Minit", Minit);
            Parameters.Add("@LName", LName);
            Parameters.Add("@Email", Email);
            Parameters.Add("@Username", Username);
            Parameters.Add("@Password", Password);
            return dbManPro.ExecuteNonQuery(StoredProcedureName, Parameters);
        }
        public int GetHighestEID()
        {
            string query = "SELECT MAX(EID) FROM Employee;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int InsertEmployee(string Fname, string Minit, string LName, int EID, int Salary, string Sex, string Bdate, string Username, string Password)
        {
            string StoredProcedureName = StoredPro.InsertEmployee;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            Parameters.Add("@Fname", Fname);
            Parameters.Add("@Minit", Minit);
            Parameters.Add("@LName", LName);
            Parameters.Add("@EID", EID);
            Parameters.Add("@Salary", Salary);
            Parameters.Add("@Sex", Sex);
            Parameters.Add("@Bdate", Bdate);
            Parameters.Add("@Username", Username);
            Parameters.Add("@Password", Password);
            return dbManPro.ExecuteNonQuery(StoredProcedureName, Parameters);
        }
        public int GetHighestMID()
        {
            string query = "SELECT MAX(MID) FROM Manager;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int InsertManager(string Fname, string Minit, string LName, int MID, int Salary, string Sex, string Bdate, string Username, string Password)
        {
            string StoredProcedureName = StoredPro.InsertManager;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            Parameters.Add("@Fname", Fname);
            Parameters.Add("@Minit", Minit);
            Parameters.Add("@LName", LName);
            Parameters.Add("@MID", MID);
            Parameters.Add("@Salary", Salary);
            Parameters.Add("@Sex", Sex);
            Parameters.Add("@Bdate", Bdate);
            Parameters.Add("@Username", Username);
            Parameters.Add("@Password", Password);
            return dbManPro.ExecuteNonQuery(StoredProcedureName, Parameters);
        }

        public int GetHighestProdID()
        {
            string query = "SELECT MAX(ProdID) FROM Product;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public DataTable SelectCatID()
        {
            string query = "SELECT CatID FROM Category;";
            return dbMan.ExecuteReader(query);
        }
        public int AddProduct(int ProdID, string ProdName, float Size, string Color, float Price, float Weight, int CatID)
        {
            string StoredProcedureName = StoredPro.AddProduct;
            Dictionary<string, object> Parameters = new Dictionary<string, object>();
            Parameters.Add("@ProdID", ProdID);
            Parameters.Add("@ProdName", ProdName);
            Parameters.Add("@Size", Size);
            Parameters.Add("@Color", Color);
            Parameters.Add("@Price", Price);
            Parameters.Add("@Weight", Weight);
            Parameters.Add("@CatID", CatID);
            return dbManPro.ExecuteNonQuery(StoredProcedureName, Parameters);
        }
        public int GetHighestSID()
        {
            string query = "SELECT MAX(SID) FROM Supplier;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int InsertSupplier(string Name, int SID, string Address, string Phone, string Email, string URL)
        {
            string query = "INSERT INTO Supplier (Name, SID, Address, Phone, Email, URL)" +
                            "Values ('" + Name + "','" + SID + "','" + Address + "','" + Phone + "','" + Email + "','" + URL + "');";
            return dbMan.ExecuteNonQuery(query);
        }
        public DataTable SelectSID()
        {
            string query = "SELECT Name FROM Supplier;";
            return dbMan.ExecuteReader(query);
        }
        public int UpdateSupplierAddress(string Name, string Address)
        {
            string query = "UPDATE Supplier SET Address='" + Address + "' WHERE Name='" + Name + "';";
            return dbMan.ExecuteNonQuery(query);
        }
        public int UpdateSupplierPhone(string Name, string Phone)
        {
            string query = "UPDATE Supplier SET Phone='" + Phone + "' WHERE Name='" + Name + "';";
            return dbMan.ExecuteNonQuery(query);
        }
        public DataTable ViewAllProducts()
        {
            string StoredProcedureName = StoredPro.ViewAllProducts;
            return dbManPro.ExecuteReader(StoredProcedureName, null);
        }
        public int DeleteSupplier(string Name)
        {
            string query = "DELETE FROM Supplier WHERE Name='" + Name + "';";
            return dbMan.ExecuteNonQuery(query);
        }
        public DataTable ViewAllSuppliers()
        {
            string StoredProcedureName = StoredPro.ViewAllSuppliers;
            return dbManPro.ExecuteReader(StoredProcedureName, null);
        }
        public DataTable ViewAllReviews()
        {
            string StoredProcedureName = StoredPro.ViewAllReviews;
            return dbManPro.ExecuteReader(StoredProcedureName, null);
        }
        public DataTable ViewAllEmployees()
        {
            string StoredProcedureName = StoredPro.ViewAllEmployees;
            return dbManPro.ExecuteReader(StoredProcedureName, null);
        }
        public DataTable SelectProdID()
        {
            string query = "SELECT ProdID FROM Product;";
            return dbMan.ExecuteReader(query);
        }


        public int ProductDiscount(string ProdName, int Discount)
        {
            string query = "UPDATE Product SET Discount='" + Discount + "' WHERE ProdName='" + ProdName + "';";
            return dbMan.ExecuteNonQuery(query);
        }

        public DataTable SelectCustomers()
        {
            string query = "SELECT * FROM Customer;";
            return dbMan.ExecuteReader(query);
        }

        public string SelectProdName(string ProdID)
        {
            string query = "SELECT ProdName FROM Product WHERE ProdID='" + ProdID + "';";
            return Convert.ToString(dbMan.ExecuteReader(query));
        }


        public DataTable SelectProducts()
        {
            string query = "SELECT * FROM Product;";
            return dbMan.ExecuteReader(query);
        }

        public int DeleteCustomer(string Username)
        {
            string query = "DELETE FROM Customer WHERE Username='" + Username + "';";
            return dbMan.ExecuteNonQuery(query);
        }


        public int DeleteProduct(string ProdName)
        {
            string query = "DELETE FROM Product WHERE ProdName='" + ProdName + "';";
            return dbMan.ExecuteNonQuery(query);
        }

        public int UpdatePrice(int Price, string ProdName)
        {
            string query = "UPDATE Product SET Price='" + Price + "' " +
                "WHERE ProdName='" + ProdName + "';";
            return dbMan.ExecuteNonQuery(query);
        }

        public DataTable SelectEmpEID()
        {
            string query = "SELECT Username FROM Employee;";
            return dbMan.ExecuteReader(query);
        }
        public DataTable SelectEmpUsername()
        {
            string query = "SELECT Username FROM Employee;";
            return dbMan.ExecuteReader(query);
        }

        public int DeleteEmployee(string Username)
        {
            string query = "DELETE FROM Employee WHERE Username ='" + Username + "';";
            return dbMan.ExecuteNonQuery(query);
        }
        public int DeleteManager(string Username)
        {
            string query = "DELETE FROM Manager WHERE Username ='" + Username + "';";
            return dbMan.ExecuteNonQuery(query);
        }
        public int UpdateEmployee(int Salary, string Username)
        {
            string query = "UPDATE Employee SET Salary ='" + Salary + "' where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }

        public int MangChangePassword(string Password, string Username)
        {
            string query = "UPDATE Manager SET Password = HASHBYTES('MD5','" + Password + "')  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }

        public int MangCheckPassword(string Password)
        {
            string query = "SELECT Password FROM Manager where Password = HASHBYTES('MD5','" + Password + "');";
            object p = dbMan.ExecuteScalar(query);
            if (p == null)
                return 0;
            else
                return 1;
        }

        public int EmpChangePassword(string Password, string Username)
        {
            string query = "UPDATE Employee SET Password = HASHBYTES('MD5','" + Password + "')  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }

        public int EmpCheckPassword(string Password)
        {
            string query = "SELECT Password FROM Employee where Password = HASHBYTES('MD5','" + Password + "');";
            object p = dbMan.ExecuteScalar(query);
            if (p == null)
                return 0;
            else
                return 1;
        }
        public int CustChangePassword(string Password, string Username)
        {
            string query = "UPDATE Customer SET Password = HASHBYTES('MD5','" + Password + "')  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }

        public int CustCheckPassword(string Password)
        {
            string query = "SELECT Password FROM Customer where Password = HASHBYTES('MD5','" + Password + "');";
            object p = dbMan.ExecuteScalar(query);
            if (p == null)
                return 0;
            else
                return 1;
        }


        public DataTable SelectCategories()
        {
            string query = "SELECT CatName FROM Category;";
            return dbMan.ExecuteReader(query);
        }
        public DataTable GetCategories(string CatName)
        {
            //string query = "SELECT Product.ProdID, Product.ProdName AS Name,Product.Size,Product.Color,Product.Price,Product.Discount,Product.Weight FROM Product,Category WHERE Product.CatID = Category.CatID and Category.CatName = '" + CatName + "';";
            string query = "SELECT DISTINCT P.ProdID,P.ProdName AS Name,P.Size,P.Color,P.Price,P.Discount,P.Weight FROM Category as C, Product as P, Orders as O " +
"WHERE P.CatID = C.CatID and C.CatName = '" + CatName + "' AND P.ProdID NOT IN( " +
"SELECT P.ProdID FROM Product as P, Orders as O " +
"WHERE(P.OrdID = O.OrdID AND O.OrderDate IS NOT NULL) " +
"); ";
            return dbMan.ExecuteReader(query);
        }

        public int CheckOrdID(int CID)
        {
            string query = "SELECT COUNT(OrdID) FROM Orders WHERE OrderDate IS NULL and CID = " + CID + ";";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int CheckProductCount(int CID)
        {
            string query = "SELECT Count(P.ProdID) FROM Product as P,Orders as O,Customer as C " +
"WHERE C.CID = O.CID AND P.OrdID = O.OrdID AND C.CID = " + CID + " AND O.OrderDate IS NULL";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int CheckCategory(string CatName)
        {
            /*
            string query = "SELECT Count(Product.ProdName) FROM Category,Product " +
"WHERE Category.CatName = '" + CatName + "' AND Category.CatID = Product.CatID";
            */
            string query = "SELECT COUNT(P.ProdID) FROM Category as C, Product as P, Orders as O " +
"WHERE P.CatID = C.CatID and C.CatName = '" + CatName + "' AND P.ProdID NOT IN( " +
"SELECT P.ProdID FROM Product as P, Orders as O " +
"WHERE(P.OrdID = O.OrdID AND O.OrderDate IS NOT NULL)" +
"); ";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int GetCustomerID(string username)
        {
            string query = "SELECT CID FROM Customer WHERE username = '" + username + "';";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int GetOrdID(int CID)
        {
            string query = "SELECT OrdID FROM Orders WHERE OrderDate IS NULL and CID = " + CID + ";";
            return (int)dbMan.ExecuteScalar(query);
        }

        public int CreateOrder(int OrdID, int CID)
        {
            string query = "INSERT INTO Orders VALUES('" + OrdID + "',null,null," + CID + ");";
            return dbMan.ExecuteNonQuery(query);
        }

        public int AddProductToOrder(int OrdID, string ProdID)
        {
            string query = "update Product set OrdID = " + OrdID + " where ProdID = " + ProdID + ";";
            return dbMan.ExecuteNonQuery(query);
        }
        public int RemoveProductFromOrder(string ProdID)
        {
            string query = "update Product set OrdID = null where ProdID = " + ProdID + ";";
            return dbMan.ExecuteNonQuery(query);
        }

        public int GetHighestOrdID()
        {
            string query = "SELECT MAX(OrdID) FROM Orders;";
            return (int)dbMan.ExecuteScalar(query);
        }

        public DataTable SearchProducts(string ProdSearch)
        {
            //string query = "SELECT Product.ProdID, Product.ProdName AS Name,Product.Size,Product.Color,Product.Price,Product.Discount,Product.Weight FROM Product WHERE ProdName LIKE '%" + ProdSearch + "%';";
            string query = "SELECT DISTINCT P.ProdID,P.ProdName AS Name,P.Size,P.Color,P.Price,P.Discount,P.Weight FROM Category as C, Product as P, Orders as O " +
"WHERE ProdName LIKE '%" + ProdSearch + "%' AND P.ProdID NOT IN( " +
"SELECT P.ProdID FROM Product as P, Orders as O " +
"WHERE(P.OrdID = O.OrdID AND O.OrderDate IS NOT NULL) " +
"); ";
            return dbMan.ExecuteReader(query);
        }

        public int CheckProducts()
        {
            string query = "SELECT COUNT( P.ProdID) FROM Category as C, Product as P, Orders as O " +
"WHERE P.ProdID NOT IN( " +
"SELECT P.ProdID FROM Product as P, Orders as O " +
"WHERE(P.OrdID = O.OrdID AND O.OrderDate IS NOT NULL) " +
"); ";
            return (int)dbMan.ExecuteScalar(query);
        }

        public DataTable ViewAllProductsVer2()
        {
            string query = "SELECT DISTINCT P.ProdID,P.ProdName AS Name,P.Size,P.Color,P.Price,P.Discount,P.Weight FROM Category as C, Product as P, Orders as O " +
"WHERE P.ProdID NOT IN( " +
"SELECT P.ProdID FROM Product as P, Orders as O " +
"WHERE(P.OrdID = O.OrdID AND O.OrderDate IS NOT NULL) " +
"); ";
            return dbMan.ExecuteReader(query);
        }

        public DataTable ViewAllManagers()
        {
            string query = "SELECT * From Manager";
            return dbMan.ExecuteReader(query);
        }


        public int GetHighestRevNum()
        {
            string query = "SELECT MAX(RevNum) FROM Review;";
            return (int)dbMan.ExecuteScalar(query);
        }

        public int PostReview(int RevNum, int RevRating, int CID)
        {
            string query = "INSERT INTO Review (RevNum, RevDate, RevRate, CID) Values(" + RevNum + ", (select convert(date, getdate()))," + RevRating + "," + CID + ");";
            return dbMan.ExecuteNonQuery(query);
        }
        public DataTable GetCurrentOrder(int CID)
        {
            string query = "SELECT Product.ProdID, Product.ProdName AS Name,Product.Size,Product.Color,Product.Price,Product.Discount,Product.Weight FROM Product,Orders WHERE Orders.OrderDate IS NULL AND Product.OrdID = Orders.OrdID AND CID = " + CID + ";";
            return dbMan.ExecuteReader(query);
        }

        public int ConfirmOrder(int OrdID, string PaymentMethod)
        {
            string query = "update Orders set OrderDate = (select convert(date, getdate())), PaymentMethod = '" + PaymentMethod + "' where OrdID = " + OrdID + "; ";
            return dbMan.ExecuteNonQuery(query);
        }

        public int DeleteOrder(int OrdID)
        {
            string query = "DELETE FROM Orders WHERE OrdID = " + OrdID + "; ";
            return dbMan.ExecuteNonQuery(query);
        }

        public int CheckAnyOrder(int CID)
        {
            string query = "SELECT COUNT(OrdID) FROM Orders WHERE CID = " + CID + ";";
            return (int)dbMan.ExecuteScalar(query);
        }

        public DataTable ViewAllOrders(int CID)
        {
            string query = "SELECT OrderDate AS 'Order Date', PaymentMethod AS PaymentMethod FROM Orders WHERE CID = " + CID + ";";
            return dbMan.ExecuteReader(query);
        }

        public int CheckIfAdded(string ProdID, int CID)
        {
            string query = "SELECT COUNT(ProdID) FROM Product,Orders WHERE Product.OrdID = Orders.OrdID AND Product.ProdID = " + ProdID + " AND Orders.CID = " + CID + " ;";
            return (int)dbMan.ExecuteScalar(query);
        }

        public int CheckAddress(int CID)
        {
            string query = "SELECT COUNT(Address) FROM Customer WHERE CID = " + CID + ";";
            return (int)dbMan.ExecuteScalar(query);
        }

        public int CheckCredit(int CID)
        {
            string query = "SELECT COUNT(CreditNum) FROM Customer WHERE CID = " + CID + ";";
            return (int)dbMan.ExecuteScalar(query);
        }

        public int EditProfileAddress(string Address, string Username)
        {
            string query = "UPDATE Customer SET Address = '" + Address + "'  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }
        public int EditProfilePhone(string Phone, string Username)
        {
            string query = "UPDATE Customer SET Phone = '" + Phone + "'  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }
        public int EditProfileCreditCard(string CreditNum, string Username)
        {
            string query = "UPDATE Customer SET CreditNum = '" + CreditNum + "'  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }
        public int EditProfileGender(string Sex, string Username)
        {
            string query = "UPDATE Customer SET Sex = '" + Sex + "'  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }
        public int EditProfileBdate(string Bdate, string Username)
        {
            string query = "UPDATE Customer SET Bdate = '" + Bdate + "'  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }
        public int GetMaxSalaryManager()
        {
            string query = "SELECT MAX(Salary) FROM Manager;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int GetMinSalaryManager()
        {
            string query = "SELECT MIN(Salary) FROM Manager;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int GetAvgSalaryManager()
        {
            string query = "SELECT AVG(Salary) FROM Manager;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int GetMaxSalaryEmployee()
        {
            string query = "SELECT MAX(Salary) FROM Employee;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int GetMinSalaryEmployee()
        {
            string query = "SELECT MIN(Salary) FROM Employee;";
            return (int)dbMan.ExecuteScalar(query);
        }
        public int GetAvgSalaryEmployee()
        {
            string query = "SELECT AVG(Salary) FROM Employee;";
            return (int)dbMan.ExecuteScalar(query);
        }

        public int CreateShippedItems(int OrdID)
        {
            string query = "INSERT INTO ShippedItem VALUES('" + OrdID + "',5,(select dateadd(dd,5,(select convert(date, getdate())))), (select dateadd(dd,2,(select convert(date, getdate())))));";
            return dbMan.ExecuteNonQuery(query);
        }

        public DataTable ViewAllOrdersVer2(int CID)
        {
            string query = "SELECT O.OrderDate AS 'Order Date', O.PaymentMethod AS 'Payment Method', S.DeliveryDate as 'Delivery Date', S.ShipDate as 'Shipping Date' " +
"FROM Orders as O, ShippedItem as S " +
"WHERE O.CID = " + CID + " AND S.ShipID = O.OrdID";
            return dbMan.ExecuteReader(query);
        }

        public int CheckOngoingOrder(int CID) //WORK IN PROGRESS
        {
            string query = "SELECT Count(O.OrdID) " +
"FROM Orders as O, ShippedItem as S " +
"WHERE O.CID = " + CID + " AND S.ShipID = O.OrdID AND ( S.DeliveryDate > (select convert(date, getdate())) ) ";
            return (int)dbMan.ExecuteScalar(query);
        }

        public DataTable ViewOngoingOrders(int CID)
        {
            string query = "SELECT O.OrderDate AS 'Order Date', O.PaymentMethod AS 'Payment Method', S.DeliveryDate as 'Delivery Date', S.ShipDate as 'Shipping Date' " +
"FROM Orders as O, ShippedItem as S " +
"WHERE O.CID = " + CID + " AND S.ShipID = O.OrdID  AND ( S.DeliveryDate > (select convert(date, getdate())) ) ";
            return dbMan.ExecuteReader(query);
        }

        public int InsertAdmin(string username, string password, int AID)
        {
            string query = "INSERT INTO Admins VALUES ('" + username + "', HASHBYTES('MD5', '" + password + "'),"+AID+");";
            return dbMan.ExecuteNonQuery(query);
        }

        public int GetHighestAID()
        {
            string query = "SELECT MAX(AID) FROM Admins;";
            return (int)dbMan.ExecuteScalar(query);

        }
        public int AdminCheckPassword(string Password)
        {
            string query = "SELECT Password FROM Admins where Password = HASHBYTES('MD5','" + Password + "');";
            object p = dbMan.ExecuteScalar(query);
            if (p == null)
                return 0;
            else
                return 1;
        }
        public int AdminChangePassword(string Password, string Username)
        {
            string query = "UPDATE Admins SET Password = HASHBYTES('MD5','" + Password + "')  where Username = '" + Username + "' ;";
            return dbMan.ExecuteNonQuery(query);
        }
        public DataTable SelectManagerUsername()
        {
            string query = "SELECT Username FROM Manager;";
            return dbMan.ExecuteReader(query);
        }


    }
}
