﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class CustLogin : Form
    {
        Controller controllerObj;
        Form MyParent; 
        public CustLogin(Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (CustUserNameTextBox.Text.ToString() == "" || CustPasswordTextBox.Text.ToString() == "")
            {
                MessageBox.Show("Please enter a proper username and password.");
            }
            else
            {
                controllerObj = new Controller();
                int count = controllerObj.EmployeeCheckID(CustUserNameTextBox.Text.ToString(), CustPasswordTextBox.Text.ToString(), "Customer");
                if (count == 0)
                {
                    MessageBox.Show("Incorrect username or password.");
                }
                else
                {
                    int EID = controllerObj.EmployeeGetLoginID(CustUserNameTextBox.Text.ToString(), CustPasswordTextBox.Text.ToString(), "Customer");
                    MessageBox.Show("Sucessfully logged in.");
                    CustomerPage CP = new CustomerPage(CustUserNameTextBox.Text,this);
                    CP.Show();

                    CustUserNameTextBox.Text = null;
                    CustPasswordTextBox.Text = null;
                }
            }
        }

        private void CustLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }
    }
}
