﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class CustReg : Form
    {
        Controller controllerObj;
        Form MyParent;
        public CustReg(Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();

        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            if (UsernameTextBox.Text == "" || PasswordTextBox.Text == "" || EmailTextBox.Text == "" || LnameTextBox.Text == "" || MinitTextBox.Text == "" || FnameTextBox.Text == "" || CPasswordTextBox.Text == "")
            {
                MessageBox.Show("Please insert all values.");
            }
            else if (PasswordTextBox.Text != CPasswordTextBox.Text)
            {
                MessageBox.Show("Please type the same password twice.");
            }
            else
            {
                controllerObj = new Controller();
                int CID = controllerObj.GetHighestCID() + 1;
                int r = controllerObj.InsertCustomer(CID, FnameTextBox.Text.ToString(), MinitTextBox.Text.ToString(), LnameTextBox.Text.ToString(), EmailTextBox.Text.ToString(), UsernameTextBox.Text.ToString(), PasswordTextBox.Text.ToString());
                if (r > 0)
                { 
                    MessageBox.Show("Customer inserted successfully");
                    CustomerPage CP = new CustomerPage(PasswordTextBox.Text, this);
                    CP.Show();
                    UsernameTextBox.Text = null;
                    PasswordTextBox.Text = null;
                    EmailTextBox.Text = null;
                    LnameTextBox.Text = null;
                    MinitTextBox.Text = null;
                    FnameTextBox.Text = null;
                    CPasswordTextBox.Text = null;
                }
                else
                    MessageBox.Show("Insertion Failed");
            }
            
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void CustReg_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        
    }
}
