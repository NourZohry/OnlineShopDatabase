﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class CustRegLog : Form
    {
        Form MyParent;
        public CustRegLog(Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
        }
       

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        

        private void LoginButton_Click(object sender, EventArgs e)
        {
            CustLogin CL = new CustLogin(this);
            CL.Show();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            CustReg CR = new CustReg(this);
            CR.Show();
        }

        private void CustRegLog_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }
    }
}
