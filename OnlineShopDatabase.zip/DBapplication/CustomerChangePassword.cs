﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class CustomerChangePassword : Form
    {
        Form MyParent;
        string s;
        Controller obj;
        public CustomerChangePassword(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            obj = new Controller();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void CustomerChangePassword_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void ConfirmChangebutton_Click(object sender, EventArgs e)
        {
            if (CurrentPasswordTextBox.Text == "" || PasswordTextBox.Text == "" || ConfirmPasswordTextBox.Text == "")
            {
                MessageBox.Show("There are an empty box please, fill it");
            }
            else
            {

                if ((obj.CustCheckPassword(CurrentPasswordTextBox.Text)) != 0 && PasswordTextBox.Text == ConfirmPasswordTextBox.Text)
                {
                    int result = obj.CustChangePassword(PasswordTextBox.Text, s);
                    if (result == 0)
                    {

                        MessageBox.Show("Failed to change the password");
                    }
                    else
                    {
                        MessageBox.Show("Password is changed successfully");

                    }

                }
                else
                {
                    MessageBox.Show("Please, Enter the Confirmed password as the new one or enter the old password correctly");
                }
            }
        }
    }
}
