﻿namespace DBapplication
{
    partial class CustomerPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerPage));
            this.LogOutButton = new System.Windows.Forms.Button();
            this.SearchForProducts = new System.Windows.Forms.Button();
            this.PostReview = new System.Windows.Forms.Button();
            this.ViewOrders = new System.Windows.Forms.Button();
            this.ConfirmOrder = new System.Windows.Forms.Button();
            this.CustomerSettings = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LogOutButton
            // 
            this.LogOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutButton.Location = new System.Drawing.Point(265, 226);
            this.LogOutButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Size = new System.Drawing.Size(92, 38);
            this.LogOutButton.TabIndex = 5;
            this.LogOutButton.Text = "Log Out";
            this.LogOutButton.UseVisualStyleBackColor = true;
            this.LogOutButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // SearchForProducts
            // 
            this.SearchForProducts.Location = new System.Drawing.Point(69, 15);
            this.SearchForProducts.Margin = new System.Windows.Forms.Padding(4);
            this.SearchForProducts.Name = "SearchForProducts";
            this.SearchForProducts.Size = new System.Drawing.Size(231, 28);
            this.SearchForProducts.TabIndex = 7;
            this.SearchForProducts.Text = "Search for Products";
            this.SearchForProducts.UseVisualStyleBackColor = true;
            this.SearchForProducts.Click += new System.EventHandler(this.SearchForProducts_Click);
            // 
            // PostReview
            // 
            this.PostReview.Location = new System.Drawing.Point(69, 122);
            this.PostReview.Margin = new System.Windows.Forms.Padding(4);
            this.PostReview.Name = "PostReview";
            this.PostReview.Size = new System.Drawing.Size(231, 28);
            this.PostReview.TabIndex = 10;
            this.PostReview.Text = "Post Review";
            this.PostReview.UseVisualStyleBackColor = true;
            this.PostReview.Click += new System.EventHandler(this.PostReview_Click);
            // 
            // ViewOrders
            // 
            this.ViewOrders.Location = new System.Drawing.Point(69, 86);
            this.ViewOrders.Margin = new System.Windows.Forms.Padding(4);
            this.ViewOrders.Name = "ViewOrders";
            this.ViewOrders.Size = new System.Drawing.Size(231, 28);
            this.ViewOrders.TabIndex = 12;
            this.ViewOrders.Text = "View Orders";
            this.ViewOrders.UseVisualStyleBackColor = true;
            this.ViewOrders.Click += new System.EventHandler(this.ViewOrders_Click);
            // 
            // ConfirmOrder
            // 
            this.ConfirmOrder.Location = new System.Drawing.Point(69, 50);
            this.ConfirmOrder.Margin = new System.Windows.Forms.Padding(4);
            this.ConfirmOrder.Name = "ConfirmOrder";
            this.ConfirmOrder.Size = new System.Drawing.Size(231, 28);
            this.ConfirmOrder.TabIndex = 13;
            this.ConfirmOrder.Text = "Confirm Order";
            this.ConfirmOrder.UseVisualStyleBackColor = true;
            this.ConfirmOrder.Click += new System.EventHandler(this.ConfirmOrder_Click);
            // 
            // CustomerSettings
            // 
            this.CustomerSettings.Location = new System.Drawing.Point(159, 226);
            this.CustomerSettings.Margin = new System.Windows.Forms.Padding(4);
            this.CustomerSettings.Name = "CustomerSettings";
            this.CustomerSettings.Size = new System.Drawing.Size(100, 38);
            this.CustomerSettings.TabIndex = 14;
            this.CustomerSettings.Text = "Settings";
            this.CustomerSettings.UseVisualStyleBackColor = true;
            this.CustomerSettings.Click += new System.EventHandler(this.CustomerSettings_Click);
            // 
            // CustomerPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(371, 282);
            this.Controls.Add(this.CustomerSettings);
            this.Controls.Add(this.ConfirmOrder);
            this.Controls.Add(this.ViewOrders);
            this.Controls.Add(this.PostReview);
            this.Controls.Add(this.SearchForProducts);
            this.Controls.Add(this.LogOutButton);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CustomerPage";
            this.Text = "CustomerPage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.CustomerPage_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button LogOutButton;
        private System.Windows.Forms.Button SearchForProducts;
        private System.Windows.Forms.Button PostReview;
        private System.Windows.Forms.Button ViewOrders;
        private System.Windows.Forms.Button ConfirmOrder;
        private System.Windows.Forms.Button CustomerSettings;
    }
}