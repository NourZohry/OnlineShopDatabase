﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class CustomerPage : Form
    {
        Form MyParent;
        string s;
        public CustomerPage(string id,Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;

        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void CustomerPage_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(s);
        }

        private void SearchForProducts_Click(object sender, EventArgs e)
        {
            SearchForProducts SFP = new SearchForProducts(s, this);
            SFP.Show();
        }

        private void ConfirmOrder_Click(object sender, EventArgs e)
        {
            ConfirmOrder CO = new ConfirmOrder(s, this);
            CO.Show();
        }

        private void ViewOrders_Click(object sender, EventArgs e)
        {
            ViewOrders VO = new ViewOrders(s, this);
            VO.Show();
        }

        private void PostReview_Click(object sender, EventArgs e)
        {
            PostReview PR = new PostReview(s, this);
            PR.Show();
        }

        private void CustomerSettings_Click(object sender, EventArgs e)
        {
            CustomerSettings CS = new CustomerSettings(s, this);
            CS.Show();
        }
    }
}
