﻿namespace DBapplication
{
    partial class CustomerSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerSettings));
            this.ChangePasswordButton = new System.Windows.Forms.Button();
            this.Returnbutton = new System.Windows.Forms.Button();
            this.EditProfileButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ChangePasswordButton
            // 
            this.ChangePasswordButton.Location = new System.Drawing.Point(45, 110);
            this.ChangePasswordButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ChangePasswordButton.Name = "ChangePasswordButton";
            this.ChangePasswordButton.Size = new System.Drawing.Size(152, 42);
            this.ChangePasswordButton.TabIndex = 8;
            this.ChangePasswordButton.Text = "Change Password";
            this.ChangePasswordButton.UseVisualStyleBackColor = true;
            this.ChangePasswordButton.Click += new System.EventHandler(this.Changepasswordbutton_Click);
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(168, 192);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 33);
            this.Returnbutton.TabIndex = 6;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // EditProfileButton
            // 
            this.EditProfileButton.Location = new System.Drawing.Point(45, 42);
            this.EditProfileButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EditProfileButton.Name = "EditProfileButton";
            this.EditProfileButton.Size = new System.Drawing.Size(152, 44);
            this.EditProfileButton.TabIndex = 9;
            this.EditProfileButton.Text = "Edit Profile";
            this.EditProfileButton.UseVisualStyleBackColor = true;
            this.EditProfileButton.Click += new System.EventHandler(this.EditProfileButton_Click);
            // 
            // CustomerSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(257, 239);
            this.Controls.Add(this.EditProfileButton);
            this.Controls.Add(this.ChangePasswordButton);
            this.Controls.Add(this.Returnbutton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CustomerSettings";
            this.Text = "CustomerSettings";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.CustomerSettings_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ChangePasswordButton;
        private System.Windows.Forms.Button Returnbutton;
        private System.Windows.Forms.Button EditProfileButton;
    }
}