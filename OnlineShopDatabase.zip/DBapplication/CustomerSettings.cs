﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class CustomerSettings : Form
    {
        Form MyParent;
        string s;
        public CustomerSettings(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void Changepasswordbutton_Click(object sender, EventArgs e)
        {
            CustomerChangePassword CCP = new CustomerChangePassword(s,this);
            CCP.Show();
        }

        //private void Logoutbutton_Click(object sender, EventArgs e)
        //{

        //}

        private void EditProfileButton_Click(object sender, EventArgs e)
        {
            EditProfile EP = new EditProfile(s, this);
            EP.Show();
        }

        private void CustomerSettings_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }
    }
}
