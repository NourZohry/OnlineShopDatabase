﻿namespace DBapplication
{
    partial class DeleteCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Returnbutton = new System.Windows.Forms.Button();
            this.DeleteCustomerbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CustomerUsernameCombobox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(383, 122);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 29);
            this.Returnbutton.TabIndex = 0;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // DeleteCustomerbutton
            // 
            this.DeleteCustomerbutton.Location = new System.Drawing.Point(219, 122);
            this.DeleteCustomerbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DeleteCustomerbutton.Name = "DeleteCustomerbutton";
            this.DeleteCustomerbutton.Size = new System.Drawing.Size(141, 29);
            this.DeleteCustomerbutton.TabIndex = 1;
            this.DeleteCustomerbutton.Text = "Delete Customer";
            this.DeleteCustomerbutton.UseVisualStyleBackColor = true;
            this.DeleteCustomerbutton.Click += new System.EventHandler(this.DeleteCustomerbutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Customer Username";
            // 
            // CustomerUsernameCombobox
            // 
            this.CustomerUsernameCombobox.FormattingEnabled = true;
            this.CustomerUsernameCombobox.Location = new System.Drawing.Point(219, 37);
            this.CustomerUsernameCombobox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CustomerUsernameCombobox.Name = "CustomerUsernameCombobox";
            this.CustomerUsernameCombobox.Size = new System.Drawing.Size(121, 24);
            this.CustomerUsernameCombobox.TabIndex = 3;
            // 
            // DeleteCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(501, 185);
            this.Controls.Add(this.CustomerUsernameCombobox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DeleteCustomerbutton);
            this.Controls.Add(this.Returnbutton);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "DeleteCustomer";
            this.Text = "DeleteCustomer";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.DeleteCustomer_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Returnbutton;
        private System.Windows.Forms.Button DeleteCustomerbutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CustomerUsernameCombobox;
    }
}