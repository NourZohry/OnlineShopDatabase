﻿namespace DBapplication
{
    partial class EditProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddressTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CreditCardTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.GenderTextBox = new System.Windows.Forms.ComboBox();
            this.SaveChangesButton = new System.Windows.Forms.Button();
            this.Returnbutton = new System.Windows.Forms.Button();
            this.CheckBdateBox = new System.Windows.Forms.CheckBox();
            this.BdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AddressTextBox
            // 
            this.AddressTextBox.Location = new System.Drawing.Point(128, 37);
            this.AddressTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.AddressTextBox.Name = "AddressTextBox";
            this.AddressTextBox.Size = new System.Drawing.Size(245, 22);
            this.AddressTextBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Address:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 85);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Phone Number:";
            // 
            // PhoneNumberTextBox
            // 
            this.PhoneNumberTextBox.Location = new System.Drawing.Point(128, 81);
            this.PhoneNumberTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.PhoneNumberTextBox.Name = "PhoneNumberTextBox";
            this.PhoneNumberTextBox.Size = new System.Drawing.Size(245, 22);
            this.PhoneNumberTextBox.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 133);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Credit Card:";
            // 
            // CreditCardTextBox
            // 
            this.CreditCardTextBox.Location = new System.Drawing.Point(128, 129);
            this.CreditCardTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.CreditCardTextBox.Name = "CreditCardTextBox";
            this.CreditCardTextBox.Size = new System.Drawing.Size(245, 22);
            this.CreditCardTextBox.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 180);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Gender:";
            // 
            // GenderTextBox
            // 
            this.GenderTextBox.FormattingEnabled = true;
            this.GenderTextBox.Items.AddRange(new object[] {
            "M",
            "F"});
            this.GenderTextBox.Location = new System.Drawing.Point(128, 176);
            this.GenderTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.GenderTextBox.Name = "GenderTextBox";
            this.GenderTextBox.Size = new System.Drawing.Size(245, 24);
            this.GenderTextBox.TabIndex = 11;
            // 
            // SaveChangesButton
            // 
            this.SaveChangesButton.Location = new System.Drawing.Point(128, 293);
            this.SaveChangesButton.Margin = new System.Windows.Forms.Padding(4);
            this.SaveChangesButton.Name = "SaveChangesButton";
            this.SaveChangesButton.Size = new System.Drawing.Size(247, 28);
            this.SaveChangesButton.TabIndex = 13;
            this.SaveChangesButton.Text = "Save Changes";
            this.SaveChangesButton.UseVisualStyleBackColor = true;
            this.SaveChangesButton.Click += new System.EventHandler(this.SaveChangesButton_Click);
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(393, 332);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 32);
            this.Returnbutton.TabIndex = 14;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // CheckBdateBox
            // 
            this.CheckBdateBox.AutoSize = true;
            this.CheckBdateBox.Location = new System.Drawing.Point(12, 217);
            this.CheckBdateBox.Name = "CheckBdateBox";
            this.CheckBdateBox.Size = new System.Drawing.Size(251, 21);
            this.CheckBdateBox.TabIndex = 18;
            this.CheckBdateBox.Text = "Do you want to edit your birth date.";
            this.CheckBdateBox.UseVisualStyleBackColor = true;
            // 
            // BdateTimePicker1
            // 
            this.BdateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.BdateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.BdateTimePicker1.Location = new System.Drawing.Point(128, 245);
            this.BdateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.BdateTimePicker1.Name = "BdateTimePicker1";
            this.BdateTimePicker1.Size = new System.Drawing.Size(245, 22);
            this.BdateTimePicker1.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 245);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 17);
            this.label7.TabIndex = 16;
            this.label7.Text = "Bdate:";
            // 
            // EditProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(483, 378);
            this.Controls.Add(this.CheckBdateBox);
            this.Controls.Add(this.BdateTimePicker1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Returnbutton);
            this.Controls.Add(this.SaveChangesButton);
            this.Controls.Add(this.GenderTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CreditCardTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PhoneNumberTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AddressTextBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EditProfile";
            this.Text = "EditProfile";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.EditProfile_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox AddressTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox PhoneNumberTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox CreditCardTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox GenderTextBox;
        private System.Windows.Forms.Button SaveChangesButton;
        private System.Windows.Forms.Button Returnbutton;
        private System.Windows.Forms.CheckBox CheckBdateBox;
        private System.Windows.Forms.DateTimePicker BdateTimePicker1;
        private System.Windows.Forms.Label label7;
    }
}