﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class EditProfile : Form
    {
        Form MyParent;
        string s;
        Controller obj;
        public EditProfile(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            obj = new Controller();
        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void EditProfile_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void SaveChangesButton_Click(object sender, EventArgs e)
        {
            if (AddressTextBox.Text == "" && PhoneNumberTextBox.Text == "" && CreditCardTextBox.Text == "" && GenderTextBox.Text == "" && CheckBdateBox.Checked == false)
            {
                MessageBox.Show("Error,There are no value to update please,insert anyone");
            }
            else
            {

                if (AddressTextBox.Text != "")
                {
                    int r = obj.EditProfileAddress(AddressTextBox.Text, s);
                }
                if (PhoneNumberTextBox.Text != "")
                {
                    int r1 = obj.EditProfilePhone(PhoneNumberTextBox.Text, s);
                }

                if (CreditCardTextBox.Text != "")
                {
                    int r2 = obj.EditProfileCreditCard(CreditCardTextBox.Text, s);
                }

                if (GenderTextBox.Text != "")
                {
                    int r3 = obj.EditProfileGender(GenderTextBox.Text, s);
                }
                if (BdateTimePicker1.Text != "" && CheckBdateBox.Checked == true)
                {
                    int r4 = obj.EditProfileBdate(BdateTimePicker1.Text.Trim('"'), s);
                }
                MessageBox.Show("The profile is updated successfuly");
            }
        }
    }
}
