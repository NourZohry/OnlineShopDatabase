﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class EmpLogin : Form
    {
        Controller controllerObj;
        Form MyParent;
        public EmpLogin(Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (EmpUserNameTextBox.Text.ToString() == "" || EmpPasswordTextBox.Text.ToString() == "")
            {
                MessageBox.Show("Please enter a proper username and password.");
            }
            else
            {
                controllerObj = new Controller();
                int count = controllerObj.EmployeeCheckID(EmpUserNameTextBox.Text.ToString(), EmpPasswordTextBox.Text.ToString(),"Employee");
                if (count == 0)
                {
                    MessageBox.Show("Incorrect username or password.");
                }
                else
                {
                    int EID = controllerObj.EmployeeGetLoginID(EmpUserNameTextBox.Text.ToString(), EmpPasswordTextBox.Text.ToString(),"Employee");
                    MessageBox.Show("Sucessfully logged in as an employee.");
                    EmployeePage EP = new EmployeePage(EmpUserNameTextBox.Text.ToString(), this);
                    EP.Show();

                    EmpUserNameTextBox.Text = null;
                    EmpPasswordTextBox.Text = null;
                }
            }
        }

        private void EmpLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();

        }
    }
}

