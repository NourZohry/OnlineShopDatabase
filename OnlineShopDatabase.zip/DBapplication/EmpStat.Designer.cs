﻿namespace DBapplication
{
    partial class EmpStat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReturnButton = new System.Windows.Forms.Button();
            this.MinTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.AvgTextBox = new System.Windows.Forms.TextBox();
            this.MaxTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ReturnButton
            // 
            this.ReturnButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnButton.Location = new System.Drawing.Point(362, 218);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(75, 38);
            this.ReturnButton.TabIndex = 15;
            this.ReturnButton.Text = "Return";
            this.ReturnButton.UseVisualStyleBackColor = true;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // MinTextBox
            // 
            this.MinTextBox.Location = new System.Drawing.Point(195, 94);
            this.MinTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MinTextBox.Name = "MinTextBox";
            this.MinTextBox.ReadOnly = true;
            this.MinTextBox.Size = new System.Drawing.Size(132, 22);
            this.MinTextBox.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 17);
            this.label1.TabIndex = 25;
            this.label1.Text = "Minimum Salary:";
            // 
            // AvgTextBox
            // 
            this.AvgTextBox.Location = new System.Drawing.Point(195, 157);
            this.AvgTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.AvgTextBox.Name = "AvgTextBox";
            this.AvgTextBox.ReadOnly = true;
            this.AvgTextBox.Size = new System.Drawing.Size(132, 22);
            this.AvgTextBox.TabIndex = 24;
            // 
            // MaxTextBox
            // 
            this.MaxTextBox.Location = new System.Drawing.Point(195, 34);
            this.MaxTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MaxTextBox.Name = "MaxTextBox";
            this.MaxTextBox.ReadOnly = true;
            this.MaxTextBox.Size = new System.Drawing.Size(132, 22);
            this.MaxTextBox.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 161);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 17);
            this.label3.TabIndex = 22;
            this.label3.Text = "Average Salary:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 37);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 17);
            this.label2.TabIndex = 21;
            this.label2.Text = "Maximum Salary:";
            // 
            // EmpStat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(463, 281);
            this.Controls.Add(this.MinTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AvgTextBox);
            this.Controls.Add(this.MaxTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ReturnButton);
            this.Name = "EmpStat";
            this.Text = "EmpStat";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.EmpStat_FormClosed);
            this.Load += new System.EventHandler(this.EmpStat_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ReturnButton;
        private System.Windows.Forms.TextBox MinTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox AvgTextBox;
        private System.Windows.Forms.TextBox MaxTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}