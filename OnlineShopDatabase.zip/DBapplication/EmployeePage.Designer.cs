﻿namespace DBapplication
{
    partial class EmployeePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeePage));
            this.LogOutButton = new System.Windows.Forms.Button();
            this.DeleteCustomer = new System.Windows.Forms.Button();
            this.AddProduct = new System.Windows.Forms.Button();
            this.RemoveProduct = new System.Windows.Forms.Button();
            this.UpdateProduct = new System.Windows.Forms.Button();
            this.Settings = new System.Windows.Forms.Button();
            this.ViewCustomers = new System.Windows.Forms.Button();
            this.ViewProducts = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LogOutButton
            // 
            this.LogOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutButton.Location = new System.Drawing.Point(335, 282);
            this.LogOutButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Size = new System.Drawing.Size(104, 38);
            this.LogOutButton.TabIndex = 4;
            this.LogOutButton.Text = "Log Out";
            this.LogOutButton.UseVisualStyleBackColor = true;
            this.LogOutButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // DeleteCustomer
            // 
            this.DeleteCustomer.Location = new System.Drawing.Point(101, 31);
            this.DeleteCustomer.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteCustomer.Name = "DeleteCustomer";
            this.DeleteCustomer.Size = new System.Drawing.Size(239, 28);
            this.DeleteCustomer.TabIndex = 5;
            this.DeleteCustomer.Text = "Delete a Customer\'s Account";
            this.DeleteCustomer.UseVisualStyleBackColor = true;
            this.DeleteCustomer.Click += new System.EventHandler(this.DeleteCustomer_Click);
            // 
            // AddProduct
            // 
            this.AddProduct.Location = new System.Drawing.Point(101, 102);
            this.AddProduct.Margin = new System.Windows.Forms.Padding(4);
            this.AddProduct.Name = "AddProduct";
            this.AddProduct.Size = new System.Drawing.Size(239, 28);
            this.AddProduct.TabIndex = 7;
            this.AddProduct.Text = "Add a Product to Sell";
            this.AddProduct.UseVisualStyleBackColor = true;
            this.AddProduct.Click += new System.EventHandler(this.AddProduct_Click);
            // 
            // RemoveProduct
            // 
            this.RemoveProduct.Location = new System.Drawing.Point(101, 174);
            this.RemoveProduct.Margin = new System.Windows.Forms.Padding(4);
            this.RemoveProduct.Name = "RemoveProduct";
            this.RemoveProduct.Size = new System.Drawing.Size(239, 28);
            this.RemoveProduct.TabIndex = 8;
            this.RemoveProduct.Text = "Remove a Product";
            this.RemoveProduct.UseVisualStyleBackColor = true;
            this.RemoveProduct.Click += new System.EventHandler(this.RemoveProduct_Click);
            // 
            // UpdateProduct
            // 
            this.UpdateProduct.Location = new System.Drawing.Point(101, 138);
            this.UpdateProduct.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateProduct.Name = "UpdateProduct";
            this.UpdateProduct.Size = new System.Drawing.Size(239, 28);
            this.UpdateProduct.TabIndex = 9;
            this.UpdateProduct.Text = "Update Product Information";
            this.UpdateProduct.UseVisualStyleBackColor = true;
            this.UpdateProduct.Click += new System.EventHandler(this.UpdateProduct_Click);
            // 
            // Settings
            // 
            this.Settings.Location = new System.Drawing.Point(231, 283);
            this.Settings.Margin = new System.Windows.Forms.Padding(4);
            this.Settings.Name = "Settings";
            this.Settings.Size = new System.Drawing.Size(97, 37);
            this.Settings.TabIndex = 10;
            this.Settings.Text = "Settings";
            this.Settings.UseVisualStyleBackColor = true;
            this.Settings.Click += new System.EventHandler(this.Settings_Click);
            // 
            // ViewCustomers
            // 
            this.ViewCustomers.Location = new System.Drawing.Point(101, 66);
            this.ViewCustomers.Margin = new System.Windows.Forms.Padding(4);
            this.ViewCustomers.Name = "ViewCustomers";
            this.ViewCustomers.Size = new System.Drawing.Size(239, 28);
            this.ViewCustomers.TabIndex = 11;
            this.ViewCustomers.Text = "View All Customers";
            this.ViewCustomers.UseVisualStyleBackColor = true;
            this.ViewCustomers.Click += new System.EventHandler(this.ViewCustomers_Click);
            // 
            // ViewProducts
            // 
            this.ViewProducts.Location = new System.Drawing.Point(101, 209);
            this.ViewProducts.Margin = new System.Windows.Forms.Padding(4);
            this.ViewProducts.Name = "ViewProducts";
            this.ViewProducts.Size = new System.Drawing.Size(239, 28);
            this.ViewProducts.TabIndex = 12;
            this.ViewProducts.Text = "View All Products";
            this.ViewProducts.UseVisualStyleBackColor = true;
            this.ViewProducts.Click += new System.EventHandler(this.ViewProducts_Click);
            // 
            // EmployeePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(453, 336);
            this.Controls.Add(this.ViewProducts);
            this.Controls.Add(this.ViewCustomers);
            this.Controls.Add(this.Settings);
            this.Controls.Add(this.UpdateProduct);
            this.Controls.Add(this.RemoveProduct);
            this.Controls.Add(this.AddProduct);
            this.Controls.Add(this.DeleteCustomer);
            this.Controls.Add(this.LogOutButton);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "EmployeePage";
            this.Text = "EmployeePage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.EmployeePage_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button LogOutButton;
        private System.Windows.Forms.Button DeleteCustomer;
        private System.Windows.Forms.Button AddProduct;
        private System.Windows.Forms.Button RemoveProduct;
        private System.Windows.Forms.Button UpdateProduct;
        private System.Windows.Forms.Button Settings;
        private System.Windows.Forms.Button ViewCustomers;
        private System.Windows.Forms.Button ViewProducts;
    }
}