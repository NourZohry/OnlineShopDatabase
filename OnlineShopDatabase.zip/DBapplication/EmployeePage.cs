﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class EmployeePage : Form
    {
        Form MyParent;
        string s;
        public EmployeePage(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;

        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void EmployeePage_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void DeleteCustomer_Click(object sender, EventArgs e)
        {
            DeleteCustomer DC = new DeleteCustomer(s,this);
            DC.Show();
        }

        private void ViewCustomers_Click(object sender, EventArgs e)
        {
            ViewCustomers VC = new ViewCustomers(s,this);
            VC.Show();
        }

        private void AddProduct_Click(object sender, EventArgs e)
        {
            AddProduct AP = new AddProduct(s,this);
            AP.Show();
        }

        private void UpdateProduct_Click(object sender, EventArgs e)
        {
            UpdateProduct UP = new UpdateProduct(s,this);
            UP.Show();
        }

        private void RemoveProduct_Click(object sender, EventArgs e)
        {
            RemoveProduct RP = new RemoveProduct(s,this);
            RP.Show();
        }

        private void ViewProducts_Click(object sender, EventArgs e)
        {
            ViewProducts VP = new ViewProducts(s,this);
            VP.Show();
        }

        private void Settings_Click(object sender, EventArgs e)
        {
            EmployeeSettings ES = new EmployeeSettings(s,this);
            ES.Show();
        }
    }
}
