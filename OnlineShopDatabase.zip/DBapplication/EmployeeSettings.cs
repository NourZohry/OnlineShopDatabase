﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class EmployeeSettings : Form
    {
        Form MyParent;
        string s;
        public EmployeeSettings(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;

        }
        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void EmployeeSettings_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void Changepasswordbutton_Click(object sender, EventArgs e)
        {
            EmployeeChangePassword ECP = new EmployeeChangePassword(s,this);
            ECP.Show();
        }

        private void Logoutbutton_Click(object sender, EventArgs e)
        {
           
        }
    }
}
