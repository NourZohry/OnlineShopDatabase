﻿namespace DBapplication
{
    partial class ManagerPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManagerPage));
            this.LogOutButton = new System.Windows.Forms.Button();
            this.InsertEmployee = new System.Windows.Forms.Button();
            this.UpdateSupplier = new System.Windows.Forms.Button();
            this.AddSupplier = new System.Windows.Forms.Button();
            this.RemoveEmployee = new System.Windows.Forms.Button();
            this.UpdateEmployee = new System.Windows.Forms.Button();
            this.SetDiscount = new System.Windows.Forms.Button();
            this.RemoveSupplier = new System.Windows.Forms.Button();
            this.ManagerSettings = new System.Windows.Forms.Button();
            this.ViewSuppliers = new System.Windows.Forms.Button();
            this.ViewEmployees = new System.Windows.Forms.Button();
            this.ViewAllProducts = new System.Windows.Forms.Button();
            this.ViewAllReviews = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LogOutButton
            // 
            this.LogOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOutButton.Location = new System.Drawing.Point(697, 287);
            this.LogOutButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Size = new System.Drawing.Size(88, 38);
            this.LogOutButton.TabIndex = 3;
            this.LogOutButton.Text = "Log Out";
            this.LogOutButton.UseVisualStyleBackColor = true;
            this.LogOutButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // InsertEmployee
            // 
            this.InsertEmployee.Location = new System.Drawing.Point(61, 31);
            this.InsertEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.InsertEmployee.Name = "InsertEmployee";
            this.InsertEmployee.Size = new System.Drawing.Size(291, 28);
            this.InsertEmployee.TabIndex = 4;
            this.InsertEmployee.Text = "Add New Employees";
            this.InsertEmployee.UseVisualStyleBackColor = true;
            this.InsertEmployee.Click += new System.EventHandler(this.InsertEmployee_Click);
            // 
            // UpdateSupplier
            // 
            this.UpdateSupplier.Location = new System.Drawing.Point(402, 67);
            this.UpdateSupplier.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateSupplier.Name = "UpdateSupplier";
            this.UpdateSupplier.Size = new System.Drawing.Size(291, 28);
            this.UpdateSupplier.TabIndex = 5;
            this.UpdateSupplier.Text = "Update Supplier Information";
            this.UpdateSupplier.UseVisualStyleBackColor = true;
            this.UpdateSupplier.Click += new System.EventHandler(this.UpdateSupplier_Click);
            // 
            // AddSupplier
            // 
            this.AddSupplier.Location = new System.Drawing.Point(402, 31);
            this.AddSupplier.Margin = new System.Windows.Forms.Padding(4);
            this.AddSupplier.Name = "AddSupplier";
            this.AddSupplier.Size = new System.Drawing.Size(291, 28);
            this.AddSupplier.TabIndex = 6;
            this.AddSupplier.Text = "Add New Suppliers";
            this.AddSupplier.UseVisualStyleBackColor = true;
            this.AddSupplier.Click += new System.EventHandler(this.AddSupplier_Click);
            // 
            // RemoveEmployee
            // 
            this.RemoveEmployee.Location = new System.Drawing.Point(61, 103);
            this.RemoveEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.RemoveEmployee.Name = "RemoveEmployee";
            this.RemoveEmployee.Size = new System.Drawing.Size(291, 28);
            this.RemoveEmployee.TabIndex = 7;
            this.RemoveEmployee.Text = "Remove Employees";
            this.RemoveEmployee.UseVisualStyleBackColor = true;
            this.RemoveEmployee.Click += new System.EventHandler(this.RemoveEmployee_Click);
            // 
            // UpdateEmployee
            // 
            this.UpdateEmployee.Location = new System.Drawing.Point(61, 67);
            this.UpdateEmployee.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateEmployee.Name = "UpdateEmployee";
            this.UpdateEmployee.Size = new System.Drawing.Size(291, 28);
            this.UpdateEmployee.TabIndex = 8;
            this.UpdateEmployee.Text = "Update Employee Information";
            this.UpdateEmployee.UseVisualStyleBackColor = true;
            this.UpdateEmployee.Click += new System.EventHandler(this.UpdateEmployee_Click);
            // 
            // SetDiscount
            // 
            this.SetDiscount.Location = new System.Drawing.Point(61, 213);
            this.SetDiscount.Margin = new System.Windows.Forms.Padding(4);
            this.SetDiscount.Name = "SetDiscount";
            this.SetDiscount.Size = new System.Drawing.Size(291, 28);
            this.SetDiscount.TabIndex = 10;
            this.SetDiscount.Text = "Set Discount on a Product";
            this.SetDiscount.UseVisualStyleBackColor = true;
            this.SetDiscount.Click += new System.EventHandler(this.SetDiscount_Click);
            // 
            // RemoveSupplier
            // 
            this.RemoveSupplier.Location = new System.Drawing.Point(402, 103);
            this.RemoveSupplier.Margin = new System.Windows.Forms.Padding(4);
            this.RemoveSupplier.Name = "RemoveSupplier";
            this.RemoveSupplier.Size = new System.Drawing.Size(291, 28);
            this.RemoveSupplier.TabIndex = 11;
            this.RemoveSupplier.Text = "Remove Suppliers";
            this.RemoveSupplier.UseVisualStyleBackColor = true;
            this.RemoveSupplier.Click += new System.EventHandler(this.RemoveSupplier_Click);
            // 
            // ManagerSettings
            // 
            this.ManagerSettings.Location = new System.Drawing.Point(591, 287);
            this.ManagerSettings.Margin = new System.Windows.Forms.Padding(4);
            this.ManagerSettings.Name = "ManagerSettings";
            this.ManagerSettings.Size = new System.Drawing.Size(100, 38);
            this.ManagerSettings.TabIndex = 12;
            this.ManagerSettings.Text = "Settings";
            this.ManagerSettings.UseVisualStyleBackColor = true;
            this.ManagerSettings.Click += new System.EventHandler(this.ManagerSettings_Click);
            // 
            // ViewSuppliers
            // 
            this.ViewSuppliers.Location = new System.Drawing.Point(402, 138);
            this.ViewSuppliers.Margin = new System.Windows.Forms.Padding(4);
            this.ViewSuppliers.Name = "ViewSuppliers";
            this.ViewSuppliers.Size = new System.Drawing.Size(291, 28);
            this.ViewSuppliers.TabIndex = 13;
            this.ViewSuppliers.Text = "View All Suppliers";
            this.ViewSuppliers.UseVisualStyleBackColor = true;
            this.ViewSuppliers.Click += new System.EventHandler(this.ViewSuppliers_Click);
            // 
            // ViewEmployees
            // 
            this.ViewEmployees.Location = new System.Drawing.Point(61, 138);
            this.ViewEmployees.Margin = new System.Windows.Forms.Padding(4);
            this.ViewEmployees.Name = "ViewEmployees";
            this.ViewEmployees.Size = new System.Drawing.Size(291, 28);
            this.ViewEmployees.TabIndex = 14;
            this.ViewEmployees.Text = "View All Employees";
            this.ViewEmployees.UseVisualStyleBackColor = true;
            this.ViewEmployees.Click += new System.EventHandler(this.ViewEmployees_Click);
            // 
            // ViewAllProducts
            // 
            this.ViewAllProducts.Location = new System.Drawing.Point(61, 248);
            this.ViewAllProducts.Margin = new System.Windows.Forms.Padding(4);
            this.ViewAllProducts.Name = "ViewAllProducts";
            this.ViewAllProducts.Size = new System.Drawing.Size(291, 28);
            this.ViewAllProducts.TabIndex = 15;
            this.ViewAllProducts.Text = "View All Products";
            this.ViewAllProducts.UseVisualStyleBackColor = true;
            this.ViewAllProducts.Click += new System.EventHandler(this.ViewAllProducts_Click);
            // 
            // ViewAllReviews
            // 
            this.ViewAllReviews.Location = new System.Drawing.Point(61, 284);
            this.ViewAllReviews.Margin = new System.Windows.Forms.Padding(4);
            this.ViewAllReviews.Name = "ViewAllReviews";
            this.ViewAllReviews.Size = new System.Drawing.Size(291, 28);
            this.ViewAllReviews.TabIndex = 16;
            this.ViewAllReviews.Text = "View All Reviews";
            this.ViewAllReviews.UseVisualStyleBackColor = true;
            this.ViewAllReviews.Click += new System.EventHandler(this.ViewAllReviews_Click);
            // 
            // ManagerPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 338);
            this.Controls.Add(this.ViewAllReviews);
            this.Controls.Add(this.ViewAllProducts);
            this.Controls.Add(this.ViewEmployees);
            this.Controls.Add(this.ViewSuppliers);
            this.Controls.Add(this.ManagerSettings);
            this.Controls.Add(this.RemoveSupplier);
            this.Controls.Add(this.SetDiscount);
            this.Controls.Add(this.UpdateEmployee);
            this.Controls.Add(this.RemoveEmployee);
            this.Controls.Add(this.AddSupplier);
            this.Controls.Add(this.UpdateSupplier);
            this.Controls.Add(this.InsertEmployee);
            this.Controls.Add(this.LogOutButton);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ManagerPage";
            this.Text = "ManagerPage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ManagerPage_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button LogOutButton;
        private System.Windows.Forms.Button InsertEmployee;
        private System.Windows.Forms.Button UpdateSupplier;
        private System.Windows.Forms.Button AddSupplier;
        private System.Windows.Forms.Button RemoveEmployee;
        private System.Windows.Forms.Button UpdateEmployee;
        private System.Windows.Forms.Button SetDiscount;
        private System.Windows.Forms.Button RemoveSupplier;
        private System.Windows.Forms.Button ManagerSettings;
        private System.Windows.Forms.Button ViewSuppliers;
        private System.Windows.Forms.Button ViewEmployees;
        private System.Windows.Forms.Button ViewAllProducts;
        private System.Windows.Forms.Button ViewAllReviews;
    }
}