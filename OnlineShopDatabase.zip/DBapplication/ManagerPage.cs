﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class ManagerPage : Form
    {
        Form MyParent;
        string s;
        public ManagerPage(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;

        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void ManagerPage_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void InsertEmployee_Click(object sender, EventArgs e)
        {
            InsertEmployee IE = new InsertEmployee(s,this);
            IE.Show();
        }

        private void UpdateEmployee_Click(object sender, EventArgs e)
        {
            UpdateEmployee UE = new UpdateEmployee(s,this);
            UE.Show();
        }

        private void RemoveEmployee_Click(object sender, EventArgs e)
        {
            RemoveEmployee RE = new RemoveEmployee(s,this);
            RE.Show();
        }

        private void ViewEmployees_Click(object sender, EventArgs e)
        {
            ViewEmployees VE = new ViewEmployees(s,this);
            VE.Show();
        }

        private void SetDiscount_Click(object sender, EventArgs e)
        {
            SetDiscount SD = new SetDiscount(s,this);
            SD.Show();
        }

        private void ViewAllProducts_Click(object sender, EventArgs e)
        {
            ViewAllProducts VAP = new ViewAllProducts(s,this);
            VAP.Show();
        }

        private void ViewAllReviews_Click(object sender, EventArgs e)
        {
            ViewAllReviews VAR = new ViewAllReviews(s,this);
            VAR.Show();
        }

        private void AddSupplier_Click(object sender, EventArgs e)
        {
            AddSupplier AS = new AddSupplier(s,this);
            AS.Show();
        }

        private void UpdateSupplier_Click(object sender, EventArgs e)
        {
            UpdateSupplier US = new UpdateSupplier(s,this);
            US.Show();
        }

        private void RemoveSupplier_Click(object sender, EventArgs e)
        {
            RemoveSupplier RS = new RemoveSupplier(s,this);
            RS.Show();
        }

        private void ViewSuppliers_Click(object sender, EventArgs e)
        {
            ViewSuppliers VS = new ViewSuppliers(s,this);
            VS.Show();
        }

        private void ManagerSettings_Click(object sender, EventArgs e)
        {
            ManagerSettings MS = new ManagerSettings(s,this);
            MS.Show();
        }
    }
}
