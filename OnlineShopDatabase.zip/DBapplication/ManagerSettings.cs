﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class ManagerSettings : Form
    {
        Form MyParent;
        string s;
        public ManagerSettings(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;

        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void ManagerSettings_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void Changepasswordbutton_Click(object sender, EventArgs e)
        {
            ManagerChangePassword MCP = new ManagerChangePassword(s,this);
            MCP.Show();
        }
    }
}
