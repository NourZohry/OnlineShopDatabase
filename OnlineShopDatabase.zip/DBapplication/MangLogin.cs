﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class MangLogin : Form
    {
        Controller controllerObj;
        Form MyParent;
        public MangLogin(Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if (MangUserNameTextBox.Text.ToString() == "" || MangPasswordTextBox.Text.ToString() == "")
            {
                MessageBox.Show("Please enter a proper username and password.");
            }
            else
            {
                controllerObj = new Controller();
                int count = controllerObj.EmployeeCheckID(MangUserNameTextBox.Text.ToString(), MangPasswordTextBox.Text.ToString(), "Manager");
                if (count == 0)
                {
                    MessageBox.Show("Incorrect username or password.");
                }
                else
                {
                    int MID = controllerObj.EmployeeGetLoginID(MangUserNameTextBox.Text.ToString(), MangPasswordTextBox.Text.ToString(), "Manager");
                    MessageBox.Show("Sucessfully logged in as a manager.");
                    ManagerPage MP = new ManagerPage(MangUserNameTextBox.Text.ToString(), this);
                    MP.Show();

                    MangUserNameTextBox.Text = null;
                    MangPasswordTextBox.Text = null;

                }
            }
        }


        private void MangLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }
    } 
}
