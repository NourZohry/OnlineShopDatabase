﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class PostReview : Form
    {
        Controller controllerObj;
        Form MyParent;
        string s;
        public PostReview(string id, Form p)
        {
            InitializeComponent();
            controllerObj = new Controller();
            MyParent = p;
            MyParent.Hide();
            s = id;
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            //controllerObj = new Controller();
            if (ReviewComboBox.Text == "")
            {
                MessageBox.Show("Please select a rating.");
                return;
            }
            int HighestRevNum = controllerObj.GetHighestRevNum();
            int CID = controllerObj.GetCustomerID(s);
            int r = controllerObj.PostReview(HighestRevNum+1, Int16.Parse(ReviewComboBox.Text), CID);
            if (r > 0)
            {
                MessageBox.Show("Thank you for reviewing!");
            }
            else
                MessageBox.Show("Error occurred. Try again later.");
        }
    }
}
