﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class PrintReviewReport : Form
    {
        Form MyParent;
        string s;
        public PrintReviewReport(string id,Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void PrintReviewReport_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }
    }
}
