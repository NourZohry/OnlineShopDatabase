﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class RemoveEmployee : Form
    {
        Form MyParent;
        string s;
        Controller obj;
        public RemoveEmployee(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            obj = new Controller();
            DataTable dt = obj.SelectEmpEID();
            EmployeeUsernamecomboBox.DataSource = dt;
            EmployeeUsernamecomboBox.DisplayMember = "Username";
            EmployeeUsernamecomboBox.ValueMember = "Username";

        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void RemoveEmployee_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void RemoveEmployeebutton_Click(object sender, EventArgs e)
        {
            int result = obj.DeleteEmployee(EmployeeUsernamecomboBox.Text);
            if (result == 0)
            {
                MessageBox.Show("No Employee are deleted");
            }
            else
            {
                MessageBox.Show("The Employee is deleted successfully!");
            }
        }
    }
}
