﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class RemoveManager : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public RemoveManager(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            controllerObj = new Controller();

            DataTable dt = controllerObj.SelectManagerUsername();
            ManagerUsernamecomboBox.DataSource = dt;
            ManagerUsernamecomboBox.DisplayMember = "Username";
            ManagerUsernamecomboBox.ValueMember = "Username";
        }

        private void RemoveManagerbutton_Click(object sender, EventArgs e)
        {
            int result = controllerObj.DeleteManager(ManagerUsernamecomboBox.Text);
            if (result == 0)
            {
                MessageBox.Show("No Manager are deleted");
            }
            else
            {
                MessageBox.Show("The Manager is deleted successfully!");
            }

        }

        private void RemoveManager_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }
    }
}
