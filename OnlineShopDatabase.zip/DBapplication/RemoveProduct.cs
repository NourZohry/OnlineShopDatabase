﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class RemoveProduct : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public RemoveProduct(string id, Form p)
        {
            InitializeComponent();
            controllerObj = new Controller();
            MyParent = p;
            MyParent.Hide();
            s = id;
            DataTable dt = controllerObj.SelectProducts();
            ProductNameComboBox.DataSource = dt;
            ProductNameComboBox.DisplayMember = "ProdName";
            ProductNameComboBox.ValueMember = "ProdName";


        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void RemoveProduct_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void Removeproductbutton_Click(object sender, EventArgs e)
        {
            int result = controllerObj.DeleteProduct(ProductNameComboBox.Text);
            if (result == 0)
            {
                MessageBox.Show("No Products are deleted");
            }
            else
            {
                MessageBox.Show("The Product is deleted successfully!");
            }
        }
    }
}
