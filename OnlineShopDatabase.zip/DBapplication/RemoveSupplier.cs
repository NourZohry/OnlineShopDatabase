﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class RemoveSupplier : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public RemoveSupplier(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            controllerObj = new Controller();
            DataTable dt = controllerObj.SelectSID();
            SupplierNamecomboBox.DataSource = dt;
            SupplierNamecomboBox.DisplayMember = "Name";
            SupplierNamecomboBox.ValueMember = "Name";
        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void RemoveSupplier_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void RemoveSupplierbutton_Click(object sender, EventArgs e)
        {
            int result = controllerObj.DeleteSupplier(SupplierNamecomboBox.Text);
            if (result == 0)
            {
                MessageBox.Show("Supplier isn't deleted");
            }
            else
            {
                MessageBox.Show("The supplier is deleted successfully!");
            }

        }
    }
}
