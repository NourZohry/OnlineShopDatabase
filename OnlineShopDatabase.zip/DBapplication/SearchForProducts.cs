﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class SearchForProducts : Form
    {
        Controller controllerObj;
        Form MyParent;
        string s;
        public SearchForProducts(string id,Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;

            controllerObj = new Controller();
            DataTable dt = controllerObj.SelectCategories();
            CategoryCombobox.DataSource = dt;
            CategoryCombobox.DisplayMember = "CatName";
            CategoryCombobox.ValueMember = "CatName";
        }

        private void ProductDataGrid_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //int Index = ProductDataGrid.CurrentRow.Index;
            //MessageBox.Show(ProductDataGrid.SelectedCells[Index].Value.ToString());
            if (e.RowIndex < 0)
                return;
            //MessageBox.Show(ProductDataGrid.Rows[e.RowIndex].Cells[0].Value.ToString());
            string ProdID = ProductDataGrid.Rows[e.RowIndex].Cells[0].Value.ToString();
            controllerObj = new Controller();
            
            int CID = controllerObj.GetCustomerID(s);
            int Check = controllerObj.CheckOrdID(CID); //0 -> no order exists, make new order
            int r;
            if (Check == 0) //0 -> no order exists, make new order
            {
                int HighestOrdID = controllerObj.GetHighestOrdID();
                r = controllerObj.CreateOrder(HighestOrdID + 1, CID);
            }
            /*
            else //1 -> order exists, get the OrdID and add the product/order
            {
                OrdID = controllerObj.GetOrdID(CID);
                r = controllerObj.AddProductToOrder(OrdID, ProdID);
            }
            */
            if (controllerObj.CheckIfAdded(ProdID,CID) > 0)
            {
                MessageBox.Show("This product is already in your order.");
                return;
            }

            int OrdID = controllerObj.GetOrdID(CID);
            r = controllerObj.AddProductToOrder(OrdID, ProdID);
            MessageBox.Show("Added " + ProductDataGrid.Rows[e.RowIndex].Cells[1].Value.ToString() + " to your Order!");
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void ViewAllProducts_Click(object sender, EventArgs e)
        {
            controllerObj = new Controller();
            if (controllerObj.CheckProducts() == 0)
            {
                MessageBox.Show("No products available for sale at the moment.");
                return;
            }
            DataTable dt = controllerObj.ViewAllProductsVer2();
            ProductDataGrid.DataSource = dt;
            ProductDataGrid.Columns["ProdID"].Visible = false;
            ProductDataGrid.Refresh();
        }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            if (CategoryCombobox.Text == "")
                MessageBox.Show("Please select a category.");
            else
            {
                int CatCount = controllerObj.CheckCategory(CategoryCombobox.Text);
                if (CatCount > 0)
                { 
                    DataTable dt = controllerObj.GetCategories(CategoryCombobox.Text);
                    ProductDataGrid.DataSource = dt;
                    ProductDataGrid.Columns["ProdID"].Visible = false;
                    ProductDataGrid.Refresh();
                }
                else
                {
                    MessageBox.Show("No products available in the selected category.");
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            controllerObj = new Controller();
            DataTable dt = controllerObj.SearchProducts(textBox1.Text);
            if (dt == null)
            {
                MessageBox.Show("No search results.");
                return;
            }
            ProductDataGrid.DataSource = dt;
            ProductDataGrid.Columns["ProdID"].Visible = false;
            ProductDataGrid.Refresh();
        }
    }
}
