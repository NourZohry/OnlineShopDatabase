﻿namespace DBapplication
{
    partial class SetDiscount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Discounttextbox = new System.Windows.Forms.TextBox();
            this.ProductIDcomboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SetDiscountbutton = new System.Windows.Forms.Button();
            this.Returnbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Discounttextbox
            // 
            this.Discounttextbox.Location = new System.Drawing.Point(121, 92);
            this.Discounttextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Discounttextbox.Name = "Discounttextbox";
            this.Discounttextbox.Size = new System.Drawing.Size(121, 22);
            this.Discounttextbox.TabIndex = 11;
            // 
            // ProductIDcomboBox
            // 
            this.ProductIDcomboBox.FormattingEnabled = true;
            this.ProductIDcomboBox.Location = new System.Drawing.Point(121, 25);
            this.ProductIDcomboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ProductIDcomboBox.Name = "ProductIDcomboBox";
            this.ProductIDcomboBox.Size = new System.Drawing.Size(121, 24);
            this.ProductIDcomboBox.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Discount";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Product Name";
            // 
            // SetDiscountbutton
            // 
            this.SetDiscountbutton.Location = new System.Drawing.Point(157, 166);
            this.SetDiscountbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SetDiscountbutton.Name = "SetDiscountbutton";
            this.SetDiscountbutton.Size = new System.Drawing.Size(119, 32);
            this.SetDiscountbutton.TabIndex = 7;
            this.SetDiscountbutton.Text = "Set Discount";
            this.SetDiscountbutton.UseVisualStyleBackColor = true;
            this.SetDiscountbutton.Click += new System.EventHandler(this.SetDiscountbutton_Click);
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(304, 166);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 32);
            this.Returnbutton.TabIndex = 6;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // SetDiscount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(395, 222);
            this.Controls.Add(this.Discounttextbox);
            this.Controls.Add(this.ProductIDcomboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SetDiscountbutton);
            this.Controls.Add(this.Returnbutton);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "SetDiscount";
            this.Text = "SetDiscount";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SetDiscount_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Discounttextbox;
        private System.Windows.Forms.ComboBox ProductIDcomboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SetDiscountbutton;
        private System.Windows.Forms.Button Returnbutton;
    }
}