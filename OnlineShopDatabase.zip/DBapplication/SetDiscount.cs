﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class SetDiscount : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public SetDiscount(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            controllerObj = new Controller();
            DataTable dt = controllerObj.SelectProducts();
            ProductIDcomboBox.DataSource = dt;
            ProductIDcomboBox.DisplayMember = "ProdName";
            ProductIDcomboBox.ValueMember = "ProdName";

        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void SetDiscount_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void SetDiscountbutton_Click(object sender, EventArgs e)
        {
            if (Discounttextbox.Text == "" )
            {
                MessageBox.Show("Please insert the discount.");
            }
            else
            {
                StringBuilder err = new StringBuilder();
                Object Discount = ValidationClass.isPositiveInteger(Discounttextbox.Text, err);
                if (Discount == null)
                {
                    MessageBox.Show("Some inputs has incorrect values " + err.ToString());
                }
                else
                {
                    int r = controllerObj.ProductDiscount(ProductIDcomboBox.Text, (int)Discount);
                    if (r > 0)
                    {
                        MessageBox.Show("Discount inserted successfully");

                    }
                    else
                        MessageBox.Show("Insertion Failed");
                }
            }

        }
    }
}
