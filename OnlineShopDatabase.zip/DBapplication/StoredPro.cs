﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DBapplication
{
    class StoredPro
    {
        public static string InsertCustomer = "InsertCustomer";
        public static string InsertEmployee = "InsertEmployee";
        public static string InsertManager = "InsertManager";
        public static string ViewAllProducts = "ViewAllProducts";
        public static string ViewAllSuppliers = "ViewAllSuppliers";
        public static string ViewAllReviews = "ViewAllReviews";
        public static string ViewAllEmployees = "ViewAllEmployees";
        public static string AddProduct = "AddProduct";
    }
}

