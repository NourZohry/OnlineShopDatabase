﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class UpdateEmployee : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public UpdateEmployee(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            controllerObj = new Controller();
            DataTable dt = controllerObj.SelectEmpUsername();
            EmployeeUsernamecomboBox.DataSource = dt;
            EmployeeUsernamecomboBox.DisplayMember = "Username";

        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void UpdateEmployee_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void UpdateEmployeebutton_Click(object sender, EventArgs e)
        {
            if (SalarytextBox.Text == "" || EmployeeUsernamecomboBox.Text == "")
            {
                MessageBox.Show("Please, insert all values");
            }
            else
            {
                StringBuilder err = new StringBuilder();
                Object Salary = ValidationClass.isPositiveInteger(SalarytextBox.Text, err);
                if (Salary == null)
                {
                    MessageBox.Show("Some inputs has incorrect values " + err.ToString());
                }
                else
                {
                    int r = controllerObj.UpdateEmployee((int)Salary,EmployeeUsernamecomboBox.Text);
                    MessageBox.Show("Employee updated successfully");
                }
            }
        }
    }
}
