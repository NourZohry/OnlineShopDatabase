﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class UpdateProduct : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public UpdateProduct(string id, Form p)
        {
            InitializeComponent();
            controllerObj = new Controller();
            MyParent = p;
            MyParent.Hide();
            s = id;
            DataTable dt = controllerObj.SelectProducts();
            ProductNameComboBox.DataSource = dt;
            ProductNameComboBox.DisplayMember = "ProdName";
            ProductNameComboBox.ValueMember = "ProdName";
        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void UpdateProduct_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void UpdateProductbutton_Click_1(object sender, EventArgs e)
        {
            if (Pricetextbox.Text == "")
            {
                MessageBox.Show("Please insert the price.");
            }
            else
            {
                StringBuilder err = new StringBuilder();
                Object Price = ValidationClass.isPositiveInteger(Pricetextbox.Text, err);
                if (Price == null)
                {
                    MessageBox.Show("Some inputs has incorrect values " + err.ToString());
                }
                else
                {
                    int r = controllerObj.UpdatePrice((int)Price,ProductNameComboBox.Text);
                    if (r > 0)
                    {
                        MessageBox.Show("Price Updated successfully");

                    }
                    else
                        MessageBox.Show("Updating Failed");

                }
            }
        }
    }
}
