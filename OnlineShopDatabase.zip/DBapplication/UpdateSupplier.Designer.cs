﻿namespace DBapplication
{
    partial class UpdateSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Phonetextbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.UpdateSupplierbutton = new System.Windows.Forms.Button();
            this.Returnbutton = new System.Windows.Forms.Button();
            this.AddresstextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SupplierNamecomboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Phonetextbox
            // 
            this.Phonetextbox.Location = new System.Drawing.Point(115, 107);
            this.Phonetextbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Phonetextbox.Name = "Phonetextbox";
            this.Phonetextbox.Size = new System.Drawing.Size(121, 22);
            this.Phonetextbox.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Phone";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Address";
            // 
            // UpdateSupplierbutton
            // 
            this.UpdateSupplierbutton.Location = new System.Drawing.Point(151, 167);
            this.UpdateSupplierbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.UpdateSupplierbutton.Name = "UpdateSupplierbutton";
            this.UpdateSupplierbutton.Size = new System.Drawing.Size(119, 32);
            this.UpdateSupplierbutton.TabIndex = 7;
            this.UpdateSupplierbutton.Text = "Update supplier";
            this.UpdateSupplierbutton.UseVisualStyleBackColor = true;
            this.UpdateSupplierbutton.Click += new System.EventHandler(this.UpdateSupplierbutton_Click);
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(297, 167);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 32);
            this.Returnbutton.TabIndex = 6;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // AddresstextBox
            // 
            this.AddresstextBox.Location = new System.Drawing.Point(115, 69);
            this.AddresstextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AddresstextBox.Name = "AddresstextBox";
            this.AddresstextBox.Size = new System.Drawing.Size(121, 22);
            this.AddresstextBox.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "Supplier Name";
            // 
            // SupplierNamecomboBox
            // 
            this.SupplierNamecomboBox.FormattingEnabled = true;
            this.SupplierNamecomboBox.Location = new System.Drawing.Point(115, 26);
            this.SupplierNamecomboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SupplierNamecomboBox.Name = "SupplierNamecomboBox";
            this.SupplierNamecomboBox.Size = new System.Drawing.Size(121, 24);
            this.SupplierNamecomboBox.TabIndex = 14;
            // 
            // UpdateSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(392, 220);
            this.Controls.Add(this.SupplierNamecomboBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AddresstextBox);
            this.Controls.Add(this.Phonetextbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UpdateSupplierbutton);
            this.Controls.Add(this.Returnbutton);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "UpdateSupplier";
            this.Text = "UpdateSupplier";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.UpdateSupplier_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Phonetextbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button UpdateSupplierbutton;
        private System.Windows.Forms.Button Returnbutton;
        private System.Windows.Forms.TextBox AddresstextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox SupplierNamecomboBox;
    }
}