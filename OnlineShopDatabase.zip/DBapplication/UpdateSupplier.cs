﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class UpdateSupplier : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public UpdateSupplier(string id, Form p)
        {
            InitializeComponent();
            controllerObj = new Controller();
            MyParent = p;
            MyParent.Hide();
            s = id;
            DataTable dt = controllerObj.SelectSID();
            SupplierNamecomboBox.DataSource = dt;
            SupplierNamecomboBox.DisplayMember = "Name";
            SupplierNamecomboBox.ValueMember = "Name";

        }

        private void Returnbutton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void UpdateSupplier_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void UpdateSupplierbutton_Click(object sender, EventArgs e)
        {
            if (AddresstextBox.Text == "" && Phonetextbox.Text == "")
            {
                MessageBox.Show("Please insert either the address or Phone or insert both.");
            }
            else
            {
                if (AddresstextBox.Text != "")
                {
                    int r = controllerObj.UpdateSupplierAddress(SupplierNamecomboBox.Text, AddresstextBox.Text);
                    if (r > 0)
                    {
                        MessageBox.Show("Address Updated successfully");

                    }
                    else
                        MessageBox.Show("Updating Address Failed");

                }


                if (Phonetextbox.Text != "")
                {
                    int r1 = controllerObj.UpdateSupplierPhone(SupplierNamecomboBox.Text, Phonetextbox.Text);
                    if (r1 > 0)
                    {
                        MessageBox.Show("Phone Updated successfully");

                    }
                    else
                        MessageBox.Show("Updating Phone Failed");
                }
                

            }
            }
        }
    }

