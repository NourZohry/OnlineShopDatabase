﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class ViewAllManagers : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public ViewAllManagers(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            controllerObj = new Controller();
            DataTable dt = controllerObj.ViewAllManagers();
            ViewManagersGridView.DataSource = dt;
            ViewManagersGridView.Refresh();
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void ViewAllManagers_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }
    }
}
