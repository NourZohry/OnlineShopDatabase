﻿namespace DBapplication
{
    partial class ViewAllProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ViewProductdataGridView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.Returnbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ViewProductdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ViewProductdataGridView
            // 
            this.ViewProductdataGridView.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.ViewProductdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ViewProductdataGridView.GridColor = System.Drawing.Color.White;
            this.ViewProductdataGridView.Location = new System.Drawing.Point(45, 91);
            this.ViewProductdataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ViewProductdataGridView.Name = "ViewProductdataGridView";
            this.ViewProductdataGridView.RowHeadersWidth = 51;
            this.ViewProductdataGridView.RowTemplate.Height = 24;
            this.ViewProductdataGridView.Size = new System.Drawing.Size(685, 286);
            this.ViewProductdataGridView.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(280, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "All products";
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(713, 392);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 36);
            this.Returnbutton.TabIndex = 2;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // ViewAllProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Returnbutton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ViewProductdataGridView);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ViewAllProducts";
            this.Text = "View Products";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ViewAllProducts_FormClosed);
            this.Load += new System.EventHandler(this.ViewAllProducts_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ViewProductdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ViewProductdataGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Returnbutton;
    }
}