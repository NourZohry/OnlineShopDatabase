﻿namespace DBapplication
{
    partial class ViewCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Returnbutton = new System.Windows.Forms.Button();
            this.ViewCustomersGrid = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ViewCustomersGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // Returnbutton
            // 
            this.Returnbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnbutton.Location = new System.Drawing.Point(695, 383);
            this.Returnbutton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Returnbutton.Name = "Returnbutton";
            this.Returnbutton.Size = new System.Drawing.Size(75, 27);
            this.Returnbutton.TabIndex = 0;
            this.Returnbutton.Text = "Return";
            this.Returnbutton.UseVisualStyleBackColor = true;
            this.Returnbutton.Click += new System.EventHandler(this.Returnbutton_Click);
            // 
            // ViewCustomersGrid
            // 
            this.ViewCustomersGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.ViewCustomersGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ViewCustomersGrid.GridColor = System.Drawing.Color.White;
            this.ViewCustomersGrid.Location = new System.Drawing.Point(72, 78);
            this.ViewCustomersGrid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ViewCustomersGrid.Name = "ViewCustomersGrid";
            this.ViewCustomersGrid.RowHeadersWidth = 51;
            this.ViewCustomersGrid.RowTemplate.Height = 24;
            this.ViewCustomersGrid.Size = new System.Drawing.Size(659, 279);
            this.ViewCustomersGrid.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(249, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "All the customers";
            // 
            // ViewCustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ViewCustomersGrid);
            this.Controls.Add(this.Returnbutton);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ViewCustomers";
            this.Text = "View Customers";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ViewCustomers_FormClosed);
            this.Load += new System.EventHandler(this.ViewCustomers_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.ViewCustomersGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Returnbutton;
        private System.Windows.Forms.DataGridView ViewCustomersGrid;
        private System.Windows.Forms.Label label1;
    }
}