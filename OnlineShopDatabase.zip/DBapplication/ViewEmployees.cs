﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class ViewEmployees : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public ViewEmployees(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            controllerObj = new Controller();
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void ViewEmployees_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void ViewEmployees_Load(object sender, EventArgs e)
        {
            DataTable dt = controllerObj.ViewAllEmployees();
            ViewEmployeesGridView.DataSource = dt;
            ViewEmployeesGridView.Refresh();
        }
    }
}
