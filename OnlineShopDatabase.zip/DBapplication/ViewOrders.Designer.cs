﻿namespace DBapplication
{
    partial class ViewOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReturnButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ViewAllOrdersButton = new System.Windows.Forms.Button();
            this.ViewOngoingOrdersButton = new System.Windows.Forms.Button();
            this.OrderLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // ReturnButton
            // 
            this.ReturnButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnButton.Location = new System.Drawing.Point(709, 334);
            this.ReturnButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(75, 38);
            this.ReturnButton.TabIndex = 7;
            this.ReturnButton.Text = "Return";
            this.ReturnButton.UseVisualStyleBackColor = true;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(17, 114);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(767, 213);
            this.dataGridView1.TabIndex = 8;
            // 
            // ViewAllOrdersButton
            // 
            this.ViewAllOrdersButton.Location = new System.Drawing.Point(216, 15);
            this.ViewAllOrdersButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ViewAllOrdersButton.Name = "ViewAllOrdersButton";
            this.ViewAllOrdersButton.Size = new System.Drawing.Size(191, 58);
            this.ViewAllOrdersButton.TabIndex = 9;
            this.ViewAllOrdersButton.Text = "View All Orders";
            this.ViewAllOrdersButton.UseVisualStyleBackColor = true;
            this.ViewAllOrdersButton.Click += new System.EventHandler(this.ViewAllOrdersButton_Click);
            // 
            // ViewOngoingOrdersButton
            // 
            this.ViewOngoingOrdersButton.Location = new System.Drawing.Point(17, 15);
            this.ViewOngoingOrdersButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ViewOngoingOrdersButton.Name = "ViewOngoingOrdersButton";
            this.ViewOngoingOrdersButton.Size = new System.Drawing.Size(191, 58);
            this.ViewOngoingOrdersButton.TabIndex = 10;
            this.ViewOngoingOrdersButton.Text = "View Ongoing Orders";
            this.ViewOngoingOrdersButton.UseVisualStyleBackColor = true;
            this.ViewOngoingOrdersButton.Click += new System.EventHandler(this.ViewOngoingOrdersButton_Click);
            // 
            // OrderLabel
            // 
            this.OrderLabel.AutoSize = true;
            this.OrderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderLabel.Location = new System.Drawing.Point(16, 86);
            this.OrderLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.OrderLabel.Name = "OrderLabel";
            this.OrderLabel.Size = new System.Drawing.Size(171, 20);
            this.OrderLabel.TabIndex = 11;
            this.OrderLabel.Text = "Showing all orders:";
            // 
            // ViewOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DBapplication.Properties.Resources.Login;
            this.ClientSize = new System.Drawing.Size(799, 385);
            this.Controls.Add(this.OrderLabel);
            this.Controls.Add(this.ViewOngoingOrdersButton);
            this.Controls.Add(this.ViewAllOrdersButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ReturnButton);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ViewOrders";
            this.Text = "View Orders";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ReturnButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ViewAllOrdersButton;
        private System.Windows.Forms.Button ViewOngoingOrdersButton;
        private System.Windows.Forms.Label OrderLabel;
    }
}