﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class ViewOrders : Form
    {
        Controller controllerObj;
        Form MyParent;
        string s;
        public ViewOrders(string id, Form p)
        {
            controllerObj = new Controller();
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;

        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void ViewAllOrdersButton_Click(object sender, EventArgs e)
        {
            int CID = controllerObj.GetCustomerID(s);
            int Check = controllerObj.CheckAnyOrder(CID);
            if (Check > 0)
            {
                //DataTable dt = controllerObj.ViewAllOrders(CID);
                DataTable dt = controllerObj.ViewAllOrdersVer2(CID);
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
            }
            else
            {
                MessageBox.Show("You haven't made any orders.");
            }
        }

        private void ViewOngoingOrdersButton_Click(object sender, EventArgs e)
        {
                int CID = controllerObj.GetCustomerID(s);
                int Check = controllerObj.CheckOngoingOrder(CID);
                if (Check > 0)
                {
                    //DataTable dt = controllerObj.ViewAllOrders(CID);
                    DataTable dt = controllerObj.ViewOngoingOrders(CID);
                    dataGridView1.DataSource = dt;
                    dataGridView1.Refresh();
                }
                else
                {
                    MessageBox.Show("No ongoing orders.");
                }
        }
    }
}
