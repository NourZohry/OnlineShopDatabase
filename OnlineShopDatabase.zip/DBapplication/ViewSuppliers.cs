﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class ViewSuppliers : Form
    {
        Form MyParent;
        string s;
        Controller controllerObj;
        public ViewSuppliers(string id, Form p)
        {
            InitializeComponent();
            MyParent = p;
            MyParent.Hide();
            s = id;
            controllerObj = new Controller();

        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            MyParent.Show();
            this.Close();
        }

        private void ViewSuppliers_FormClosed(object sender, FormClosedEventArgs e)
        {
            MyParent.Show();
        }

        private void ViewSuppliers_Load(object sender, EventArgs e)
        {
            DataTable dt = controllerObj.ViewAllSuppliers();
            ViewSuppliersGridView.DataSource = dt;
            ViewSuppliersGridView.Refresh();
        }
    }
}
