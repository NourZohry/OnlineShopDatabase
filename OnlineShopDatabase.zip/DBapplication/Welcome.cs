﻿using System; 
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DBapplication
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            
            InitializeComponent();
        }

        private void ManagerButton_Click(object sender, EventArgs e)
        {
            MangLogin ML = new MangLogin(this);
            ML.Show();
        }

        private void EmployeeButton_Click(object sender, EventArgs e)
        {
            EmpLogin EL = new EmpLogin(this);
            EL.Show();
        }

        private void CustomerButton_Click(object sender, EventArgs e)
        {
            CustRegLog CRL = new CustRegLog(this);
            CRL.Show();
        }

        private void Adminbutton_Click(object sender, EventArgs e)
        {
            AdminLogin AD = new AdminLogin(this);
            AD.Show();
        }
    }
}
