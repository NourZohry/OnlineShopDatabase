-------------Database creation-------------
--create database Online Shop
Create database Online_Shop1
GO
use Online_Shop1

------------Table Creation-----------------
create table Manager
(
Fname varchar(50) not null,
Minit char(1) not null,
Lname varchar(50) not null,
MID int,
primary key (MID),
Salary int,
Sex char(1),
Bdate date,
Username varchar(50) unique,
Password varchar(100),
CatID int,
)

create table Employee
(
Fname varchar(50) not null,
Minit char(1) not null,
Lname varchar(50) not null,
EID int,
primary key (EID),
Salary int,
Sex char(1),
Bdate date,
Username varchar(50) unique,
Password varchar(100),
MID int,
)

create table Supplier
(
Name varchar(50) not null,
SID int not null,
Address varchar(200),
Phone varchar(50),
Email  varchar(200),
URL  varchar(200),
primary key (SID),
MID int,
)

create table Customer
(
Fname varchar(50) not null,
Minit char(1) not null,
Lname varchar(50) not null,
CID int,
primary key (CID),
Address varchar(200),
Phone varchar(50), 
CreditNum varchar(100),
Email varchar(200),
Sex char(1),
Bdate date,
Username varchar(50) unique,
Password varchar(100),
EID int,
)

create table Category
(
CatID int,
CatName varchar(100) not null,
Description varchar(500),
primary key (CatID)
)

create table AddRemove
(
EID int,
ProdID int,
primary key (EID,ProdID),
)

create table Orders
(
OrdID int,
OrderDate date,
PaymentMethod varchar(50), 
CID int,
Primary key (OrdID) 
)

create table Product
(
ProdID int,
ProdName varchar(200),
Size float,
Color varchar(50),
Price float not null,
Discount int,
Weight float,
MID int, 
CatID int, 
OrdID int,  
primary key (ProdID),
)

create table Deliver
(
EID int,
CID int,
ShipID int,
primary key (EID,CID,ShipID),
)

create table ShippedItem
(
ShipID int,
primary key (ShipID),
ShipPrice float not null,
DeliveryDate date,
ShipDate date,
)

create table Review 
(
RevNum int,
RevDate date not null,
RevRate int not null,
primary key (RevNum),
CID int,
)

create table Search_For
(
CID int,
ProdID int,
Primary key (CID,ProdID)
)

create table Admins
(
Username varchar(50),
Password varchar(50),
AID int,
primary key (AID),
)

-----------inserting Foreign key--------------

alter table Manager add foreign key (CatID) references Category
alter table Employee add foreign key (MID) references Manager
alter table Supplier add foreign key (MID) references Manager
alter table Customer add foreign key (EID) references Employee
alter table AddRemove add foreign key (EID) references Employee
alter table AddRemove add foreign key (ProdID) references Product
alter table Orders add foreign key (CID) references Customer
alter table Product add foreign key (MID) references Manager
alter table Product add foreign key (CatID) references Category
alter table Product add foreign key (OrdID) references Orders
alter table Deliver add foreign key (EID) references Employee
alter table Deliver add foreign key (CID) references Customer
alter table Deliver add foreign key (ShipID) references ShippedItem
alter table Review add foreign key (CID) references Customer
alter table Search_For add foreign key (CID) references Customer
alter table Search_For add foreign key (ProdID) references Product

---------------Inserting values into tables----------------

insert into Manager -- Fname | Minit | Lname | MID | Salary | M/F | Bdate | Username | Password | CatID
values 
('Rory','A','Stewart',1,35000,'M','1982-08-08','RoryA',HASHBYTES('MD5','12345678'),null),
('George','F','Harper',2,34000,'M','1969-01-22','GeorgeF',HASHBYTES('MD5','george123a'),null),
('Bradley','G','Brooks',3,33000,'M','1975-02-23','BradleyG',HASHBYTES('MD5','pass242here'),null),
('Ewan','A','Campbell',4,32000,'M','1977-06-05','EwanA',HASHBYTES('MD5','campy23141'),null),
('Harley','E','Snyder',5,38000,'F','1977-08-03','HarleyE',HASHBYTES('MD5','synderrrr623'),null),
('Barden','T','Brewer',6,32000,'M','1996-05-03','BardenT',HASHBYTES('MD5','woi2222'),null),
('Kale','E','Allen',7,32500,'M','1982-03-11','KaleE',HASHBYTES('MD5','kea50323'),null),
('Quinn','W','Cox',8,29000,'M','1991-04-02','QuinnW',HASHBYTES('MD5','coxwwwww312'),null),
('Holden','S','Jones',9,40000,'M','1981-03-25','HoldenS',HASHBYTES('MD5','holdenup123'),null),
('Jaeden','K','Henderson',10,35000,'M','1982-04-04','JaedenK',HASHBYTES('MD5','hendyyy3535'),null),
('Arin','U','Rivas',11,29000,'F','1984-10-16','ArinU',HASHBYTES('MD5','rivas222242'),null),
('Aaron','N','Carney',12,34000,'M','1982-02-14','AaronN',HASHBYTES('MD5','puppylover231'),null),
('Christopher','H','Sawyer',13,37000,'F','1991-03-13','ChristopherH',HASHBYTES('MD5','cleaguefrewis'),null),
('Oscar','Y','Woods',14,34000,'F','1982-04-26','OscarY',HASHBYTES('MD5','bobvexturia'),null),
('Peter','H','Clarke',15,33000,'M','1987-06-24','PeterH',HASHBYTES('MD5','knearnormick'),null),
('Sebastian','I','Schneider',16,32000,'M','1981-02-04','SebastianI',HASHBYTES('MD5','femeve'),null),
('Ciel','K','West',17,36000,'M','1972-02-02','CielK',HASHBYTES('MD5','potgught'),null),
('Emilia','N','Ware',18,40000,'M','1980-04-02','EmiliaN',HASHBYTES('MD5','cleabdomp'),null),
('Jack','M','Forbes',19,35000,'M','1991-04-03','JackM',HASHBYTES('MD5','pookadd'),null),
('Jeremy','V','Andrews',20,35000,'M','1988-03-03','JeremyV',HASHBYTES('MD5','drargese'),null)

insert into Employee -- Fname | Minit | Lname | EID | Salary | M/F | Bdate | Username | Password | MID
values
('Andrew','B','Balcom',1,20000,'M','1980-09-09','AndrewB',HASHBYTES('MD5','joukertias234'),null),
('Benjamin','D','Lopez',2,25000,'M','1970-02-23','BenjaminD',HASHBYTES('MD5','soognappy231'),null),
('Christopher','S','Hansen',3,23000,'M','1976-01-22','ChristopherS',HASHBYTES('MD5','zeferaa121'),null),
('Donald','S','Washington',4,26000,'M','1977-05-06','DonaldS',HASHBYTES('MD5','donalddisco2312'),null),
('Elizabeth','D','Grant',5,28000,'F','1975-06-01','ElizabethD',HASHBYTES('MD5','rubberyduckies41'),null),
('Franklin','T','Rivera',6,22000,'M','1990-04-04','FranklinT',HASHBYTES('MD5','lemonpie034'),null),
('George','N','Perkins',7,22500,'M','1983-09-15','GeorgeN',HASHBYTES('MD5','unfairlife632'),null),
('Hans','C','Andersen',8,19000,'M','1993-02-04','HansC',HASHBYTES('MD5','gamegrumps9472'),null),
('Marcus','W','Meyer',9,30000,'M','1985-07-27','MarcusW',HASHBYTES('MD5','sixdogs524'),null),
('Johnson','D','Gonzalez',10,25000,'M','1983-03-04','JohnsonD',HASHBYTES('MD5','thrillerbest323'),null),
('Sarah','J','Wilde',11,19000,'F','1997-11-15','SarahJ',HASHBYTES('MD5','nonsense412'),null),
('Cameron','C','Chambers',12,24000,'M','1993-07-18','CameronC',HASHBYTES('MD5','fastlegs394'),null),
('Fiona','M','Pax',13,27000,'F','1992-05-19','FionaM',HASHBYTES('MD5','herowarrior342'),null),
('Tracey','F','Ceravee',14,24000,'F','1992-07-22','TraceyF',HASHBYTES('MD5','medievalman352'),null),
('Jimmy','N','Martinez',15,23000,'M','1989-04-25','JimmyN',HASHBYTES('MD5','fireplace143'),null),
('Steve','B','Miller',16,22000,'M','1983-03-05','SteveB',HASHBYTES('MD5','monopolyman942'),null),
('Michael','T','Garcia',17,26000,'M','1982-01-01','MichaelT',HASHBYTES('MD5','creditglass341'),null),
('Alfredo','S','Diaz',18,30000,'M','1990-05-03','AlfredoS',HASHBYTES('MD5','locayo462'),null),
('Gavin','H','Free',19,25000,'M','1993-06-06','GavinH',HASHBYTES('MD5','gavfree928'),null),
('Scott','N','Free',20,25000,'M','1993-06-06','ScottN',HASHBYTES('MD5','cookiemunch352'),null)

insert into Supplier -- Name | SID | Address | Phone | Email | URL | MID
values
('Google',1,'1600 Amphitheatre Parkway, Mountain View, CA','(919) 468-1502','google@gmail.com','www.google.com',null),
('Microsoft',2,'2214 Grande Valley Cir, Cary, NC, 27513 ','(716) 773-7019','microsoft@hotmail.com','www.microsoft.com',null),
('Dell',3,'164 Marlin Dr, Grand Island, NY, 14072','(225) 435-0062','dell@yahoo.com','www.dell.com',null),
('Philips',4,'29791 E Highland St, Livingston, LA, 70754 ','(503) 925-8478','philips@yahoo.com','www.philips.com',null),
('Kellogg',5,'23337 SW Cinnamon Hill Pl, Sherwood, OR, 97140','(770) 507-3151','kelloggcompany@gmail.com','www.kelloggcompany.com',null),
('Nike',6,'4222 Entrance Orch, Rex, GA, 30273',null,'nike@yahoo.com','www.nike.com',null),
('Adidas',7,'1015 Brick Mill Rd, Honea Path, SC, 29654','(406) 377-1767','adidas@hotmail.com','www.adidas.com',null),
('Ferrari',8,'301 Pine St, Glendive, MT, 59330','(405) 275-2226','ferrari@yahoo.com','www.ferrari.com',null),
('LG',9,'1955 N Louisa Ave, Shawnee, OK, 74804','(608) 884-6247','LG@yahoo.com','www.lg.com',null),
('Lacoste',10,'316 Spencer Rd, Edgerton, WI, 53534','01002534346','lacoste@gamil.com','www.lacoste.com',null),
('Louis Vuitton',11,'2661 Pahmeyer Rd, New Braunfels, TX, 78130','(830) 625-3940','louisvuitton@yahoo.com','eu.louisvuitton.com',null),
('Crocs',12,'410 Upper Snuff Mill Row #146, Hockessin, DE, 19707','01008395839','crocs@gmail.com','www.crocs.com',null),
('Toys R Us',13,'1911 Harvey Straughn Rd, Townsend, DE, 19734','01004729406','toysrus@yahoo.com','www.toysrus.com',null),
('Opel',14,'7 Lauras Way, Rehoboth Beach, DE, 19971','(214) 256-4071','opel@yahoo.com','www.opel.com',null),
('Zara',15,'53 Arden Ave, New Castle, DE, 19720','8602491950','zara@gmail.com','www.zara.com',null),
('Puma',16,'44 Ivy Glen Ct, Smyrna, DE, 19977','(239) 597-3806','puma@yahoo.com','en.puma.com',null),
('Cadbury',17,'3368 Southern View Dr, Smyrna, DE, 19977','(302) 212-2380','cadbury@hotmail.com','www.cadbury.co.uk',null),
('Pringles',18,'19 Summer Dr, Smyrna, DE, 19977','(302) 221-3933','pringles@yahoo.com','www.pringles.com',null),
('Sony',19,'48 S Carter Rd, Smyrna, DE, 19977','(302) 223-6011','sony@yahoo.com','www.sony.com',null),
('Nintendo',20,'204 W Radison Run, Clayton, DE, 19938','(302) 223-6143','nintendo@yahoo.com','www.nintendo.com',null)

insert into Customer -- Fname | Minit | Lname | CID | Address | Phone # | Credit card | Email | M/F | Bdate | Username | Password | EID
values
('John','B','Smith',1,'731 Fondren, Houston, TX','01234567899',HASHBYTES('MD5','2357365536789543'),'johnbsmith@gmail.com',
'M','1965-09-11','Johnb',HASHBYTES('MD5','embra93842'),null), 
('Franklin','T','Wong',2,'638 Voss, Houston, TX','01263568643',null,'franklintwong@gmail.com',
'M','1955-12-08','Franklin',HASHBYTES('MD5','ilovemanga1999'),null),
('Joyce','A','English',3,'5631 Rice, Houston, T','01263673557',HASHBYTES('MD5','5556678945967845'),'joyceaenglish@gmail.com',
'F','1972-07-31','Joyce',HASHBYTES('MD5','rembestgirl1995'),null),
('Ramesh','K','Narayan',4,'975 Fire Oak, Humble, TX','01244445555',null,'rameshknarayan@gmail.com',
'M','1962-09-15','Ramesh',HASHBYTES('MD5','codegeass9999'),null),
('James','E','Borg',5,'450 Stone, Houston, TX','01222334455',HASHBYTES('MD5','9998273619584747'),'jameseborg@gmail.com',
'M','1937-11-10','James',HASHBYTES('MD5','bizarreowl999'),null),
('Jennifer','S','Wallace',6,'291 Berry, Bellaire, TX','01222222222',null,'jenniferswallace@gmail.com',
'F','1937-11-10','Jennifer',HASHBYTES('MD5','superbowl2002'),null),
('Ahmad','V','Jabbar',7,'980 Dallas, Houston, TX','01123777790',HASHBYTES('MD5','9999876578938411'),'ahmedvjabbar@gmail.com',
'M','1969-03-29','Ahmad',HASHBYTES('MD5','oldentimes1969'),null),
('Michael','J','Robinson',8,'291 Stone, Houston, TX','01188449375',HASHBYTES('MD5','8877652221198422'),'michaeljrobinson@gmail.com',
'M','1994-04-22','Michael',HASHBYTES('MD5','evangelion1994'),null),
('Jackson','D','Smith',9,'3581 Pooz Street, Lexington, TN','7319672827',null,'jacksondsmith@gmail.com',
'M','1985-09-07','Jackson',HASHBYTES('MD5','cowboybebop3918'),null),
('Rene','D','Durham',10,'3306 Marion Drive, Plant City, FL','8134692976',HASHBYTES('MD5','33355632456742346'),'reneddurham@gmail.com',
'M','1972-08-13','Rene',HASHBYTES('MD5','steinsgate1972'),null),
('Janelle','J','Byers',11,'4390 Post Farm Road, Wayland, OH','4042491959',null,'janellejbyers@hotmail.com',
'F','1982-05-26','Janelle',HASHBYTES('MD5','onepiece420'),null),
('Bob','J','Gulick',12,'779 Counts Lane, New Haven, CT','8602139960',null,'bobjgulick@yahoo.com',
'M','1985-06-27','Bob',HASHBYTES('MD5','tabletopdad529'),null),
('Sophia','J','Gosha',13,'995 Woodland Terrace, Fair Oaks, CA','9169447434',HASHBYTES('MD5','9987689237295826'),'sophiajgosha@hotmail.com',
'F','1994-11-11','Sophia',HASHBYTES('MD5','sophmc3948'),null),
('Michael','K','Jones',14,'3255 Bridge Street, Houston, TX','9188387012',null,'michaelkjones@gmail.com',
'M','1990-10-19','Michael454',HASHBYTES('MD5','daisydaisy22'),null),
('Ahmed','Y','Magdy',15,'810 Saint Clair Street, Senatobia, MS','6625607755',HASHBYTES('MD5','8776692343546232'),'ahmedymagdy@gmail.com',
'M','1970-01-23','Ahmed',HASHBYTES('MD5','foxgirl27'),null),
('Julie','R','Cooper',16,'1845 Dog Hill Lane, Delia, KS','7857715251',HASHBYTES('MD5','8882342425675345'),'juliercooper@yahoo.com',
'F','1977-02-25','Julie',HASHBYTES('MD5','flowergirl59'),null),
('Bob','S','Durham',17,'2572 Jerry Dove Drive, Beaufort, SC','8434415247',HASHBYTES('MD5','1235822324812381'),'bobsdurham@gmail.com',
'M','1984-06-06','Bobbyyyy',HASHBYTES('MD5','shokugekifan348'),null),
('Sarah','N','Robinson',18,'1356 Big Indian, Metairie, LA','5046483523',null,'sarahnrobinson@gmail.com',
'F','1988-08-09','Sarah',HASHBYTES('MD5','deathparade534'),null),
('Jennifer','S','Rose',19,'235 Chestnut Street, Sacramento, KY','8434483523',HASHBYTES('MD5','1234567123456789'),'jennifersrose@gmail.com',
'F','1992-06-15','JenniferRose',HASHBYTES('MD5','michaelJgirl53'),null),
('Robin','D','Hood',20,'274 Shad Hole Road, Dennis Port, MA','9046968559',null,'robindhood@gmail.com',
'M','1995-08-06','Robin_Hood',HASHBYTES('MD5','sauyernet66'),null)

insert into Product -- ProdID | ProdName | Size | Color | Price | Discount | Weight | MID | CatID | OrdID
values
(1,'Keyboard',20,'Red',50,20,500,null,null,null), 
(2,'Mouse',13,'Black',30,0,200,null,null,null),
(3,'Blouse',46,'Beige',200,0,50,null,null,null),
(4,'Hand Cream',22,'Blue',24.5,12,13,null,null,null),
(5,'iPhone Cover',10,'Yellow',29.99,0,15,null,null,null),
(6,'Jeans',50,'Blue',120,10,50,null,null,null),
(7,'Lipstick',5,'Red',23,0,3,null,null,null),
(8,'Laptop',100,'Black',15000,30,3000,null,null,null),
(9,'Headphones',3,'White',200,0,300,null,null,null),
(10,'Table',150,'Green',500,0,5000,null,null,null),
(11,'Carpet',2500,'Beige',500,10,6000,null,null,null),
(12,'Chair',1666,'Pink',150,0,1000,null,null,null),
(13,'Doll',23,'Blue',3000,5,300,null,null,null),
(14,'Toy Car',30,'Red',68,0,200,null,null,null),
(15,'iPhone',13,'White',12000,20,400,null,null,null),
(16,'Football',30,'White',50,0,200,null,null,null),
(17,'Earrings',2,'Red',150,0,20,null,null,null),
(18,'Harry Potter Books',20,'Black',100,0,500,null,null,null),
(19,'Bracelet',7,'Pink',60,0,100,null,null,null),
(20,'Desk',66,'Brown',2000,0,3000,null,null,null)

insert into Category -- CatID | CatName | Description
values
(1,'Beauty',null),
(2,'Cameras',null),
(3,'Clothing',null),
(4,'Bags & Wallets',null),
(5,'Footwear',null),
(6,'Watches & Accessories',null),
(7,'Electronics',null),
(8,'Game Consoles',null),
(9,'Vehicle Parts & Accessories',null),
(10,'Jewelry & Accessories',null),
(11,'Mobile Phones & Tablets',null),
(12,'Toys',null),
(13,'Tools & Home Improvements',null),
(14,'Books',null),
(15,'Garden & Outdoor',null),
(16,'Eyewear & Optics',null),
(17,'Furniture',null),
(18,'Home Appliances',null),
(19,'Grocery, Food & Beverages',null),
(20,'Sports & Fitness',null)

insert into Review -- RevNum | RevDate | RevRate | CID
values
(1,'2020-11-11',5,null),
(2,'2020-12-12',7,null),
(3,'2020-08-06',9,null),
(4,'2020-04-06',3,null),
(5,'2020-06-22',5,null),
(6,'2020-09-25',8,null),
(7,'2020-11-17',10,null),
(8,'2020-12-16',10,null),
(9,'2021-01-01',10,null),
(10,'2020-01-11',8,null),
(11,'2020-05-17',7,null),
(12,'2020-09-16',5,null),
(13,'2020-09-21',5,null),
(14,'2020-12-19',8,null),
(15,'2020-12-23',9,null),
(16,'2020-12-27',2,null),
(17,'2020-12-30',1,null),
(18,'2020-11-19',7,null),
(19,'2020-11-01',9,null),
(20,'2021-01-03',8,null)

insert into Orders -- OrderID | OrderDate | CID
values
(1,'2020-01-01','Cash',null), 
(2,'2020-01-03','Cash',null), 
(3,'2021-01-01','Cash',null), 
(4,'2020-03-05','Cash',null), 
(5,'2020-05-02','Cash',null), 
(6,'2020-12-12','Cash',null), 
(7,'2020-05-05','Cash',null), 
(8,'2020-06-06','Cash',null), 
(9,'2020-12-04','Cash',null), 
(10,'2020-09-11','Cash',null), 
(11,'2020-03-22','Credit',null), 
(12,'2020-02-19','Credit',null), 
(13,'2020-07-05','Credit',null), 
(14,'2020-11-14','Credit',null), 
(15,'2020-11-17','Credit',null), 
(16,'2020-11-19','Credit',null),  
(17,'2020-11-23','Credit',null), 
(18,'2020-12-13','Credit',null),  
(19,'2020-12-16','Credit',null), 
(20,'2020-12-19','Credit',null)

insert into ShippedItem -- ShipID | ShipPrice | DeliveryDate | ShipDate
values
(1,5,'2020-01-06','2020-01-03'),
(2,4,'2020-01-08','2020-01-05'),
(3,3,'2021-01-06','2021-01-03'),
(4,5,'2020-03-10','2020-03-07'),
(5,4.5,'2020-05-07','2020-05-04'),
(6,3.5,'2020-12-17','2020-12-14'),
(7,5.5,'2020-05-10','2020-05-07'),
(8,5.5,'2020-06-11','2020-06-08'),
(9,6,'2020-12-09','2020-12-06'),
(10,7,'2020-09-16','2020-09-13'),
(11,7.5,'2020-03-27','2020-03-24'),
(12,4.5,'2020-02-24','2020-02-21'),
(13,3,'2020-07-10','2020-07-07'),
(14,3.5,'2020-11-19','2020-11-16'),
(15,6,'2020-11-22','2020-11-19'),
(16,3,'2020-11-24','2020-11-21'),
(17,6,'2020-11-28','2020-11-25'),
(18,3.5,'2020-12-18','2020-12-15'),
(19,7.5,'2020-12-21','2020-12-18'),
(20,8,'2020-12-24','2020-12-21')

insert into Admins -- Username | Password | AID
values
('ErwinSmith',HASHBYTES('MD5','sasageyo'),104)

update Manager set CatID = 1 where MID = 1
update Manager set CatID = 2 where MID = 2
update Manager set CatID = 3 where MID = 3
update Manager set CatID = 4 where MID = 4
update Manager set CatID = 5 where MID = 5
update Manager set CatID = 6 where MID = 6
update Manager set CatID = 7 where MID = 7
update Manager set CatID = 8 where MID = 8
update Manager set CatID = 9 where MID = 9
update Manager set CatID = 10 where MID = 10
update Manager set CatID = 11 where MID = 11
update Manager set CatID = 12 where MID = 12
update Manager set CatID = 13 where MID = 13
update Manager set CatID = 14 where MID = 14
update Manager set CatID = 15 where MID = 15
update Manager set CatID = 16 where MID = 16
update Manager set CatID = 17 where MID = 17
update Manager set CatID = 18 where MID = 18
update Manager set CatID = 19 where MID = 19
update Manager set CatID = 20 where MID = 20

update Employee set MID = 1 where EID = 1
update Employee set MID = 2 where EID = 2
update Employee set MID = 3 where EID = 3
update Employee set MID = 4 where EID = 4
update Employee set MID = 5 where EID = 5
update Employee set MID = 6 where EID = 6
update Employee set MID = 7 where EID = 7
update Employee set MID = 8 where EID = 8
update Employee set MID = 9 where EID = 9
update Employee set MID = 10 where EID = 10
update Employee set MID = 11 where EID = 11
update Employee set MID = 12 where EID = 12
update Employee set MID = 13 where EID = 13
update Employee set MID = 14 where EID = 14
update Employee set MID = 15 where EID = 15
update Employee set MID = 16 where EID = 16
update Employee set MID = 17 where EID = 17
update Employee set MID = 18 where EID = 18
update Employee set MID = 19 where EID = 19
update Employee set MID = 20 where EID = 20

update Supplier set MID = 1 where SID = 1
update Supplier set MID = 2 where SID = 2
update Supplier set MID = 3 where SID = 3
update Supplier set MID = 4 where SID = 4
update Supplier set MID = 5 where SID = 5
update Supplier set MID = 6 where SID = 6
update Supplier set MID = 7 where SID = 7
update Supplier set MID = 8 where SID = 8
update Supplier set MID = 9 where SID = 9
update Supplier set MID = 10 where SID = 10
update Supplier set MID = 11 where SID = 11
update Supplier set MID = 12 where SID = 12
update Supplier set MID = 13 where SID = 13
update Supplier set MID = 14 where SID = 14
update Supplier set MID = 15 where SID = 15
update Supplier set MID = 16 where SID = 16
update Supplier set MID = 17 where SID = 17
update Supplier set MID = 18 where SID = 18
update Supplier set MID = 19 where SID = 19
update Supplier set MID = 20 where SID = 20

update Customer set EID = 1 where CID = 1
update Customer set EID = 2 where CID = 2
update Customer set EID = 3 where CID = 3
update Customer set EID = 4 where CID = 4
update Customer set EID = 5 where CID = 5
update Customer set EID = 6 where CID = 6
update Customer set EID = 7 where CID = 7
update Customer set EID = 8 where CID = 8
update Customer set EID = 9 where CID = 9
update Customer set EID = 10 where CID = 10
update Customer set EID = 11 where CID = 11
update Customer set EID = 12 where CID = 12
update Customer set EID = 13 where CID = 13
update Customer set EID = 14 where CID = 14
update Customer set EID = 15 where CID = 15
update Customer set EID = 16 where CID = 16
update Customer set EID = 17 where CID = 17
update Customer set EID = 18 where CID = 18
update Customer set EID = 19 where CID = 19
update Customer set EID = 20 where CID = 20

update Product set MID = 7, CatID = 7, OrdID = 1 where ProdID = 1
update Product set MID = 7, CatID = 7, OrdID = 2 where ProdID = 2
update Product set MID = 3, CatID = 3, OrdID = 3 where ProdID = 3
update Product set MID = 1, CatID = 1, OrdID = 4 where ProdID = 4
update Product set MID = 11, CatID = 11, OrdID = 5 where ProdID = 5
update Product set MID = 3, CatID = 3, OrdID = 6 where ProdID = 6
update Product set MID = 1, CatID = 1, OrdID = 7 where ProdID = 7
update Product set MID = 7, CatID = 7, OrdID = 8 where ProdID = 8
update Product set MID = 7, CatID = 7, OrdID = 9 where ProdID = 9
update Product set MID = 17, CatID = 17, OrdID = 10 where ProdID = 10
update Product set MID = 17, CatID = 17, OrdID = 11 where ProdID = 11
update Product set MID = 17, CatID = 17, OrdID = 12 where ProdID = 12
update Product set MID = 12, CatID = 12, OrdID = 13 where ProdID = 13
update Product set MID = 12, CatID = 12, OrdID = 14 where ProdID = 14
update Product set MID = 7, CatID = 7, OrdID = 15 where ProdID = 15
update Product set MID = 20, CatID = 20, OrdID = 16 where ProdID = 16
update Product set MID = 6, CatID = 6, OrdID = 17 where ProdID = 17
update Product set MID = 14, CatID = 14, OrdID = 18 where ProdID = 18
update Product set MID = 6, CatID = 6, OrdID = 19 where ProdID = 19
update Product set MID = 17, CatID = 17, OrdID = 20 where ProdID = 20

update Review set CID = 1 where RevNum = 1
update Review set CID = 2 where RevNum = 2
update Review set CID = 3 where RevNum = 3
update Review set CID = 4 where RevNum = 4
update Review set CID = 5 where RevNum = 5
update Review set CID = 6 where RevNum = 6
update Review set CID = 7 where RevNum = 7
update Review set CID = 8 where RevNum = 8
update Review set CID = 9 where RevNum = 9
update Review set CID = 10 where RevNum = 10
update Review set CID = 11 where RevNum = 11
update Review set CID = 12 where RevNum = 12
update Review set CID = 13 where RevNum = 13
update Review set CID = 14 where RevNum = 14
update Review set CID = 15 where RevNum = 15
update Review set CID = 16 where RevNum = 16
update Review set CID = 17 where RevNum = 17
update Review set CID = 18 where RevNum = 18
update Review set CID = 19 where RevNum = 19
update Review set CID = 20 where RevNum = 20

update Orders set CID = 1 where OrdID = 1
update Orders set CID = 2 where OrdID = 2
update Orders set CID = 3 where OrdID = 3
update Orders set CID = 4 where OrdID = 4
update Orders set CID = 5 where OrdID = 5
update Orders set CID = 6 where OrdID = 6
update Orders set CID = 7 where OrdID = 7
update Orders set CID = 8 where OrdID = 8
update Orders set CID = 9 where OrdID = 9
update Orders set CID = 10 where OrdID = 10
update Orders set CID = 11 where OrdID = 11
update Orders set CID = 12 where OrdID = 12
update Orders set CID = 13 where OrdID = 13
update Orders set CID = 14 where OrdID = 14
update Orders set CID = 15 where OrdID = 15
update Orders set CID = 16 where OrdID = 16
update Orders set CID = 17 where OrdID = 17
update Orders set CID = 18 where OrdID = 18
update Orders set CID = 19 where OrdID = 19
update Orders set CID = 20 where OrdID = 20


use Online_Shop1
GO

ALTER TABLE Product
ADD CONSTRAINT FK_Delete_Constraint
FOREIGN KEY(OrdID)
REFERENCES Orders(OrdID)
ON DELETE SET NULL


ALTER TABLE Customer
ADD CONSTRAINT FK_Employee_Delete_Constraint
FOREIGN KEY(EID)
REFERENCES Employee(EID)
ON DELETE SET NULL


--ALTER TABLE Payment
--ADD CONSTRAINT FK_Customer_Payment_Delete_Constraint
--FOREIGN KEY(CID)
--REFERENCES Customer(CID)
--ON DELETE CASCADE


ALTER TABLE Orders
ADD CONSTRAINT FK_Customer_Orders_Delete_Constraint
FOREIGN KEY(CID)
REFERENCES Customer(CID)
ON DELETE CASCADE

ALTER TABLE Review
ADD CONSTRAINT FK_Customer_Review_Delete_Constraint
FOREIGN KEY(CID)
REFERENCES Customer(CID)
ON DELETE CASCADE

ALTER TABLE Employee
ADD CONSTRAINT FK_Employee_Manager_Delete_Constraint
FOREIGN KEY(MID)
REFERENCES Manager(MID)
ON DELETE SET NULL

ALTER TABLE Supplier
ADD CONSTRAINT FK_Supplier_Manager_Delete_Constraint
FOREIGN KEY(MID)
REFERENCES Manager(MID)
ON DELETE SET NULL

ALTER TABLE Product
ADD CONSTRAINT FK_Product_Manager_Delete_Constraint
FOREIGN KEY(MID)
REFERENCES Manager(MID)
ON DELETE SET NULL