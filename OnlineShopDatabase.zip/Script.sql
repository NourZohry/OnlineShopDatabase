USE [master]
GO
/****** Object:  Database [Online_Shop1]    Script Date: 1/10/2021 9:20:58 AM ******/
CREATE DATABASE [Online_Shop1]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Online_Shop1', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\Online_Shop1.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'Online_Shop1_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\Online_Shop1_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [Online_Shop1] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [Online_Shop1].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [Online_Shop1] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [Online_Shop1] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [Online_Shop1] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [Online_Shop1] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [Online_Shop1] SET ARITHABORT OFF 
GO
ALTER DATABASE [Online_Shop1] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [Online_Shop1] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [Online_Shop1] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [Online_Shop1] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [Online_Shop1] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [Online_Shop1] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [Online_Shop1] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [Online_Shop1] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [Online_Shop1] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [Online_Shop1] SET  ENABLE_BROKER 
GO
ALTER DATABASE [Online_Shop1] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [Online_Shop1] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [Online_Shop1] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [Online_Shop1] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [Online_Shop1] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [Online_Shop1] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [Online_Shop1] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [Online_Shop1] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [Online_Shop1] SET  MULTI_USER 
GO
ALTER DATABASE [Online_Shop1] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [Online_Shop1] SET DB_CHAINING OFF 
GO
ALTER DATABASE [Online_Shop1] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [Online_Shop1] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [Online_Shop1] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [Online_Shop1] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [Online_Shop1] SET QUERY_STORE = OFF
GO
USE [Online_Shop1]
GO
/****** Object:  Table [dbo].[AddRemove]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AddRemove](
	[EID] [int] NOT NULL,
	[ProdID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EID] ASC,
	[ProdID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Admins]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Admins](
	[Username] [varchar](50) NULL,
	[Password] [varchar](50) NULL,
	[AID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[AID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Category]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Category](
	[CatID] [int] NOT NULL,
	[CatName] [varchar](100) NOT NULL,
	[Description] [varchar](500) NULL,
PRIMARY KEY CLUSTERED 
(
	[CatID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Customer]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Customer](
	[Fname] [varchar](50) NOT NULL,
	[Minit] [char](1) NOT NULL,
	[Lname] [varchar](50) NOT NULL,
	[CID] [int] NOT NULL,
	[Address] [varchar](200) NULL,
	[Phone] [varchar](50) NULL,
	[CreditNum] [varchar](100) NULL,
	[Email] [varchar](200) NULL,
	[Sex] [char](1) NULL,
	[Bdate] [date] NULL,
	[Username] [varchar](50) NULL,
	[Password] [varchar](100) NULL,
	[EID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[CID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Deliver]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Deliver](
	[EID] [int] NOT NULL,
	[CID] [int] NOT NULL,
	[ShipID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[EID] ASC,
	[CID] ASC,
	[ShipID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employee](
	[Fname] [varchar](50) NOT NULL,
	[Minit] [char](1) NOT NULL,
	[Lname] [varchar](50) NOT NULL,
	[EID] [int] NOT NULL,
	[Salary] [int] NULL,
	[Sex] [char](1) NULL,
	[Bdate] [date] NULL,
	[Username] [varchar](50) NULL,
	[Password] [varchar](100) NULL,
	[MID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[EID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Manager]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Manager](
	[Fname] [varchar](50) NOT NULL,
	[Minit] [char](1) NOT NULL,
	[Lname] [varchar](50) NOT NULL,
	[MID] [int] NOT NULL,
	[Salary] [int] NULL,
	[Sex] [char](1) NULL,
	[Bdate] [date] NULL,
	[Username] [varchar](50) NULL,
	[Password] [varchar](100) NULL,
	[CatID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[MID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Orders]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Orders](
	[OrdID] [int] NOT NULL,
	[OrderDate] [date] NULL,
	[PaymentMethod] [varchar](50) NULL,
	[CID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[OrdID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Product]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Product](
	[ProdID] [int] NOT NULL,
	[ProdName] [varchar](200) NULL,
	[Size] [float] NULL,
	[Color] [varchar](50) NULL,
	[Price] [float] NOT NULL,
	[Discount] [int] NULL,
	[Weight] [float] NULL,
	[MID] [int] NULL,
	[CatID] [int] NULL,
	[OrdID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProdID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Review]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Review](
	[RevNum] [int] NOT NULL,
	[RevDate] [date] NOT NULL,
	[RevRate] [int] NOT NULL,
	[CID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[RevNum] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Search_For]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Search_For](
	[CID] [int] NOT NULL,
	[ProdID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[CID] ASC,
	[ProdID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ShippedItem]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ShippedItem](
	[ShipID] [int] NOT NULL,
	[ShipPrice] [float] NOT NULL,
	[DeliveryDate] [date] NULL,
	[ShipDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[ShipID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Supplier]    Script Date: 1/10/2021 9:20:58 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Supplier](
	[Name] [varchar](50) NOT NULL,
	[SID] [int] NOT NULL,
	[Address] [varchar](200) NULL,
	[Phone] [varchar](50) NULL,
	[Email] [varchar](200) NULL,
	[URL] [varchar](200) NULL,
	[MID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[SID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[Admins] ([Username], [Password], [AID]) VALUES (N'ErwinSmith', N'Ìˆ×¦"w#ÙBmE A', 104)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (1, N'Beauty', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (2, N'Cameras', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (3, N'Clothing', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (4, N'Bags & Wallets', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (5, N'Footwear', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (6, N'Watches & Accessories', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (7, N'Electronics', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (8, N'Game Consoles', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (9, N'Vehicle Parts & Accessories', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (10, N'Jewelry & Accessories', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (11, N'Mobile Phones & Tablets', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (12, N'Toys', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (13, N'Tools & Home Improvements', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (14, N'Books', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (15, N'Garden & Outdoor', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (16, N'Eyewear & Optics', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (17, N'Furniture', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (18, N'Home Appliances', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (19, N'Grocery, Food & Beverages', NULL)
GO
INSERT [dbo].[Category] ([CatID], [CatName], [Description]) VALUES (20, N'Sports & Fitness', NULL)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'John', N'B', N'Smith', 1, N'731 Fondren, Houston, TX', N'01234567899', N'¿ß°røµLƒ¹9Ï
', N'johnbsmith@gmail.com', N'M', CAST(N'1965-09-11' AS Date), N'Johnb', N'vÜÖžånW-†šïFØŸù', 1)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Franklin', N'T', N'Wong', 2, N'638 Voss, Houston, TX', N'01263568643', NULL, N'franklintwong@gmail.com', N'M', CAST(N'1955-12-08' AS Date), N'Franklin', N'
ENÝ†¶¿ç`XGBq', 2)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Joyce', N'A', N'English', 3, N'5631 Rice, Houston, T', N'01263673557', N'D"Ô’šÿþþ$U=nB)Ñ', N'joyceaenglish@gmail.com', N'F', CAST(N'1972-07-31' AS Date), N'Joyce', N'ç©4µñ“Ž
íQ
Çä', 3)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Ramesh', N'K', N'Narayan', 4, N'975 Fire Oak, Humble, TX', N'01244445555', NULL, N'rameshknarayan@gmail.com', N'M', CAST(N'1962-09-15' AS Date), N'Ramesh', N'%­²	.íâû‚Y+eÞ¬wL', 4)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'James', N'E', N'Borg', 5, N'450 Stone, Houston, TX', N'01222334455', N'U¹ä­"øKOãmë–ÿS„', N'jameseborg@gmail.com', N'M', CAST(N'1937-11-10' AS Date), N'James', N'ïVB"½ßL—t+¶Æ', 5)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Jennifer', N'S', N'Wallace', 6, N'291 Berry, Bellaire, TX', N'01222222222', NULL, N'jenniferswallace@gmail.com', N'F', CAST(N'1937-11-10' AS Date), N'Jennifer', N'tškË(JŠ!³Ka)R€d)', 6)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Ahmad', N'V', N'Jabbar', 7, N'980 Dallas, Houston, TX', N'01123777790', N'ðFŠ•Õ`¦âsƒ+L¥÷', N'ahmedvjabbar@gmail.com', N'M', CAST(N'1969-03-29' AS Date), N'Ahmad', N'é@ÏgÞ³M–è(	½·', 7)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Michael', N'J', N'Robinson', 8, N'291 Stone, Houston, TX', N'01188449375', N'p».ÝŠXøñ*æ|©×ö
', N'michaeljrobinson@gmail.com', N'M', CAST(N'1994-04-22' AS Date), N'Michael', N'«Òœ¿•º?
ÿa|Ž^¾r', 8)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Jackson', N'D', N'Smith', 9, N'3581 Pooz Street, Lexington, TN', N'7319672827', NULL, N'jacksondsmith@gmail.com', N'M', CAST(N'1985-09-07' AS Date), N'Jackson', N'âËO®TCÚq†ÌIŒm', 9)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Rene', N'D', N'Durham', 10, N'3306 Marion Drive, Plant City, FL', N'8134692976', N'˜…Ì÷v
¯¤M«S˜NÚ€h', N'reneddurham@gmail.com', N'M', CAST(N'1972-08-13' AS Date), N'Rene', N'Á	<ÉÄíh‚y8àþŽÃ', 10)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Janelle', N'J', N'Byers', 11, N'4390 Post Farm Road, Wayland, OH', N'4042491959', NULL, N'janellejbyers@hotmail.com', N'F', CAST(N'1982-05-26' AS Date), N'Janelle', N'óˆ^šÊTÂý‰pIÛ', 11)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Bob', N'J', N'Gulick', 12, N'779 Counts Lane, New Haven, CT', N'8602139960', NULL, N'bobjgulick@yahoo.com', N'M', CAST(N'1985-06-27' AS Date), N'Bob', N'$–äPÈ^[žÒ»=*üzû', 12)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Sophia', N'J', N'Gosha', 13, N'995 Woodland Terrace, Fair Oaks, CA', N'9169447434', N'ÅP°™*ÕSlw¥‹W$Á', N'sophiajgosha@hotmail.com', N'F', CAST(N'1994-11-11' AS Date), N'Sophia', N'(5^œEjÓXÛ×“ûç|', 13)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Michael', N'K', N'Jones', 14, N'3255 Bridge Street, Houston, TX', N'9188387012', NULL, N'michaelkjones@gmail.com', N'M', CAST(N'1990-10-19' AS Date), N'Michael454', N'@ùõ¾¢­¡ž5Ùÿ…8', 14)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Ahmed', N'Y', N'Magdy', 15, N'810 Saint Clair Street, Senatobia, MS', N'6625607755', N'j{$RYn~?£½È?', N'ahmedymagdy@gmail.com', N'M', CAST(N'1970-01-23' AS Date), N'Ahmed', N'ôBË×}y¹mZiùëÛ', 15)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Julie', N'R', N'Cooper', 16, N'1845 Dog Hill Lane, Delia, KS', N'7857715251', N'ùMÔràŠhUc£É¬ÀÞ', N'juliercooper@yahoo.com', N'F', CAST(N'1977-02-25' AS Date), N'Julie', N'HÖxm”£Ûª>g÷Oðgå', 16)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Bob', N'S', N'Durham', 17, N'2572 Jerry Dove Drive, Beaufort, SC', N'8434415247', N'ßn1Œ*¹pRYG¿+À', N'bobsdurham@gmail.com', N'M', CAST(N'1984-06-06' AS Date), N'Bobbyyyy', N'í†4P7j$¿*V‡„Æ', 17)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Sarah', N'N', N'Robinson', 18, N'1356 Big Indian, Metairie, LA', N'5046483523', NULL, N'sarahnrobinson@gmail.com', N'F', CAST(N'1988-08-09' AS Date), N'Sarah', N'“Ü_AîïóÓÞaP', 18)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Jennifer', N'S', N'Rose', 19, N'235 Chestnut Street, Sacramento, KY', N'8434483523', N'Kv™|ð$5£§ý
w¤ R', N'jennifersrose@gmail.com', N'F', CAST(N'1992-06-15' AS Date), N'JenniferRose', N'·-§ù%¥aÃ ‡“¥H¾', 19)
GO
INSERT [dbo].[Customer] ([Fname], [Minit], [Lname], [CID], [Address], [Phone], [CreditNum], [Email], [Sex], [Bdate], [Username], [Password], [EID]) VALUES (N'Robin', N'D', N'Hood', 20, N'274 Shad Hole Road, Dennis Port, MA', N'9046968559', NULL, N'robindhood@gmail.com', N'M', CAST(N'1995-08-06' AS Date), N'Robin_Hood', N'|«U^àXìÕ¨0¾¨µª', 20)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Andrew', N'B', N'Balcom', 1, 20000, N'M', CAST(N'1980-09-09' AS Date), N'AndrewB', N'E(‡ö¾:''Ñ8´z|', 1)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Benjamin', N'D', N'Lopez', 2, 25000, N'M', CAST(N'1970-02-23' AS Date), N'BenjaminD', N'¶º6Ô±‘,&±zwQ¥', 2)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Christopher', N'S', N'Hansen', 3, 23000, N'M', CAST(N'1976-01-22' AS Date), N'ChristopherS', N'ûôzé¾8—`—mÙéõñ', 3)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Donald', N'S', N'Washington', 4, 26000, N'M', CAST(N'1977-05-06' AS Date), N'DonaldS', N'Š¡ð’5;%äSð5á£†', 4)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Elizabeth', N'D', N'Grant', 5, 28000, N'F', CAST(N'1975-06-01' AS Date), N'ElizabethD', N'òg´áÃøõ†SýMê&’Õ', 5)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Franklin', N'T', N'Rivera', 6, 22000, N'M', CAST(N'1990-04-04' AS Date), N'FranklinT', N'ŽÅÃ9¢TñØÖjÓó3', 6)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'George', N'N', N'Perkins', 7, 22500, N'M', CAST(N'1983-09-15' AS Date), N'GeorgeN', N'£5ìÖf“c×Ð‹ëñHuZ', 7)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Hans', N'C', N'Andersen', 8, 19000, N'M', CAST(N'1993-02-04' AS Date), N'HansC', N'Ö¤ïÀ/jmna“¹„¨d', 8)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Marcus', N'W', N'Meyer', 9, 30000, N'M', CAST(N'1985-07-27' AS Date), N'MarcusW', N'òFÜä*¶Q¿uÉÈ¡—{', 9)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Johnson', N'D', N'Gonzalez', 10, 25000, N'M', CAST(N'1983-03-04' AS Date), N'JohnsonD', N'Í…Ò~ÌPÜ''‹_‹Î ', 10)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Sarah', N'J', N'Wilde', 11, 19000, N'F', CAST(N'1997-11-15' AS Date), N'SarahJ', N'Ac,Ü—…Îœ—

HÔ', 11)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Cameron', N'C', N'Chambers', 12, 24000, N'M', CAST(N'1993-07-18' AS Date), N'CameronC', N'â8#àžæúDÆúKbZ—', 12)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Fiona', N'M', N'Pax', 13, 27000, N'F', CAST(N'1992-05-19' AS Date), N'FionaM', N'f`m¨eq¸m<', 13)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Tracey', N'F', N'Ceravee', 14, 24000, N'F', CAST(N'1992-07-22' AS Date), N'TraceyF', N'%‡W|Øhâ…Ùùó!3', 14)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Jimmy', N'N', N'Martinez', 15, 23000, N'M', CAST(N'1989-04-25' AS Date), N'JimmyN', N'·°Ly¤2Z]2sS§', 15)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Steve', N'B', N'Miller', 16, 22000, N'M', CAST(N'1983-03-05' AS Date), N'SteveB', N'W¸PhyÕg¦ÕOÅÿkr', 16)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Michael', N'T', N'Garcia', 17, 26000, N'M', CAST(N'1982-01-01' AS Date), N'MichaelT', N'Žm9§®…ø$ýfè¡Wê‘', 17)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Alfredo', N'S', N'Diaz', 18, 30000, N'M', CAST(N'1990-05-03' AS Date), N'AlfredoS', N'MxËœ³*ó+´üûmäº', 18)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Gavin', N'H', N'Free', 19, 25000, N'M', CAST(N'1993-06-06' AS Date), N'GavinH', N'å
p€9qªrˆJê–œ¾º', 19)
GO
INSERT [dbo].[Employee] ([Fname], [Minit], [Lname], [EID], [Salary], [Sex], [Bdate], [Username], [Password], [MID]) VALUES (N'Scott', N'N', N'Free', 20, 25000, N'M', CAST(N'1993-06-06' AS Date), N'ScottN', N'ït‹­ˆ×Õ{q°A®z[Ãè', 20)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Rory', N'A', N'Stewart', 1, 35000, N'M', CAST(N'1982-08-08' AS Date), N'RoryA', N'%ÕZÒƒª@
ôdÇmq<­', 1)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'George', N'F', N'Harper', 2, 34000, N'M', CAST(N'1969-01-22' AS Date), N'GeorgeF', N'ðþn—
Q=?D§,.q', 2)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Bradley', N'G', N'Brooks', 3, 33000, N'M', CAST(N'1975-02-23' AS Date), N'BradleyG', N'qXetÊº¯|É2ùÝ', 3)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Ewan', N'A', N'Campbell', 4, 32000, N'M', CAST(N'1977-06-05' AS Date), N'EwanA', N'wê†’§ªÖ+†¡n¨\jRö', 4)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Harley', N'E', N'Snyder', 5, 38000, N'F', CAST(N'1977-08-03' AS Date), N'HarleyE', N'B&Ÿ$g’\‚2c,', 5)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Barden', N'T', N'Brewer', 6, 32000, N'M', CAST(N'1996-05-03' AS Date), N'BardenT', N'dÚjœMå÷0!•7Q+', 6)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Kale', N'E', N'Allen', 7, 32500, N'M', CAST(N'1982-03-11' AS Date), N'KaleE', N'Â=\DRÀßÂÚ‡@ù”', 7)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Quinn', N'W', N'Cox', 8, 29000, N'M', CAST(N'1991-04-02' AS Date), N'QuinnW', N'ƒÓŒ#à	®RžYUÏ', 8)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Holden', N'S', N'Jones', 9, 40000, N'M', CAST(N'1981-03-25' AS Date), N'HoldenS', N'à:›ç‰Xù^æ[aÛ', 9)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Jaeden', N'K', N'Henderson', 10, 35000, N'M', CAST(N'1982-04-04' AS Date), N'JaedenK', N'æÑätúñô%Ápçj;', 10)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Arin', N'U', N'Rivas', 11, 29000, N'F', CAST(N'1984-10-16' AS Date), N'ArinU', N' QyÂªåž§2ˆýêè)Ë', 11)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Aaron', N'N', N'Carney', 12, 34000, N'M', CAST(N'1982-02-14' AS Date), N'AaronN', N'p›ðŒ‚›´ö˜‹vÂj', 12)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Christopher', N'H', N'Sawyer', 13, 37000, N'F', CAST(N'1991-03-13' AS Date), N'ChristopherH', N'7ÿ)îbëú©”§W±ËVí', 13)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Oscar', N'Y', N'Woods', 14, 34000, N'F', CAST(N'1982-04-26' AS Date), N'OscarY', N'ÌñåÇã@ES¢Î;Ãè¬', 14)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Peter', N'H', N'Clarke', 15, 33000, N'M', CAST(N'1987-06-24' AS Date), N'PeterH', N'=ËÐ¥ëšQ–ÝûôûÏœ{Ë', 15)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Sebastian', N'I', N'Schneider', 16, 32000, N'M', CAST(N'1981-02-04' AS Date), N'SebastianI', N'$"}üFÃÀ¢8#SƒÞØ', 16)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Ciel', N'K', N'West', 17, 36000, N'M', CAST(N'1972-02-02' AS Date), N'CielK', N'¬1l·ÈØãÉS_ýÉ', 17)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Emilia', N'N', N'Ware', 18, 40000, N'M', CAST(N'1980-04-02' AS Date), N'EmiliaN', N'hÿá»ÿçWŸŽÛh4*', 18)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Jack', N'M', N'Forbes', 19, 35000, N'M', CAST(N'1991-04-03' AS Date), N'JackM', N'ú''IÌ¦x$¿/ÈËÈõá', 19)
GO
INSERT [dbo].[Manager] ([Fname], [Minit], [Lname], [MID], [Salary], [Sex], [Bdate], [Username], [Password], [CatID]) VALUES (N'Jeremy', N'V', N'Andrews', 20, 35000, N'M', CAST(N'1988-03-03' AS Date), N'JeremyV', N'oLùX²£ìAŒ¯æþ I¾,', 20)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (1, CAST(N'2020-01-01' AS Date), N'Cash', 1)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (2, CAST(N'2020-01-03' AS Date), N'Cash', 2)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (3, CAST(N'2021-01-01' AS Date), N'Cash', 3)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (4, CAST(N'2020-03-05' AS Date), N'Cash', 4)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (5, CAST(N'2020-05-02' AS Date), N'Cash', 5)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (6, CAST(N'2020-12-12' AS Date), N'Cash', 6)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (7, CAST(N'2020-05-05' AS Date), N'Cash', 7)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (8, CAST(N'2020-06-06' AS Date), N'Cash', 8)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (9, CAST(N'2020-12-04' AS Date), N'Cash', 9)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (10, CAST(N'2020-09-11' AS Date), N'Cash', 10)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (11, CAST(N'2020-03-22' AS Date), N'Credit', 11)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (12, CAST(N'2020-02-19' AS Date), N'Credit', 12)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (13, CAST(N'2020-07-05' AS Date), N'Credit', 13)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (14, CAST(N'2020-11-14' AS Date), N'Credit', 14)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (15, CAST(N'2020-11-17' AS Date), N'Credit', 15)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (16, CAST(N'2020-11-19' AS Date), N'Credit', 16)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (17, CAST(N'2020-11-23' AS Date), N'Credit', 17)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (18, CAST(N'2020-12-13' AS Date), N'Credit', 18)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (19, CAST(N'2020-12-16' AS Date), N'Credit', 19)
GO
INSERT [dbo].[Orders] ([OrdID], [OrderDate], [PaymentMethod], [CID]) VALUES (20, CAST(N'2020-12-19' AS Date), N'Credit', 20)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (1, N'Keyboard', 20, N'Red', 50, 20, 500, 7, 7, 1)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (2, N'Mouse', 13, N'Black', 30, 0, 200, 7, 7, 2)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (3, N'Blouse', 46, N'Beige', 200, 0, 50, 3, 3, 3)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (4, N'Hand Cream', 22, N'Blue', 24.5, 12, 13, 1, 1, 4)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (5, N'iPhone Cover', 10, N'Yellow', 29.99, 0, 15, 11, 11, 5)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (6, N'Jeans', 50, N'Blue', 120, 10, 50, 3, 3, 6)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (7, N'Lipstick', 5, N'Red', 23, 0, 3, 1, 1, 7)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (8, N'Laptop', 100, N'Black', 15000, 30, 3000, 7, 7, 8)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (9, N'Headphones', 3, N'White', 200, 0, 300, 7, 7, 9)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (10, N'Table', 150, N'Green', 500, 0, 5000, 17, 17, 10)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (11, N'Carpet', 2500, N'Beige', 500, 10, 6000, 17, 17, 11)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (12, N'Chair', 1666, N'Pink', 150, 0, 1000, 17, 17, 12)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (13, N'Doll', 23, N'Blue', 3000, 5, 300, 12, 12, 13)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (14, N'Toy Car', 30, N'Red', 68, 0, 200, 12, 12, 14)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (15, N'iPhone', 13, N'White', 12000, 20, 400, 7, 7, 15)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (16, N'Football', 30, N'White', 50, 0, 200, 20, 20, 16)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (17, N'Earrings', 2, N'Red', 150, 0, 20, 6, 6, 17)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (18, N'Harry Potter Books', 20, N'Black', 100, 0, 500, 14, 14, 18)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (19, N'Bracelet', 7, N'Pink', 60, 0, 100, 6, 6, 19)
GO
INSERT [dbo].[Product] ([ProdID], [ProdName], [Size], [Color], [Price], [Discount], [Weight], [MID], [CatID], [OrdID]) VALUES (20, N'Desk', 66, N'Brown', 2000, 0, 3000, 17, 17, 20)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (1, CAST(N'2020-11-11' AS Date), 5, 1)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (2, CAST(N'2020-12-12' AS Date), 7, 2)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (3, CAST(N'2020-08-06' AS Date), 9, 3)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (4, CAST(N'2020-04-06' AS Date), 3, 4)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (5, CAST(N'2020-06-22' AS Date), 5, 5)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (6, CAST(N'2020-09-25' AS Date), 8, 6)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (7, CAST(N'2020-11-17' AS Date), 10, 7)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (8, CAST(N'2020-12-16' AS Date), 10, 8)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (9, CAST(N'2021-01-01' AS Date), 10, 9)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (10, CAST(N'2020-01-11' AS Date), 8, 10)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (11, CAST(N'2020-05-17' AS Date), 7, 11)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (12, CAST(N'2020-09-16' AS Date), 5, 12)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (13, CAST(N'2020-09-21' AS Date), 5, 13)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (14, CAST(N'2020-12-19' AS Date), 8, 14)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (15, CAST(N'2020-12-23' AS Date), 9, 15)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (16, CAST(N'2020-12-27' AS Date), 2, 16)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (17, CAST(N'2020-12-30' AS Date), 1, 17)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (18, CAST(N'2020-11-19' AS Date), 7, 18)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (19, CAST(N'2020-11-01' AS Date), 9, 19)
GO
INSERT [dbo].[Review] ([RevNum], [RevDate], [RevRate], [CID]) VALUES (20, CAST(N'2021-01-03' AS Date), 8, 20)
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (1, 5, CAST(N'2020-01-06' AS Date), CAST(N'2020-01-03' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (2, 4, CAST(N'2020-01-08' AS Date), CAST(N'2020-01-05' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (3, 3, CAST(N'2021-01-06' AS Date), CAST(N'2021-01-03' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (4, 5, CAST(N'2020-03-10' AS Date), CAST(N'2020-03-07' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (5, 4.5, CAST(N'2020-05-07' AS Date), CAST(N'2020-05-04' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (6, 3.5, CAST(N'2020-12-17' AS Date), CAST(N'2020-12-14' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (7, 5.5, CAST(N'2020-05-10' AS Date), CAST(N'2020-05-07' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (8, 5.5, CAST(N'2020-06-11' AS Date), CAST(N'2020-06-08' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (9, 6, CAST(N'2020-12-09' AS Date), CAST(N'2020-12-06' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (10, 7, CAST(N'2020-09-16' AS Date), CAST(N'2020-09-13' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (11, 7.5, CAST(N'2020-03-27' AS Date), CAST(N'2020-03-24' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (12, 4.5, CAST(N'2020-02-24' AS Date), CAST(N'2020-02-21' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (13, 3, CAST(N'2020-07-10' AS Date), CAST(N'2020-07-07' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (14, 3.5, CAST(N'2020-11-19' AS Date), CAST(N'2020-11-16' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (15, 6, CAST(N'2020-11-22' AS Date), CAST(N'2020-11-19' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (16, 3, CAST(N'2020-11-24' AS Date), CAST(N'2020-11-21' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (17, 6, CAST(N'2020-11-28' AS Date), CAST(N'2020-11-25' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (18, 3.5, CAST(N'2020-12-18' AS Date), CAST(N'2020-12-15' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (19, 7.5, CAST(N'2020-12-21' AS Date), CAST(N'2020-12-18' AS Date))
GO
INSERT [dbo].[ShippedItem] ([ShipID], [ShipPrice], [DeliveryDate], [ShipDate]) VALUES (20, 8, CAST(N'2020-12-24' AS Date), CAST(N'2020-12-21' AS Date))
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Google', 1, N'1600 Amphitheatre Parkway, Mountain View, CA', N'(919) 468-1502', N'google@gmail.com', N'www.google.com', 1)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Microsoft', 2, N'2214 Grande Valley Cir, Cary, NC, 27513 ', N'(716) 773-7019', N'microsoft@hotmail.com', N'www.microsoft.com', 2)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Dell', 3, N'164 Marlin Dr, Grand Island, NY, 14072', N'(225) 435-0062', N'dell@yahoo.com', N'www.dell.com', 3)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Philips', 4, N'29791 E Highland St, Livingston, LA, 70754 ', N'(503) 925-8478', N'philips@yahoo.com', N'www.philips.com', 4)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Kellogg', 5, N'23337 SW Cinnamon Hill Pl, Sherwood, OR, 97140', N'(770) 507-3151', N'kelloggcompany@gmail.com', N'www.kelloggcompany.com', 5)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Nike', 6, N'4222 Entrance Orch, Rex, GA, 30273', NULL, N'nike@yahoo.com', N'www.nike.com', 6)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Adidas', 7, N'1015 Brick Mill Rd, Honea Path, SC, 29654', N'(406) 377-1767', N'adidas@hotmail.com', N'www.adidas.com', 7)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Ferrari', 8, N'301 Pine St, Glendive, MT, 59330', N'(405) 275-2226', N'ferrari@yahoo.com', N'www.ferrari.com', 8)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'LG', 9, N'1955 N Louisa Ave, Shawnee, OK, 74804', N'(608) 884-6247', N'LG@yahoo.com', N'www.lg.com', 9)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Lacoste', 10, N'316 Spencer Rd, Edgerton, WI, 53534', N'01002534346', N'lacoste@gamil.com', N'www.lacoste.com', 10)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Louis Vuitton', 11, N'2661 Pahmeyer Rd, New Braunfels, TX, 78130', N'(830) 625-3940', N'louisvuitton@yahoo.com', N'eu.louisvuitton.com', 11)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Crocs', 12, N'410 Upper Snuff Mill Row #146, Hockessin, DE, 19707', N'01008395839', N'crocs@gmail.com', N'www.crocs.com', 12)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Toys R Us', 13, N'1911 Harvey Straughn Rd, Townsend, DE, 19734', N'01004729406', N'toysrus@yahoo.com', N'www.toysrus.com', 13)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Opel', 14, N'7 Lauras Way, Rehoboth Beach, DE, 19971', N'(214) 256-4071', N'opel@yahoo.com', N'www.opel.com', 14)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Zara', 15, N'53 Arden Ave, New Castle, DE, 19720', N'8602491950', N'zara@gmail.com', N'www.zara.com', 15)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Puma', 16, N'44 Ivy Glen Ct, Smyrna, DE, 19977', N'(239) 597-3806', N'puma@yahoo.com', N'en.puma.com', 16)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Cadbury', 17, N'3368 Southern View Dr, Smyrna, DE, 19977', N'(302) 212-2380', N'cadbury@hotmail.com', N'www.cadbury.co.uk', 17)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Pringles', 18, N'19 Summer Dr, Smyrna, DE, 19977', N'(302) 221-3933', N'pringles@yahoo.com', N'www.pringles.com', 18)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Sony', 19, N'48 S Carter Rd, Smyrna, DE, 19977', N'(302) 223-6011', N'sony@yahoo.com', N'www.sony.com', 19)
GO
INSERT [dbo].[Supplier] ([Name], [SID], [Address], [Phone], [Email], [URL], [MID]) VALUES (N'Nintendo', 20, N'204 W Radison Run, Clayton, DE, 19938', N'(302) 223-6143', N'nintendo@yahoo.com', N'www.nintendo.com', 20)
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Customer__536C85E4DACCC10B]    Script Date: 1/10/2021 9:21:11 AM ******/
ALTER TABLE [dbo].[Customer] ADD UNIQUE NONCLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Employee__536C85E4934E3819]    Script Date: 1/10/2021 9:21:11 AM ******/
ALTER TABLE [dbo].[Employee] ADD UNIQUE NONCLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Manager__536C85E4DFA81ADD]    Script Date: 1/10/2021 9:21:11 AM ******/
ALTER TABLE [dbo].[Manager] ADD UNIQUE NONCLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AddRemove]  WITH CHECK ADD FOREIGN KEY([EID])
REFERENCES [dbo].[Employee] ([EID])
GO
ALTER TABLE [dbo].[AddRemove]  WITH CHECK ADD FOREIGN KEY([ProdID])
REFERENCES [dbo].[Product] ([ProdID])
GO
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD FOREIGN KEY([EID])
REFERENCES [dbo].[Employee] ([EID])
GO
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Employee_Delete_Constraint] FOREIGN KEY([EID])
REFERENCES [dbo].[Employee] ([EID])
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Employee_Delete_Constraint]
GO
ALTER TABLE [dbo].[Deliver]  WITH CHECK ADD FOREIGN KEY([CID])
REFERENCES [dbo].[Customer] ([CID])
GO
ALTER TABLE [dbo].[Deliver]  WITH CHECK ADD FOREIGN KEY([EID])
REFERENCES [dbo].[Employee] ([EID])
GO
ALTER TABLE [dbo].[Deliver]  WITH CHECK ADD FOREIGN KEY([ShipID])
REFERENCES [dbo].[ShippedItem] ([ShipID])
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD FOREIGN KEY([MID])
REFERENCES [dbo].[Manager] ([MID])
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_Manager_Delete_Constraint] FOREIGN KEY([MID])
REFERENCES [dbo].[Manager] ([MID])
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_Manager_Delete_Constraint]
GO
ALTER TABLE [dbo].[Manager]  WITH CHECK ADD FOREIGN KEY([CatID])
REFERENCES [dbo].[Category] ([CatID])
GO
ALTER TABLE [dbo].[Orders]  WITH CHECK ADD FOREIGN KEY([CID])
REFERENCES [dbo].[Customer] ([CID])
GO
ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Customer_Orders_Delete_Constraint] FOREIGN KEY([CID])
REFERENCES [dbo].[Customer] ([CID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Customer_Orders_Delete_Constraint]
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD FOREIGN KEY([CatID])
REFERENCES [dbo].[Category] ([CatID])
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD FOREIGN KEY([MID])
REFERENCES [dbo].[Manager] ([MID])
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD FOREIGN KEY([OrdID])
REFERENCES [dbo].[Orders] ([OrdID])
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD  CONSTRAINT [FK_Delete_Constraint] FOREIGN KEY([OrdID])
REFERENCES [dbo].[Orders] ([OrdID])
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[Product] CHECK CONSTRAINT [FK_Delete_Constraint]
GO
ALTER TABLE [dbo].[Product]  WITH CHECK ADD  CONSTRAINT [FK_Product_Manager_Delete_Constraint] FOREIGN KEY([MID])
REFERENCES [dbo].[Manager] ([MID])
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[Product] CHECK CONSTRAINT [FK_Product_Manager_Delete_Constraint]
GO
ALTER TABLE [dbo].[Review]  WITH CHECK ADD FOREIGN KEY([CID])
REFERENCES [dbo].[Customer] ([CID])
GO
ALTER TABLE [dbo].[Review]  WITH CHECK ADD  CONSTRAINT [FK_Customer_Review_Delete_Constraint] FOREIGN KEY([CID])
REFERENCES [dbo].[Customer] ([CID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Review] CHECK CONSTRAINT [FK_Customer_Review_Delete_Constraint]
GO
ALTER TABLE [dbo].[Search_For]  WITH CHECK ADD FOREIGN KEY([ProdID])
REFERENCES [dbo].[Product] ([ProdID])
GO
ALTER TABLE [dbo].[Search_For]  WITH CHECK ADD FOREIGN KEY([CID])
REFERENCES [dbo].[Customer] ([CID])
GO
ALTER TABLE [dbo].[Supplier]  WITH CHECK ADD FOREIGN KEY([MID])
REFERENCES [dbo].[Manager] ([MID])
GO
ALTER TABLE [dbo].[Supplier]  WITH CHECK ADD  CONSTRAINT [FK_Supplier_Manager_Delete_Constraint] FOREIGN KEY([MID])
REFERENCES [dbo].[Manager] ([MID])
ON DELETE SET NULL
GO
ALTER TABLE [dbo].[Supplier] CHECK CONSTRAINT [FK_Supplier_Manager_Delete_Constraint]
GO
/****** Object:  StoredProcedure [dbo].[AddProduct]    Script Date: 1/10/2021 9:21:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[AddProduct]
	-- Add the parameters for the stored procedure here
	@ProdID int,
	@ProdName  varchar(200),
	@Size float,
	@Color varchar(50), 
	@Price float,
	@Weight float,
	@CatID int

AS
BEGIN
INSERT INTO Product(ProdID,ProdName,Size,Color,Price,Weight,CatID)
Values (@ProdID,@ProdName,@Size,@Color,@Price,@Weight,@CatID)
END
GO
/****** Object:  StoredProcedure [dbo].[InsertCustomer]    Script Date: 1/10/2021 9:21:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[InsertCustomer]
	-- Add the parameters for the stored procedure here
	@CID int,
	@Fname  varchar(50), 
	@Minit char(1),
	@Lname varchar(50), 
	@Email varchar(200),
	@Username varchar(50),
	@Password varchar(100)
AS
BEGIN
INSERT INTO Customer(CID,Fname,Minit,Lname,Email,Username,Password)
Values (@CID,@Fname,@Minit,@Lname,@Email,@Username,HASHBYTES('MD5',@Password))
END
GO
/****** Object:  StoredProcedure [dbo].[InsertEmployee]    Script Date: 1/10/2021 9:21:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[InsertEmployee]
	-- Add the parameters for the stored procedure here
	@Fname  varchar(50), 
	@Minit char(1),
	@Lname varchar(50), 
	@EID int,
	@Salary int,
	@Sex char(1),
	@Bdate date,
	@Username varchar(50),
	@Password varchar(100)
AS
BEGIN
INSERT INTO Employee(Fname,Minit,Lname,EID,Salary,Sex,Bdate,Username,Password)
Values (@Fname,@Minit,@Lname,@EID,@Salary,@Sex,@Bdate,@Username,HASHBYTES('MD5',@Password))
END
GO
/****** Object:  StoredProcedure [dbo].[InsertManager]    Script Date: 1/10/2021 9:21:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[InsertManager]
	-- Add the parameters for the stored procedure here
	@Fname  varchar(50), 
	@Minit char(1),
	@Lname varchar(50), 
	@MID int,
	@Salary int,
	@Sex char(1),
	@Bdate date,
	@Username varchar(50),
	@Password varchar(100)
AS
BEGIN
INSERT INTO Manager(Fname,Minit,Lname,MID,Salary,Sex,Bdate,Username,Password)
Values (@Fname,@Minit,@Lname,@MID,@Salary,@Sex,@Bdate,@Username,HASHBYTES('MD5',@Password))
END
GO
/****** Object:  StoredProcedure [dbo].[ViewAllEmployees]    Script Date: 1/10/2021 9:21:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[ViewAllEmployees]
AS
BEGIN
	SELECT *
     From Employee
END
GO
/****** Object:  StoredProcedure [dbo].[ViewAllProducts]    Script Date: 1/10/2021 9:21:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[ViewAllProducts]
AS
BEGIN
	SELECT *
     From Product
END

GO
/****** Object:  StoredProcedure [dbo].[ViewAllReviews]    Script Date: 1/10/2021 9:21:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[ViewAllReviews]
AS
BEGIN
	SELECT *
     From Review
END
GO
/****** Object:  StoredProcedure [dbo].[ViewAllSuppliers]    Script Date: 1/10/2021 9:21:11 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[ViewAllSuppliers]
AS
BEGIN
	SELECT *
     From Supplier
END
GO
USE [master]
GO
ALTER DATABASE [Online_Shop1] SET  READ_WRITE 
GO
