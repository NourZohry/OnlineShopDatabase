use Online_Shop1
GO

CREATE PROCEDURE AddProduct
	-- Add the parameters for the stored procedure here
	@ProdID int,
	@ProdName  varchar(200),
	@Size float,
	@Color varchar(50), 
	@Price float,
	@Weight float,
	@CatID int

AS
BEGIN
INSERT INTO Product(ProdID,ProdName,Size,Color,Price,Weight,CatID)
Values (@ProdID,@ProdName,@Size,@Color,@Price,@Weight,@CatID)
END
GO
 