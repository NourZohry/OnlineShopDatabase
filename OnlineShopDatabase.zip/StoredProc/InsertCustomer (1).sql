use Online_Shop1
GO

CREATE PROCEDURE InsertCustomer
	-- Add the parameters for the stored procedure here
	@CID int,
	@Fname  varchar(50), 
	@Minit char(1),
	@Lname varchar(50), 
	@Email varchar(200),
	@Username varchar(50),
	@Password varchar(100)
AS
BEGIN
INSERT INTO Customer(CID,Fname,Minit,Lname,Email,Username,Password)
Values (@CID,@Fname,@Minit,@Lname,@Email,@Username,HASHBYTES('MD5',@Password))
END
GO


