use Online_Shop1
GO

CREATE PROCEDURE InsertEmployee
	-- Add the parameters for the stored procedure here
	@Fname  varchar(50), 
	@Minit char(1),
	@Lname varchar(50), 
	@EID int,
	@Salary int,
	@Sex char(1),
	@Bdate date,
	@Username varchar(50),
	@Password varchar(100)
AS
BEGIN
INSERT INTO Employee(Fname,Minit,Lname,EID,Salary,Sex,Bdate,Username,Password)
Values (@Fname,@Minit,@Lname,@EID,@Salary,@Sex,@Bdate,@Username,HASHBYTES('MD5',@Password))
END
GO
