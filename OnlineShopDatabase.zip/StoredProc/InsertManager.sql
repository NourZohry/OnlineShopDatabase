use Online_Shop1
GO

CREATE PROCEDURE InsertManager
	-- Add the parameters for the stored procedure here
	@Fname  varchar(50), 
	@Minit char(1),
	@Lname varchar(50), 
	@MID int,
	@Salary int,
	@Sex char(1),
	@Bdate date,
	@Username varchar(50),
	@Password varchar(100)
AS
BEGIN
INSERT INTO Manager(Fname,Minit,Lname,MID,Salary,Sex,Bdate,Username,Password)
Values (@Fname,@Minit,@Lname,@MID,@Salary,@Sex,@Bdate,@Username,HASHBYTES('MD5',@Password))
END
GO
