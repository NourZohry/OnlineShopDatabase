--//set ANSI_NULLS ON
--set QUOTED_IDENTIFIER ON
use Online_Shop1
GO
CREATE PROCEDURE ViewAllProducts
AS
BEGIN
	SELECT *
     From Product
END

